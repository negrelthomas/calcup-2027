/* CalCup 2027 — renders all views from window.CALCUP. No data lives here. */
(function () {
  var D = window.CALCUP || {};
  var M = D.meta || {};
  var teams = D.teams || [], refs = D.referees || [], vols = D.volunteers || [], games = D.games || [];
  var WIN = M.winPoints != null ? M.winPoints : 2, DRAW = M.drawPoints != null ? M.drawPoints : 1, LOSS = M.lossPoints != null ? M.lossPoints : 0;
  var DAYS = ["Thu", "Fri", "Sat", "Sun"];

  var byId = {}; teams.forEach(function (t) { byId[t.id] = t; });
  var refMap = {}; refs.forEach(function (r) { refMap[r.id] = r; });
  var volMap = {}; vols.forEach(function (v) { volMap[v.id] = v; });

  function teamName(id) {
    if (byId[id]) return byId[id].name;
    if (id && id.indexOf("tbd-") === 0) return "TBD (" + id.slice(4).toUpperCase() + ")";
    return id || "TBD";
  }
  function isReal(id) { return !!byId[id]; }
  function refName(id) { return refMap[id] ? refMap[id].pair + (refMap[id].country ? " (" + refMap[id].country + ")" : "") : "TBD"; }
  function tableNames(ids) { return (ids || []).map(function (i) { return volMap[i] ? volMap[i].name : i; }).join(", ") || "TBD"; }
  function statusPill(s) {
    if (s === "final") return '<span class="pill final">Final</span>';
    if (s === "live") return '<span class="pill live"><i class="ti ti-player-play"></i> Live</span>';
    return '<span class="pill up">Upcoming</span>';
  }
  function gameTitle(g) { return g.label || ((g.division === "W" ? "Women" : "Men") + (g.group === "A" || g.group === "B" ? " · Group " + g.group : "")); }
  function set(id, html) { var el = document.getElementById(id); if (el) el.innerHTML = html; }

  /* ---------- game card ---------- */
  function gameCardHTML(g) {
    var a = g.status === "upcoming" ? '<span class="sc" style="color:var(--muted)">–</span>' : '<span class="sc">' + g.scoreA + "</span>";
    var b = g.status === "upcoming" ? '<span class="sc" style="color:var(--muted)">–</span>' : '<span class="sc">' + g.scoreB + "</span>";
    return '<div class="game">' +
      '<div class="meta">' + gameTitle(g) + " · Game " + g.no + " · " + g.day + " " + g.time + " · Court " + g.court + "</div>" +
      '<div class="row"><span>' + teamName(g.teamA) + "</span>" + a + "</div>" +
      '<div class="row" style="color:var(--muted)"><span>' + teamName(g.teamB) + "</span>" + b + "</div>" +
      '<div style="margin-top:8px">' + statusPill(g.status) + "</div>" +
      '<div class="offi">' +
        '<div><i class="ti ti-whistle"></i> Refs: ' + refName(g.refs) + "</div>" +
        '<div><i class="ti ti-clipboard-list"></i> Table: ' + tableNames(g.table) + "</div>" +
      "</div></div>";
  }

  /* ---------- top scorers ---------- */
  function topScorers(division, limit) {
    var tally = {};
    games.forEach(function (g) {
      (g.goals || []).forEach(function (e) {
        var t = byId[e.team]; if (!t || t.division !== division) return;
        var key = e.player + "|" + e.team;
        if (!tally[key]) tally[key] = { player: e.player, team: e.team, goals: 0 };
        tally[key].goals += e.goals;
      });
    });
    var arr = Object.keys(tally).map(function (k) { return tally[k]; }).sort(function (a, b) { return b.goals - a.goals; });
    return limit ? arr.slice(0, limit) : arr;
  }
  function leaderHTML(list) {
    if (!list.length) return '<div style="color:var(--muted);font-size:14px">No goals recorded yet.</div>';
    return '<div class="lead">' + list.map(function (s, i) {
      return '<div class="lrow"><span><span class="rk ' + (i === 0 ? "top" : "") + '">' + (i + 1) + "</span> " +
        s.player + " · " + teamName(s.team) + "</span><span style=\"font-weight:700\">" + s.goals + "</span></div>";
    }).join("") + "</div>";
  }

  /* ---------- standings (with head-to-head tiebreak) ---------- */
  function finalsFor(div, grp) {
    return games.filter(function (g) {
      return g.status === "final" && g.division === div && g.group === grp && isReal(g.teamA) && isReal(g.teamB);
    });
  }
  function computeTable(div, grp) {
    var row = {};
    teams.filter(function (t) { return t.division === div && t.group === grp; })
      .forEach(function (t) { row[t.id] = { id: t.id, name: t.name, P: 0, W: 0, D: 0, L: 0, GF: 0, GA: 0, Pts: 0 }; });
    var fin = finalsFor(div, grp);
    fin.forEach(function (g) {
      var A = row[g.teamA], B = row[g.teamB]; if (!A || !B) return;
      A.P++; B.P++; A.GF += g.scoreA; A.GA += g.scoreB; B.GF += g.scoreB; B.GA += g.scoreA;
      if (g.scoreA > g.scoreB) { A.W++; B.L++; A.Pts += WIN; B.Pts += LOSS; }
      else if (g.scoreB > g.scoreA) { B.W++; A.L++; B.Pts += WIN; A.Pts += LOSS; }
      else { A.D++; B.D++; A.Pts += DRAW; B.Pts += DRAW; }
    });
    var arr = Object.keys(row).map(function (k) { return row[k]; });
    arr.sort(function (a, b) { return b.Pts - a.Pts; });
    // resolve equal-points clusters by mini-league (h2h), then overall GD, GF
    var out = [], i = 0;
    while (i < arr.length) {
      var j = i; while (j < arr.length && arr[j].Pts === arr[i].Pts) j++;
      var cluster = arr.slice(i, j);
      if (cluster.length > 1) {
        var ids = {}; cluster.forEach(function (t) { ids[t.id] = { pts: 0, gd: 0 }; });
        fin.forEach(function (g) {
          if (ids[g.teamA] && ids[g.teamB]) {
            ids[g.teamA].gd += g.scoreA - g.scoreB; ids[g.teamB].gd += g.scoreB - g.scoreA;
            if (g.scoreA > g.scoreB) { ids[g.teamA].pts += WIN; ids[g.teamB].pts += LOSS; }
            else if (g.scoreB > g.scoreA) { ids[g.teamB].pts += WIN; ids[g.teamA].pts += LOSS; }
            else { ids[g.teamA].pts += DRAW; ids[g.teamB].pts += DRAW; }
          }
        });
        cluster.sort(function (a, b) {
          var m = ids[b.id].pts - ids[a.id].pts; if (m) return m;
          var mg = ids[b.id].gd - ids[a.id].gd; if (mg) return mg;
          var gd = (b.GF - b.GA) - (a.GF - a.GA); if (gd) return gd;
          if (b.GF !== a.GF) return b.GF - a.GF;
          return a.name.localeCompare(b.name);
        });
      }
      cluster.forEach(function (t) { out.push(t); });
      i = j;
    }
    return out;
  }
  function tableHTML(div, grp, qualifies) {
    var rows = computeTable(div, grp);
    var body = rows.map(function (t, i) {
      var q = i < qualifies ? ' class="qual"' : '';
      return '<tr' + q + '><td>' + (i + 1) + '</td><td class="tm">' + t.name + '</td><td>' + t.P + '</td><td>' + t.W + '</td><td>' + t.D + '</td><td>' + t.L + '</td><td>' + t.GF + '</td><td>' + t.GA + '</td><td>' + (t.GF - t.GA > 0 ? "+" : "") + (t.GF - t.GA) + '</td><td class="pts">' + t.Pts + '</td></tr>';
    }).join("");
    return '<table class="tbl"><thead><tr><th>#</th><th style="text-align:left">Team</th><th>P</th><th>W</th><th>D</th><th>L</th><th>GF</th><th>GA</th><th>GD</th><th>Pts</th></tr></thead><tbody>' + body + '</tbody></table>';
  }

  /* ---------- schedule ---------- */
  function rowHTML(g) {
    var res = g.status === "final" ? '<span class="res final">' + g.scoreA + "–" + g.scoreB + "</span>"
      : g.status === "live" ? '<span class="res live"><i class="ti ti-player-play"></i> ' + g.scoreA + "–" + g.scoreB + "</span>"
      : '<span class="res up">' + g.time + "</span>";
    return '<div class="grow" data-div="' + g.division + '">' +
      '<div class="gno">' + g.no + '</div>' +
      '<div class="gmain"><div class="gteams">' + teamName(g.teamA) + ' <span class="v">v</span> ' + teamName(g.teamB) + '</div>' +
      '<div class="gsub">' + gameTitle(g) + ' · ' + g.time + ' · Court ' + g.court +
      ' · <i class="ti ti-whistle"></i> ' + refName(g.refs) + ' · <i class="ti ti-clipboard-list"></i> ' + tableNames(g.table) + '</div></div>' +
      '<div class="gres">' + res + '</div></div>';
  }
  function renderSchedule(el) {
    var html = DAYS.filter(function (d) { return games.some(function (g) { return g.day === d; }); }).map(function (d) {
      var gs = games.filter(function (g) { return g.day === d; });
      return '<div class="dayblock"><h3 class="dayhead">' + dayLabel(d) + '</h3>' + gs.map(rowHTML).join("") + '</div>';
    }).join("");
    el.innerHTML = html;
  }
  function dayLabel(d) {
    return { Thu: "Thursday — opener", Fri: "Friday", Sat: "Saturday", Sun: "Sunday — placements & finals" }[d] || d;
  }

  /* ---------- watch ---------- */
  function renderWatch(el) {
    if (M.streamUrl) {
      el.innerHTML = '<div class="video"><iframe src="' + M.streamUrl + '" title="CalCup live stream" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>';
    } else {
      el.innerHTML = '<div class="video placeholder"><div><i class="ti ti-player-play" style="font-size:34px;color:var(--orange)"></i><p>The live stream goes live when the tournament begins.</p><p style="font-size:13px;color:var(--muted)">All games are streamed. Bookmark this page.</p></div></div>';
    }
  }

  /* ---------- featured / preview ---------- */
  function featured() {
    return games.find(function (g) { return g.status === "live"; }) ||
      games.find(function (g) { return g.status === "upcoming" && isReal(g.teamA); }) ||
      games.slice().reverse().find(function (g) { return g.status === "final"; });
  }
  function previewRows(list) {
    return '<div class="sched">' + list.map(function (g) {
      var res = g.status === "final" ? '<span style="color:var(--green);font-weight:600">' + g.scoreA + "-" + g.scoreB + "</span>"
        : g.status === "live" ? '<span style="color:var(--red);font-weight:600">live</span>'
        : '<span style="color:var(--muted)">' + g.time + "</span>";
      return '<div class="srow"><span style="color:var(--muted)">' + g.day + "</span>" +
        "<span>" + teamName(g.teamA) + " v " + teamName(g.teamB) +
        '<div class="refs"><i class="ti ti-whistle"></i> ' + refName(g.refs) + "</div></span>" +
        "<span style=\"text-align:right\">" + res + "</span></div>";
    }).join("") + "</div>";
  }

  /* ---------- teams ---------- */
  function getParam(k) { return new URLSearchParams(location.search).get(k); }
  function teamFinals(id) { return games.filter(function (g) { return g.status === "final" && (g.teamA === id || g.teamB === id); }); }
  function teamGames(id) { return games.filter(function (g) { return g.teamA === id || g.teamB === id; }); }
  function teamRecord(id) {
    var r = { W: 0, L: 0, D: 0, GF: 0, GA: 0 };
    teamFinals(id).forEach(function (g) {
      var us = g.teamA === id ? g.scoreA : g.scoreB, th = g.teamA === id ? g.scoreB : g.scoreA;
      r.GF += us; r.GA += th; if (us > th) r.W++; else if (us < th) r.L++; else r.D++;
    });
    return r;
  }
  function divLabel(d, g) { return (d === "W" ? "Women" : "Men" + (g === "A" || g === "B" ? " · Group " + g : "")); }
  function renderTeamsDirectory(el) {
    var groups = [["Men · Group A", "M", "A"], ["Men · Group B", "M", "B"], ["Women", "W", "W"]];
    el.innerHTML = groups.map(function (grp) {
      var ts = teams.filter(function (t) { return t.division === grp[1] && t.group === grp[2]; });
      return '<section><div class="sec-head"><h2>' + grp[0] + '</h2></div><div class="grid cols-3">' +
        ts.map(function (t) {
          var r = teamRecord(t.id);
          return '<a class="card teamcard" href="team.html?id=' + t.id + '"><h3>' + t.name + '</h3>' +
            '<div class="muted">' + t.city + '</div>' +
            '<div class="rec">' + r.W + 'W · ' + r.L + 'L</div></a>';
        }).join("") + '</div></section>';
    }).join("");
  }
  function renderTeamDetail(el) {
    var t = byId[getParam("id")];
    if (!t) { el.innerHTML = '<div class="card">Team not found. <a href="teams.html">Back to teams</a></div>'; return; }
    document.title = t.name + " — CalCup 2027";
    var r = teamRecord(t.id);
    var ros = (D.rosters && D.rosters[t.id]) || [];
    var rosterHTML = ros.length
      ? '<table class="tbl"><thead><tr><th>#</th><th style="text-align:left">Player</th><th style="text-align:left">Position</th></tr></thead><tbody>' +
        ros.map(function (p) { return '<tr><td>' + p.n + '</td><td class="tm">' + p.name + '</td><td style="text-align:left">' + p.pos + '</td></tr>'; }).join("") + '</tbody></table>'
      : '<div class="muted">Roster to be announced.</div>';
    var gs = teamGames(t.id).map(function (g) {
      var opp = g.teamA === t.id ? teamName(g.teamB) : teamName(g.teamA);
      var us = g.teamA === t.id ? g.scoreA : g.scoreB, th = g.teamA === t.id ? g.scoreB : g.scoreA;
      var res = g.status === "final" ? '<span class="res final">' + us + "–" + th + (us > th ? " W" : us < th ? " L" : "") + "</span>"
        : g.status === "live" ? '<span class="res live">live</span>' : '<span class="res up">' + g.day + " " + g.time + "</span>";
      return '<div class="grow"><div class="gno">' + g.no + '</div><div class="gmain"><div class="gteams">vs ' + opp + '</div><div class="gsub">' + gameTitle(g) + '</div></div><div class="gres">' + res + '</div></div>';
    }).join("");
    el.innerHTML =
      '<section><h1 style="font-size:28px;margin:0 0 4px">' + t.name + '</h1>' +
      '<p class="muted" style="margin:0 0 14px">' + t.city + ' · ' + divLabel(t.division, t.group) + ' · Record ' + r.W + 'W–' + r.L + 'L</p>' +
      '<div class="grid cols-2"><div><div class="sec-head"><h2>Roster</h2></div>' + rosterHTML + '</div>' +
      '<div><div class="sec-head"><h2>Games</h2></div>' + gs + '</div></div></section>';
  }

  /* ---------- referees ---------- */
  function renderReferees(el) {
    el.innerHTML = '<div class="grid cols-2">' + refs.map(function (r) {
      var assigned = games.filter(function (g) { return g.refs === r.id; });
      var list = assigned.map(function (g) { return '<div class="refgame">Game ' + g.no + ' · ' + g.day + ' ' + g.time + ' · ' + teamName(g.teamA) + ' v ' + teamName(g.teamB) + '</div>'; }).join("");
      return '<div class="card"><h3><i class="ti ti-whistle" style="color:var(--orange-dark)"></i> ' + r.pair + (r.country ? ' <span class="badge2">' + r.country + '</span>' : '') + '</h3>' +
        (r.bio ? '<div class="muted" style="margin-bottom:8px">' + r.bio + '</div>' : '') +
        '<div class="muted" style="font-size:12px;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Assignments (' + assigned.length + ')</div>' + list + '</div>';
    }).join("") + '</div>';
  }

  /* ---------- sponsors ---------- */
  function renderSponsors(el) {
    var s = D.sponsors || {};
    var current = (s.list && s.list.length)
      ? s.list.map(function (x) { return '<div class="sponsor"><div class="sname">' + x.name + '</div>' + (x.tier ? '<div class="muted">' + x.tier + '</div>' : '') + '</div>'; }).join("")
      : '<div class="sponsor ph">Your logo here</div><div class="sponsor ph">Your logo here</div><div class="sponsor ph">Your logo here</div>';
    el.innerHTML =
      '<section><div class="card" style="border-color:var(--orange);background:var(--orange-tint)">' +
      '<h3 style="margin-top:0">Become a CalCup sponsor — ' + (s.ask || '') + '</h3>' +
      '<p style="margin:0 0 6px">' + (s.intro || '') + '</p>' +
      '<a class="btn btn-pri" href="mailto:' + (s.contact || 'calcup@calheat.com') + '?subject=CalCup%202027%20sponsorship"><i class="ti ti-mail"></i> Sponsor CalCup</a></div></section>' +
      '<section><div class="sec-head"><h2>What sponsors receive</h2></div><div class="card"><ul class="rules" style="margin:0;padding-left:18px">' +
      (s.benefits || []).map(function (b) { return '<li>' + b + '</li>'; }).join("") + '</ul></div></section>' +
      '<section><div class="sec-head"><h2>Our supporters</h2></div><div class="sponsorgrid">' + current + '</div></section>';
  }

  /* ---------- history ---------- */
  function renderHistory(el) {
    var h = D.history || {};
    var tl = (h.timeline || []).map(function (e) { return '<div class="tlrow"><div class="tlyear">' + e.year + '</div><div class="tltext">' + e.text + '</div></div>'; }).join("");
    var aw = (h.awards || []).map(function (a) { return '<div class="card"><h3 style="margin:0 0 2px">' + a.name + '</h3><div class="muted">' + a.for + '</div></div>'; }).join("");
    var champ = (h.champions && h.champions.length)
      ? '<table class="tbl"><thead><tr><th>Year</th><th>Ed.</th><th style="text-align:left">Men champion</th><th style="text-align:left">Women champion</th></tr></thead><tbody>' +
        h.champions.map(function (c) { return '<tr><td>' + c.year + '</td><td>' + (c.edition || '') + '</td><td class="tm">' + (c.menChampion || 'TBA') + '</td><td class="tm">' + (c.womenChampion || 'TBA') + '</td></tr>'; }).join("") + '</tbody></table>'
      : '<div class="callout">Two decades of champions are being compiled. Have results or photos from past editions? Email <a href="mailto:' + M.contactEmail + '">' + M.contactEmail + '</a>.</div>';
    el.innerHTML =
      '<section><p style="font-size:17px;max-width:760px">' + (h.blurb || '') + '</p></section>' +
      '<section><div class="sec-head"><h2>Milestones</h2></div><div class="timeline">' + tl + '</div></section>' +
      '<section><div class="sec-head"><h2>The awards</h2></div><div class="grid cols-2">' + aw + '</div></section>' +
      '<section><div class="sec-head"><h2>Hall of Champions</h2></div>' + champ + '</section>';
  }

  function init() {
    var b = document.getElementById("burger");
    if (b) b.addEventListener("click", function () { document.getElementById("menu").classList.toggle("open"); });

    // home
    var f = featured(); if (document.getElementById("featured") && f) set("featured", gameCardHTML(f));
    if (document.getElementById("top-m")) set("top-m", leaderHTML(topScorers("M", 5)));
    if (document.getElementById("top-w")) set("top-w", leaderHTML(topScorers("W", 5)));
    if (document.getElementById("sched-preview")) {
      var next = games.filter(function (g) { return g.status !== "final"; }).slice(0, 5);
      set("sched-preview", previewRows(next));
    }

    // standings
    if (document.getElementById("tbl-ma")) set("tbl-ma", tableHTML("M", "A", 1));
    if (document.getElementById("tbl-mb")) set("tbl-mb", tableHTML("M", "B", 1));
    if (document.getElementById("tbl-w")) set("tbl-w", tableHTML("W", "W", 2));

    // scorers (full)
    if (document.getElementById("scorers-m")) set("scorers-m", leaderHTML(topScorers("M")));
    if (document.getElementById("scorers-w")) set("scorers-w", leaderHTML(topScorers("W")));

    // schedule
    var sc = document.getElementById("schedule"); if (sc) renderSchedule(sc);
    document.querySelectorAll("[data-filter]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var f = btn.getAttribute("data-filter");
        document.querySelectorAll("[data-filter]").forEach(function (x) { x.classList.toggle("on", x === btn); });
        document.querySelectorAll(".grow").forEach(function (r) {
          r.style.display = (f === "all" || r.getAttribute("data-div") === f) ? "" : "none";
        });
        document.querySelectorAll(".dayblock").forEach(function (db) {
          var any = Array.prototype.some.call(db.querySelectorAll(".grow"), function (r) { return r.style.display !== "none"; });
          db.style.display = any ? "" : "none";
        });
      });
    });

    // teams / referees / sponsors / history
    var td = document.getElementById("teams-dir"); if (td) renderTeamsDirectory(td);
    var tdet = document.getElementById("team-detail"); if (tdet) renderTeamDetail(tdet);
    var rfp = document.getElementById("referees"); if (rfp) renderReferees(rfp);
    var spn = document.getElementById("sponsors"); if (spn) renderSponsors(spn);
    var his = document.getElementById("history"); if (his) renderHistory(his);

    // watch
    var w = document.getElementById("watch"); if (w) renderWatch(w);
    var sb = document.getElementById("stream-btn"); if (sb && M.streamUrl) sb.setAttribute("href", M.streamUrl);
  }
  if (document.readyState !== "loading") init();
  else document.addEventListener("DOMContentLoaded", init);
})();

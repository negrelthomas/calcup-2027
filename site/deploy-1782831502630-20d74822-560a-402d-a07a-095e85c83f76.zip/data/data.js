/*
  CalCup 2027 — single source of truth.
  Everything on the site (schedule, standings, top scorers, team pages,
  referee pages) is generated from THIS file. To update during the
  tournament you only edit the `games` entries below — nothing else.

  TO RECORD A RESULT: set scoreA/scoreB, change status to "final",
  and (optionally) add scorers to goals: []. Standings + top scorers
  recompute automatically. See UPDATE-GUIDE.md.

  NOTE: data below is seeded from CalCup 2026 as a working SAMPLE in a
  mid-tournament state for testing. Replace once 2027 entries are locked.
*/
window.CALCUP = {
  meta: {
    edition: "XX",
    editionLabel: "20th edition",
    year: 2027,
    name: "California Cup 2027",
    host: "San Francisco CalHeat",
    dates: "Jan 29 – Feb 1, 2027",
    venue: "Centerville Middle School",
    venueAddress: "37720 Fremont Blvd, Fremont, CA 94536",
    streamUrl: "",
    contactEmail: "calcup@calheat.com",
    winPoints: 2, drawPoints: 1, lossPoints: 0
  },

  teams: [
    { id:"boston",   name:"Boston TH",          city:"Boston, MA",        division:"M", group:"A", logo:"" },
    { id:"lathc",    name:"LATHC",              city:"Los Angeles, CA",   division:"M", group:"A", logo:"" },
    { id:"seattle",  name:"Seattle",            city:"Seattle, WA",       division:"M", group:"A", logo:"" },
    { id:"ch-orange",name:"CalHeat Orange",     city:"San Francisco, CA", division:"M", group:"A", logo:"" },
    { id:"denver",   name:"Denver Wolves",      city:"Denver, CO",        division:"M", group:"B", logo:"" },
    { id:"sd-m",     name:"San Diego M",        city:"San Diego, CA",     division:"M", group:"B", logo:"" },
    { id:"ch-blue",  name:"CalHeat Blue",       city:"San Francisco, CA", division:"M", group:"B", logo:"" },
    { id:"army-m",   name:"West Point – Army M",city:"West Point, NY",    division:"M", group:"B", logo:"" },
    { id:"ch-w",     name:"CalHeat",            city:"San Francisco, CA", division:"W", group:"W", logo:"" },
    { id:"massif",   name:"Massif SLC",         city:"Salt Lake City, UT",division:"W", group:"W", logo:"" },
    { id:"nyc",      name:"NYC",                city:"New York, NY",      division:"W", group:"W", logo:"" },
    { id:"sd-w",     name:"San Diego W",        city:"San Diego, CA",     division:"W", group:"W", logo:"" },
    { id:"army-w",   name:"West Point – Army W",city:"West Point, NY",    division:"W", group:"W", logo:"" }
  ],

  // optional: { id: [ {n, name, pos} ] }. Empty teams show "Roster to be announced".
  rosters: {
    "ch-w":     [ {n:1,name:"C. Duvert",pos:"Goalkeeper"}, {n:7,name:"L. Movahedian",pos:"Left wing"}, {n:10,name:"G. Davi",pos:"Centre back"} ],
    "boston":   [ {n:9,name:"N. Gros",pos:"Right back"}, {n:11,name:"F. Henry",pos:"Pivot"} ],
    "ch-orange":[ {n:8,name:"M. Paulus",pos:"Centre back"} ]
  },

  referees: [
    { id:"r1", pair:"Dupont / Bernard", country:"FRA", bio:"International pair officiating in the French league." },
    { id:"r2", pair:"Smith / Johnson",  country:"USA", bio:"USATH-certified national referees." },
    { id:"r3", pair:"Garcia / Lopez",   country:"USA", bio:"USATH-certified national referees." }
  ],

  volunteers: [
    { id:"v1", name:"K. Rosolowski" },
    { id:"v2", name:"M. Andrews" },
    { id:"v3", name:"P. Nguyen" },
    { id:"v4", name:"L. Moreau" }
  ],

  sponsors: {
    ask: "$1,500–$2,000",
    intro: "CalCup keeps registration affordable for teams traveling from across North America. Sponsor support covers the venue, referee travel, physiotherapy and logistics that make the event possible.",
    benefits: [
      "Logo on the tournament website",
      "Logo on the 3-day nationwide live stream and post-event highlights",
      "Recognition in announcements and event communications",
      "Banner display in the venue (if provided)",
      "Optional player photo or quote"
    ],
    contact: "calcup@calheat.com",
    list: []  // [{name, tier, url, logo}] — add confirmed sponsors here
  },

  history: {
    firstYear: 2007,
    blurb: "CalCup is the nation's longest-running team handball tournament, hosted by San Francisco CalHeat — a Bay Area club and 501(c)(3) nonprofit since 2012. Each year around 200 athletes from across the U.S. and Canada compete in elite men's and women's divisions, streamed nationwide. Many began in CalHeat's grassroots youth programs, some now chasing the Olympic dream for LA 2028.",
    timeline: [
      { year:2007, text:"First California Cup hosted by San Francisco CalHeat" },
      { year:2012, text:"CalHeat becomes a 501(c)(3) nonprofit" },
      { year:2026, text:"19th edition — ~200 athletes from the U.S., Canada and abroad" },
      { year:2027, text:"20th edition (XX) — two decades of elite handball" }
    ],
    awards: [
      { name:"Jack Holleman Trophy", for:"Champions (Men & Women)" },
      { name:"Steve Goss Award", for:"Most Valuable Player" },
      { name:"Mark Ragatz Award", for:"Most Valuable Goalkeeper" },
      { name:"Joe McVein Award", for:"Top Scorer" }
    ],
    champions: []  // [{year, edition, menChampion, womenChampion}] — being compiled
  },

  games: [
    { no:1, day:"Thu", time:"9:00 PM", court:1, division:"W", group:"W", teamA:"ch-w", teamB:"massif", scoreA:30, scoreB:22, status:"final", refs:"r2", table:["v1","v2"], stream:true, goals:[{team:"ch-w",player:"L. Movahedian",goals:9},{team:"massif",player:"R. Adams",goals:7}] },
    { no:2, day:"Fri", time:"3:45 PM", court:1, division:"M", group:"A", teamA:"boston", teamB:"lathc", scoreA:31, scoreB:27, status:"final", refs:"r1", table:["v3","v4"], stream:true, goals:[{team:"lathc",player:"F. Grifol",goals:11},{team:"boston",player:"N. Gros",goals:8}] },
    { no:3, day:"Fri", time:"4:55 PM", court:1, division:"M", group:"B", teamA:"denver", teamB:"sd-m", scoreA:30, scoreB:25, status:"final", refs:"r2", table:["v1","v2"], stream:true, goals:[{team:"denver",player:"A. Keller",goals:9}] },
    { no:4, day:"Fri", time:"6:05 PM", court:1, division:"W", group:"W", teamA:"nyc", teamB:"sd-w", scoreA:24, scoreB:21, status:"final", refs:"r3", table:["v3","v4"], stream:true, goals:[{team:"nyc",player:"S. Cohen",goals:8},{team:"sd-w",player:"T. Ruiz",goals:6}] },
    { no:5, day:"Fri", time:"7:15 PM", court:1, division:"M", group:"A", teamA:"seattle", teamB:"ch-orange", scoreA:24, scoreB:28, status:"final", refs:"r1", table:["v1","v2"], stream:true, goals:[{team:"ch-orange",player:"M. Paulus",goals:10},{team:"seattle",player:"J. Park",goals:7}] },
    { no:6, day:"Fri", time:"8:25 PM", court:1, division:"M", group:"B", teamA:"ch-blue", teamB:"army-m", scoreA:27, scoreB:29, status:"final", refs:"r2", table:["v3","v4"], stream:true, goals:[{team:"army-m",player:"D. Wright",goals:9}] },
    { no:7, day:"Fri", time:"9:35 PM", court:1, division:"W", group:"W", teamA:"ch-w", teamB:"nyc", scoreA:28, scoreB:25, status:"final", refs:"r3", table:["v1","v2"], stream:true, goals:[{team:"ch-w",player:"L. Movahedian",goals:6},{team:"nyc",player:"S. Cohen",goals:7}] },
    { no:8, day:"Sat", time:"7:30 AM", court:1, division:"M", group:"A", teamA:"boston", teamB:"seattle", scoreA:26, scoreB:22, status:"final", refs:"r1", table:["v3","v4"], stream:true, goals:[{team:"boston",player:"N. Gros",goals:9}] },
    { no:9, day:"Sat", time:"8:40 AM", court:1, division:"W", group:"W", teamA:"massif", teamB:"army-w", scoreA:26, scoreB:23, status:"final", refs:"r2", table:["v1","v2"], stream:true, goals:[{team:"massif",player:"R. Adams",goals:8}] },
    { no:10, day:"Sat", time:"9:50 AM", court:1, division:"M", group:"B", teamA:"denver", teamB:"ch-blue", scoreA:28, scoreB:26, status:"final", refs:"r3", table:["v3","v4"], stream:true, goals:[{team:"denver",player:"M. Stone",goals:8}] },
    { no:11, day:"Sat", time:"11:00 AM", court:1, division:"W", group:"W", teamA:"ch-w", teamB:"sd-w", scoreA:18, scoreB:16, status:"live", refs:"r1", table:["v1","v2"], stream:true, goals:[] },
    { no:12, day:"Sat", time:"12:10 PM", court:1, division:"M", group:"A", teamA:"lathc", teamB:"ch-orange", scoreA:null, scoreB:null, status:"upcoming", refs:"r2", table:["v3","v4"], stream:true, goals:[] },
    { no:13, day:"Sat", time:"1:20 PM", court:1, division:"W", group:"W", teamA:"nyc", teamB:"army-w", scoreA:null, scoreB:null, status:"upcoming", refs:"r3", table:["v1","v2"], stream:true, goals:[] },
    { no:14, day:"Sat", time:"2:30 PM", court:1, division:"M", group:"B", teamA:"sd-m", teamB:"army-m", scoreA:null, scoreB:null, status:"upcoming", refs:"r1", table:["v3","v4"], stream:true, goals:[] },
    { no:15, day:"Sat", time:"3:40 PM", court:1, division:"M", group:"A", teamA:"boston", teamB:"ch-orange", scoreA:null, scoreB:null, status:"upcoming", refs:"r2", table:["v1","v2"], stream:true, goals:[] },
    { no:16, day:"Sat", time:"4:50 PM", court:1, division:"W", group:"W", teamA:"ch-w", teamB:"army-w", scoreA:null, scoreB:null, status:"upcoming", refs:"r3", table:["v3","v4"], stream:true, goals:[] },
    { no:17, day:"Sat", time:"6:00 PM", court:1, division:"W", group:"W", teamA:"massif", teamB:"sd-w", scoreA:null, scoreB:null, status:"upcoming", refs:"r1", table:["v1","v2"], stream:true, goals:[] },
    { no:18, day:"Sat", time:"7:10 PM", court:1, division:"M", group:"B", teamA:"denver", teamB:"army-m", scoreA:null, scoreB:null, status:"upcoming", refs:"r2", table:["v3","v4"], stream:true, goals:[] },
    { no:19, day:"Sat", time:"8:20 PM", court:1, division:"M", group:"A", teamA:"lathc", teamB:"seattle", scoreA:null, scoreB:null, status:"upcoming", refs:"r3", table:["v1","v2"], stream:true, goals:[] },
    { no:20, day:"Sat", time:"9:30 PM", court:1, division:"M", group:"B", teamA:"sd-m", teamB:"ch-blue", scoreA:null, scoreB:null, status:"upcoming", refs:"r1", table:["v3","v4"], stream:true, goals:[] },
    { no:21, day:"Sun", time:"7:30 AM", court:1, division:"W", group:"W", teamA:"massif", teamB:"nyc", scoreA:null, scoreB:null, status:"upcoming", refs:"r2", table:["v1","v2"], stream:true, goals:[] },
    { no:22, day:"Sun", time:"8:40 AM", court:1, division:"W", group:"W", teamA:"sd-w", teamB:"army-w", scoreA:null, scoreB:null, status:"upcoming", refs:"r3", table:["v3","v4"], stream:true, goals:[] },
    { no:23, day:"Sun", time:"9:50 AM", court:1, division:"M", group:"P", teamA:"tbd-a4", teamB:"tbd-b4", scoreA:null, scoreB:null, status:"upcoming", refs:"r1", table:["v1","v2"], stream:true, label:"Men · 7th place", goals:[] },
    { no:24, day:"Sun", time:"11:00 AM", court:1, division:"M", group:"P", teamA:"tbd-a3", teamB:"tbd-b3", scoreA:null, scoreB:null, status:"upcoming", refs:"r2", table:["v3","v4"], stream:true, label:"Men · 5th place", goals:[] },
    { no:25, day:"Sun", time:"12:10 PM", court:1, division:"M", group:"P", teamA:"tbd-a2", teamB:"tbd-b2", scoreA:null, scoreB:null, status:"upcoming", refs:"r3", table:["v1","v2"], stream:true, label:"Men · 3rd place", goals:[] },
    { no:26, day:"Sun", time:"1:20 PM", court:1, division:"W", group:"P", teamA:"tbd-w1", teamB:"tbd-w2", scoreA:null, scoreB:null, status:"upcoming", refs:"r1", table:["v3","v4"], stream:true, label:"Women · Final", goals:[] },
    { no:27, day:"Sun", time:"2:30 PM", court:1, division:"M", group:"P", teamA:"tbd-a1", teamB:"tbd-b1", scoreA:null, scoreB:null, status:"upcoming", refs:"r2", table:["v1","v2"], stream:true, label:"Men · Final", goals:[] }
  ]
};

"""Match card generator for handball tournaments.

Makes one social media image per game from a games CSV and a config.json.
  Live cards (default):   python make_match_cards.py --csv sample/games_sample.csv --config sample/config.json
  Final score cards:      add --results   (only games with Score A and Score B filled in)
  Story size 1080x1920:   add --story
  One game only:          add --game 5
  Output folder:          add --out my_cards   (default: cards)

CSV columns: Game #, Date, Day, Time, Court, Division, Round, Team A, Team B,
Short A, Short B, Color A, Color B, Logo A, Logo B, Score A, Score B.
Logo and Score columns are optional. A missing logo becomes a colored circle badge
with the short name. Logo paths are relative to the CSV file (or to "logo_folder"
in the config).

Requires Python 3 and Pillow (pip install -r requirements.txt).
"""
import argparse, csv, json, os, sys
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.path.join(HERE, "fonts")
WHITE = (255, 255, 255)
PHOTO_EXT = (".jpg", ".jpeg", ".png", ".webp")


# ---------------------------------------------------------------- helpers
def hex_rgb(value, fallback):
    v = (value or "").strip().lstrip("#")
    if len(v) == 3:
        v = "".join(c * 2 for c in v)
    try:
        return tuple(int(v[i:i + 2], 16) for i in (0, 2, 4))
    except (ValueError, IndexError):
        return fallback


def shade(c, f):
    """f < 1 darkens, f > 1 lightens toward white."""
    if f <= 1:
        return tuple(int(x * f) for x in c)
    return tuple(int(x + (255 - x) * (f - 1)) for x in c)


def luminance(c):
    def ch(x):
        x /= 255
        return x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(x) for x in c)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = sorted((luminance(a), luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def ink_on(bg, dark):
    """Pick the more readable of white or a dark brand color for text on bg."""
    return WHITE if contrast(bg, WHITE) >= contrast(bg, dark) else dark


def font(name, size):
    return ImageFont.truetype(os.path.join(FONT_DIR, name), max(8, int(size)))


def anton(s):
    return font("anton-400.ttf", s)


def oswald(s):
    return font("oswald-700.ttf", s)


def fit(draw, text, maker, max_w, start, min_size=10):
    s = int(start)
    while s > min_size and draw.textlength(text, font=maker(s)) > max_w:
        s -= 2
    return maker(s)


def spaced(draw, xy, text, fnt, fill, tracking, anchor="l"):
    """Draw letter spaced text. anchor: l (left), m (center), r (right); y is the middle."""
    widths = [draw.textlength(ch, font=fnt) for ch in text]
    total = sum(widths) + tracking * (len(text) - 1)
    x, y = xy
    x = x - total / 2 if anchor == "m" else x - total if anchor == "r" else x
    for ch, w in zip(text, widths):
        draw.text((x, y), ch, font=fnt, fill=fill, anchor="lm")
        x += w + tracking
    return total


def bezier(p0, p1, p2, n=80):
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0],
             (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1])
            for t in [i / n for i in range(n + 1)]]


def cover(img, w, h):
    s = max(w / img.width, h / img.height)
    img = img.resize((round(img.width * s), round(img.height * s)), Image.LANCZOS)
    x, y = (img.width - w) // 2, (img.height - h) // 2
    return img.crop((x, y, x + w, y + h))


def hatched_text(canvas, xy, text, fnt, color, anchor="ls"):
    """Solid color text with a faint diagonal hatch (printed texture look)."""
    W, H = canvas.size
    m = Image.new("L", canvas.size, 0)
    ImageDraw.Draw(m).text(xy, text, font=fnt, fill=255, anchor=anchor)
    fill = Image.new("RGB", canvas.size, color)
    hd = ImageDraw.Draw(fill)
    dk = shade(color, 0.88)
    step = max(9, W // 120)
    for x in range(-H, W, step):
        hd.line([(x, H), (x + H, 0)], fill=dk, width=max(2, step // 4))
    canvas.paste(fill, (0, 0), m)


def drop_shadow(canvas, shape, xy, blur, alpha=110, dy=10):
    pad = blur * 3
    sh = Image.new("RGBA", (shape.width + 2 * pad, shape.height + 2 * pad), (0, 0, 0, 0))
    a = shape.split()[-1].point(lambda v: alpha if v else 0)
    sh.paste((0, 0, 0, 255), (pad, pad + dy), a)
    sh = sh.filter(ImageFilter.GaussianBlur(blur))
    canvas.paste(sh, (int(xy[0] - pad), int(xy[1] - pad)), sh)
    canvas.paste(shape, (int(xy[0]), int(xy[1])), shape)


def load_logo(path):
    logo = Image.open(path).convert("RGBA")
    box = logo.split()[-1].point(lambda v: 255 if v > 20 else 0).getbbox()
    return logo.crop(box) if box else logo


def is_light(logo):
    small = logo.resize((48, 48))
    raw = small.tobytes()
    px = [tuple(raw[i:i + 4]) for i in range(0, len(raw), 4) if raw[i + 3] > 128]
    if not px:
        return False
    return sum(0.299 * r + 0.587 * g + 0.114 * b for r, g, b, a in px) / len(px) > 215


# ---------------------------------------------------------------- data
def parse_date(raw):
    raw = (raw or "").strip()
    for f in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d %H:%M:%S", "%d-%b-%Y", "%b %d, %Y"):
        try:
            return datetime.strptime(raw, f)
        except ValueError:
            pass
    return None


def format_time(raw, style):
    raw = (raw or "").strip()
    for f in ("%H:%M", "%H:%M:%S", "%I:%M %p", "%I:%M%p"):
        try:
            t = datetime.strptime(raw.upper(), f)
            if style == "24h":
                return t.strftime("%H:%M")
            return t.strftime("%I:%M %p").lstrip("0")
        except ValueError:
            pass
    return raw


def score(v):
    try:
        return int(float(str(v).strip()))
    except (ValueError, TypeError):
        return None


def game_no(row):
    try:
        return int(float(row.get("Game #", "0")))
    except ValueError:
        return 0


def safe(s):
    return "".join(c for c in (s or "") if c.isalnum() or c in "-_") or "X"


def name_lines(draw, text, max_w, k):
    """Fit a team name on one line, or split it over two lines if one line gets too small."""
    f = fit(draw, text, oswald, max_w, 48 * k, min_size=int(26 * k))
    if f.size >= 40 * k or " " not in text:
        return [text], f
    words = text.split()
    best = min(range(1, len(words)), key=lambda i: abs(len(" ".join(words[:i])) - len(" ".join(words[i:]))))
    lines = [" ".join(words[:best]), " ".join(words[best:])]
    f = min((fit(draw, ln, oswald, max_w, 44 * k, min_size=int(24 * k)) for ln in lines), key=lambda x: x.size)
    return lines, f


# ---------------------------------------------------------------- drawing
class Card:
    def __init__(self, cfg, cfg_dir, size):
        self.cfg, self.cfg_dir = cfg, cfg_dir
        self.W, self.H = size
        self.k = self.W / 1080
        self.primary = hex_rgb(cfg.get("primary_color"), (18, 53, 91))
        self.accent = hex_rgb(cfg.get("accent_color"), (228, 87, 46))
        self.deep = shade(self.primary, 0.55)
        self.on_accent = ink_on(self.accent, self.deep)
        self.photos = []
        folder = cfg.get("photo_folder")
        if folder:
            folder = os.path.join(cfg_dir, folder)
            if os.path.isdir(folder):
                self.photos = sorted(os.path.join(folder, f) for f in os.listdir(folder)
                                     if f.lower().endswith(PHOTO_EXT))
            else:
                print(f"note: photo folder not found ({folder}), using the plain background")

    # background -------------------------------------------------
    def background(self, n):
        W, H, k = self.W, self.H, self.k
        img = Image.new("RGB", (W, H), self.primary)
        grad = Image.new("L", (1, H))
        for y in range(H):
            grad.putpixel((0, y), int(255 * (y / H) ** 1.3))
        img = Image.composite(Image.new("RGB", (W, H), self.deep), img, grad.resize((W, H)))

        if self.photos:
            ph = cover(Image.open(self.photos[(n - 1) % len(self.photos)]).convert("RGB"), W, H)
            img = ph
            ov = Image.new("L", (1, H))
            for y in range(H):
                ov.putpixel((0, y), int(150 + 95 * (y / H) ** 1.2))
            img = Image.composite(Image.new("RGB", (W, H), self.deep), img, ov.resize((W, H)))
            d = ImageDraw.Draw(img, "RGBA")
        else:
            d = ImageDraw.Draw(img, "RGBA")
            # wide diagonal light stripes on the right
            lite = shade(self.primary, 1.18)
            for i, a in enumerate((70, 45, 28)):
                x0 = int(W * 0.55) + i * int(170 * k)
                d.polygon([(x0, H), (x0 + int(110 * k), H), (x0 + int(110 * k) + H, 0), (x0 + H, 0)],
                          fill=lite + (a,))
            # handball court goal area lines, bottom right
            cx, cy = int(W * 0.98), int(H * 0.86)
            for r, wd in ((int(430 * k), 5), (int(640 * k), 3)):
                d.arc([cx - r, cy - r, cx + r, cy + r], 90, 270, fill=(255, 255, 255, 38), width=int(wd * k))
            d.ellipse([cx - int(95 * k), cy - int(95 * k), cx + int(95 * k), cy + int(95 * k)],
                      outline=(255, 255, 255, 30), width=int(4 * k))
        # speed lines
        for i, a in enumerate((70, 45, 28)):
            y0 = int(H * 0.50) + i * int(60 * k)
            d.line([(0, y0 + int(300 * k)), (int(W * 0.7), y0 - int(300 * k))], fill=(255, 255, 255, a // 2),
                   width=max(2, int(3 * k)))
        # accent band with curved lower edge, top left
        bh = self.band_h
        curve = bezier((0, bh), (W * 0.42, bh * 0.78), (W * 0.98, 0))
        d.polygon([(0, 0), (W * 0.98, 0)] + curve[::-1], fill=self.accent)
        d.line(bezier((0, bh + 34 * k), (W * 0.45, bh * 0.82 + 30 * k), (W * 1.04, 0)),
               fill=(255, 255, 255, 170), width=max(2, int(4 * k)))
        return img

    # badge ------------------------------------------------------
    def badge(self, short, color, logo_path, d_px):
        b = Image.new("RGBA", (d_px, d_px), (0, 0, 0, 0))
        bd = ImageDraw.Draw(b)
        ring = max(4, int(d_px * 0.035))
        if logo_path and os.path.isfile(logo_path):
            logo = load_logo(logo_path)
            bd.ellipse([0, 0, d_px - 1, d_px - 1], fill=self.deep if is_light(logo) else WHITE)
            inner = int(d_px * 0.62)
            logo.thumbnail((inner, inner), Image.LANCZOS)
            b.alpha_composite(logo, ((d_px - logo.width) // 2, (d_px - logo.height) // 2))
            bd.ellipse([0, 0, d_px - 1, d_px - 1], outline=self.accent, width=ring)
            return b
        tbd = short.upper() in ("TBD", "")
        fill = (110, 120, 135) if tbd else color
        bd.ellipse([0, 0, d_px - 1, d_px - 1], fill=WHITE)
        bd.ellipse([ring, ring, d_px - 1 - ring, d_px - 1 - ring], fill=fill)
        inset = int(d_px * 0.10)
        bd.ellipse([inset, inset, d_px - 1 - inset, d_px - 1 - inset], outline=shade(fill, 1.25) if luminance(fill) < 0.5 else shade(fill, 0.85),
                   width=max(2, int(d_px * 0.012)))
        txt = (short or "TBD").upper()
        f = fit(bd, txt, anton, d_px * 0.64, d_px * 0.36)
        bd.text((d_px / 2, d_px / 2), txt, font=f, fill=ink_on(fill, (20, 24, 32)), anchor="mm")
        return b

    # main -------------------------------------------------------
    def render(self, row, csv_dir, results, out_path):
        W, H, k = self.W, self.H, self.k
        cfg = self.cfg
        story = H / W > 1.5
        self.band_h = int((330 if story else 290) * k)
        n = game_no(row)
        img = self.background(n)
        d = ImageDraw.Draw(img, "RGBA")
        M = int(64 * k)

        # tournament name on the accent band (or a logo file if configured)
        name = (cfg.get("tournament_name") or "").upper()
        edition = (cfg.get("edition") or "").upper()
        tlogo = cfg.get("tournament_logo")
        tlogo = os.path.join(self.cfg_dir, tlogo) if tlogo else None
        top = int(56 * k)
        if tlogo and os.path.isfile(tlogo):
            lg = load_logo(tlogo)
            lg.thumbnail((int(560 * k), int(150 * k)), Image.LANCZOS)
            img.paste(lg, (M, top), lg)
        else:
            nf = fit(d, name, anton, W * 0.62, 84 * k)
            d.text((M, top), name, font=nf, fill=self.on_accent, anchor="lt")
            if edition:
                ef = oswald(28 * k)
                y = top + nf.size * 1.22 + 22 * k
                spaced(d, (M, y), edition, ef, self.on_accent, 5 * k)

        # layout zones
        foot_h = int(96 * k)
        panel_h = int(170 * k)
        panel_y = H - foot_h - int(46 * k) - panel_h
        zone_top = self.band_h + int((70 if story else 18) * k)
        zone_bot = panel_y - int(36 * k)

        sa, sb = score(row.get("Score A")), score(row.get("Score B"))
        has_score = results and sa is not None and sb is not None
        head_size = (150 if has_score else 190) * k
        badge_d = int((250 if has_score else 340) * k)
        headline = (cfg.get("results_headline") or "FINAL SCORE") if has_score else (cfg.get("live_headline") or "LIVE MATCH")
        lines = [headline.upper()]
        if story:
            badge_d = int(badge_d * 1.12)
            head_size = (215 if has_score else 250) * k
            lines = headline.upper().split(None, 1) or [""]
        col_w = W / 2 - M - 20 * k
        names = {}
        for side in ("A", "B"):
            t = (row.get(f"Team {side}") or row.get(f"Short {side}") or "TBD").upper()
            names[side] = name_lines(d, t, col_w, k)
        two = any(len(v[0]) > 1 for v in names.values())
        name_h = int((98 if two else 54) * k)
        score_h = int(170 * k) if has_score else 0
        gap1 = int((40 if has_score else 56) * k)
        gap2, gap3 = int((22 if has_score else 30) * k), int(12 * k)
        line_gap = int(24 * k)
        head_h = int(head_size * 0.80) * len(lines) + line_gap * (len(lines) - 1)
        block = head_h + gap1 + badge_d + gap2 + name_h + (gap3 + score_h if has_score else 0)
        y = zone_top + max(0, (zone_bot - zone_top - block) // 2)

        # headline
        hf = min((fit(d, ln, anton, W - 2 * M, head_size) for ln in lines), key=lambda f: f.size)
        lh = int(hf.size * 0.80)
        ly = y + (head_h - (lh * len(lines) + line_gap * (len(lines) - 1))) // 2
        for ln in lines:
            ly += lh
            hatched_text(img, (W / 2, ly), ln, hf, self.accent, anchor="ms")
            ly += line_gap
        d = ImageDraw.Draw(img, "RGBA")
        y += head_h + gap1

        # badges + VS
        cxa, cxb = int(W * 0.25), int(W * 0.75)
        teams = (("A", cxa), ("B", cxb))
        for side, cx in teams:
            logo = (row.get(f"Logo {side}") or "").strip()
            lp = None
            if logo:
                base = os.path.join(self.cfg_dir, cfg["logo_folder"]) if cfg.get("logo_folder") else csv_dir
                lp = logo if os.path.isabs(logo) else os.path.join(base, logo)
                if not os.path.isfile(lp):
                    print(f"  note: logo not found for game {n}: {logo} (using badge)")
            col = hex_rgb(row.get(f"Color {side}"), self.accent if side == "A" else shade(self.primary, 1.35))
            b = self.badge(row.get(f"Short {side}", ""), col, lp, badge_d)
            drop_shadow(img, b, (cx - badge_d // 2, y), blur=int(18 * k), alpha=120, dy=int(10 * k))
        cy = y + badge_d // 2
        r = int(50 * k)
        d.line([(cxa + badge_d // 2 + 14 * k, cy), (cxb - badge_d // 2 - 14 * k, cy)], fill=self.accent + (255,), width=int(6 * k))
        d.ellipse([W / 2 - r, cy - r, W / 2 + r, cy + r], fill=self.deep, outline=WHITE, width=max(3, int(4 * k)))
        d.text((W / 2, cy - 2 * k), "VS", font=oswald(44 * k), fill=WHITE, anchor="mm")
        y += badge_d + gap2

        # team names
        for side, cx in teams:
            lines_, f = names[side]
            step = f.size * 1.12
            ty = y + name_h / 2 - step * (len(lines_) - 1) / 2
            for ln in lines_:
                d.text((cx, ty), ln, font=f, fill=WHITE, anchor="mm")
                ty += step
        y += name_h

        # scores
        if has_score:
            y += gap3
            sf = anton(score_h)
            win_a, win_b = sa > sb, sb > sa
            for (side, cx), val, win in ((teams[0], sa, win_a), (teams[1], sb, win_b)):
                colr = self.accent if win else (255, 255, 255, 255 if sa == sb else 165)
                d.text((cx, y + score_h), str(val), font=sf, fill=colr, anchor="ms")
            d.text((W / 2, y + score_h * 0.62), ":", font=anton(score_h * 0.6), fill=(255, 255, 255, 140), anchor="mm")

        # info panel
        px0, px1 = M, W - M
        d.rounded_rectangle([px0, panel_y, px1, panel_y + panel_h], radius=int(26 * k),
                            fill=self.deep + (235,), outline=(255, 255, 255, 120), width=max(2, int(3 * k)))
        label = f"GAME {n:02d}"
        pf = anton(66 * k)
        pw = d.textlength(label, font=pf) + 64 * k
        pill_y0, pill_y1 = panel_y + 26 * k, panel_y + panel_h - 26 * k
        d.rounded_rectangle([px0 + 24 * k, pill_y0, px0 + 24 * k + pw, pill_y1], radius=int(20 * k), fill=self.accent)
        d.text((px0 + 24 * k + pw / 2, (pill_y0 + pill_y1) / 2), label, font=pf, fill=self.on_accent, anchor="mm")
        tx = px0 + 24 * k + pw + 34 * k
        tw = px1 - 28 * k - tx
        line1 = "  |  ".join(v for v in ((row.get("Division") or "").upper(), (row.get("Round") or "").upper()) if v)
        if has_score:
            line1 = (line1 + "  |  FULL TIME") if line1 else "FULL TIME"
        dt = parse_date(row.get("Date"))
        day = (row.get("Day") or (dt.strftime("%a") if dt else "")).upper()[:3]
        date_txt = dt.strftime("%b %d").upper().replace(" 0", " ") if dt else (row.get("Date") or "").upper()
        when = " ".join(v for v in (day, date_txt) if v)
        time_txt = format_time(row.get("Time"), cfg.get("time_format", "12h"))
        court = (row.get("Court") or "").strip()
        court_txt = court.upper() if court.upper().startswith("COURT") else (f"COURT {court}".upper() if court else "")
        line2 = "   ".join(v for v in (when, time_txt, court_txt) if v)
        f1 = fit(d, line1, oswald, tw, 40 * k, min_size=int(22 * k))
        f2 = fit(d, line2, oswald, tw, 40 * k, min_size=int(22 * k))
        mid = panel_y + panel_h / 2
        d.text((tx, mid - 8 * k), line1, font=f1, fill=self.accent, anchor="ls")
        d.text((tx, mid + 10 * k), line2, font=f2, fill=WHITE, anchor="lt")

        # footer
        fy = H - foot_h
        d.rectangle([0, fy, W, H], fill=self.deep)
        d.rectangle([0, fy, W, fy + max(3, int(6 * k))], fill=self.accent)
        ff = oswald(30 * k)
        url = (cfg.get("website_url") or "").replace("https://", "").replace("http://", "").rstrip("/")
        foot = cfg.get("footer_text") or ""
        uw = d.textlength(url, font=ff) if url else 0
        ftf = fit(d, foot, oswald, W - 2 * M - uw - 40 * k, 30 * k, min_size=int(18 * k))
        d.text((M, fy + foot_h / 2 + 3 * k), foot, font=ftf, fill=WHITE, anchor="lm")
        if url:
            d.text((W - M, fy + foot_h / 2 + 3 * k), url, font=ff, fill=self.accent, anchor="rm")

        img.convert("RGB").save(out_path, quality=92)


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description="Make match cards from a games CSV.")
    ap.add_argument("--csv", required=True, help="games CSV exported from the workbook")
    ap.add_argument("--config", required=True, help="config.json with name, colors, footer")
    ap.add_argument("--out", default="cards", help="output folder (default: cards)")
    ap.add_argument("--results", action="store_true", help="make final score cards for games with a score")
    ap.add_argument("--story", action="store_true", help="1080x1920 story size instead of the post size")
    ap.add_argument("--game", type=int, help="only this game number")
    a = ap.parse_args()

    with open(a.config, encoding="utf-8") as f:
        cfg = json.load(f)
    cfg_dir = os.path.dirname(os.path.abspath(a.config))
    csv_dir = os.path.dirname(os.path.abspath(a.csv))
    size = tuple(cfg.get("story_size", [1080, 1920])) if a.story else tuple(cfg.get("output_size", [1080, 1350]))
    card = Card(cfg, cfg_dir, size)
    os.makedirs(a.out, exist_ok=True)

    made = skipped = 0
    with open(a.csv, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            row = {(kk or "").strip(): (vv or "").strip() for kk, vv in row.items()}
            n = game_no(row)
            if not n or (a.game and n != a.game):
                continue
            if a.results and (score(row.get("Score A")) is None or score(row.get("Score B")) is None):
                skipped += 1
                continue
            kind = "final" if a.results else "live"
            name = f"G{n:02d}_{safe(row.get('Short A'))}_{safe(row.get('Short B'))}_{kind}{'_story' if a.story else ''}.png"
            card.render(row, csv_dir, a.results, os.path.join(a.out, name))
            print("wrote", name)
            made += 1
    msg = f"done: {made} card(s) in {a.out}"
    if skipped:
        msg += f", {skipped} game(s) skipped because they have no score yet"
    print(msg)
    if not made:
        sys.exit(1)


if __name__ == "__main__":
    main()

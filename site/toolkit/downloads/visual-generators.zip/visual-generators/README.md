# Visual generators: match cards and event poster

Status: Built and tested with sample data. Not yet used in a live tournament.

This folder has two small tools that make tournament graphics for you, in your own colors, from your own schedule.

| Tool | What it makes | Typical use |
|---|---|---|
| `make_match_cards.py` | One image per game (1080x1350 post, or 1080x1920 story) | "Live match" posts before each game, "Final score" posts after |
| `make_poster.py` | A print ready poster (11x17 inch or A3) as a PDF, plus a JPG preview | Schools, gyms, libraries, coffee shops |

Look in `sample_output/` to see what they produce with the fictional "Bay Classic 2027" sample data.

## What is in this folder

* `make_match_cards.py` and `make_poster.py`: the two tools
* `sample/config.json`: your tournament name, colors, footer, website and poster text
* `sample/games_sample.csv`: a small example schedule
* `fonts/`: two free fonts (Anton and Oswald, SIL Open Font License, see `fonts/LICENSE.txt`)
* `requirements.txt`: the three Python add ons the tools need
* `sample_output/`: example results

## Step 1: Install Python (one time)

**Windows**
1. Go to python.org, click Downloads, and install the latest Python 3.
2. On the first screen of the installer, tick **"Add python.exe to PATH"**. This matters.
3. Open the Start menu, type `cmd`, and open **Command Prompt**.

**Mac**
1. Go to python.org, click Downloads, and install the latest Python 3.
2. Open **Terminal** (press Cmd + Space, type Terminal, press Enter).

## Step 2: Install the add ons (one time)

Move into this folder. The easiest way: type `cd ` (with a space), then drag the `visual-generators` folder onto the window, then press Enter.

Windows:
```
py -m pip install -r requirements.txt
```
Mac:
```
python3 -m pip install -r requirements.txt
```

## Step 3: Try it with the sample data

Windows (use `py`), Mac (use `python3`):
```
py make_match_cards.py --csv sample/games_sample.csv --config sample/config.json
py make_match_cards.py --csv sample/games_sample.csv --config sample/config.json --results
py make_poster.py --config sample/config.json
```
Cards go into a new `cards` folder. Posters go into a new `posters` folder.

## Step 4: Use your own tournament

### Edit config.json
Open `sample/config.json` in any text editor (Notepad, TextEdit) and change the values between quotes. Keep the quotes and commas.

| Setting | What it does |
|---|---|
| `tournament_name`, `edition` | Shown at the top of every card and poster |
| `primary_color`, `accent_color` | Your two brand colors as hex codes, for example `#12355B` |
| `footer_text`, `website_url` | Bottom strip of each card. The poster QR code opens `website_url` |
| `photo_folder` | Optional. A folder of action photos (next to config.json). Each card gets one, darkened so text stays readable. Leave empty for the clean graphic background |
| `logo_folder` | Optional. Where team logo files live. If empty, logo paths are read relative to the CSV file |
| `tournament_logo` | Optional. A PNG of your tournament logo to use instead of the name text |
| `output_size`, `story_size` | Image sizes in pixels. Defaults are 1080x1350 and 1080x1920 |
| `time_format` | `12h` (5:00 PM) or `24h` (17:00) |
| `live_headline`, `results_headline` | The big words on the cards |
| `poster` section | Headline lines, subline, day tiles, "Free entry" line, venue, extra lines, QR label, host line, optional `hero_photo` and `logos` (up to two, shown in the footer) |

If the poster has no `days`, it shows the `dates` line in a single white bar instead.

### Export the schedule to CSV
Do not add columns to the workbook. The website starter's converter reads the Tournament Master Template (saved in Excel first) and writes the CSV for you, with team names, short names and jersey colors joined from Teams Master:

1. Open a terminal in the `website-starter` folder (install its requirements once with `py -m pip install -r tools/requirements.txt`).
2. Run the converter with the `--cards-csv` flag:
```
py tools/workbook_to_site.py path/to/Tournament_Master_Template.xlsx --cards-csv my_games.csv
```
   It writes `my_games.csv` with these columns: `Game #, Date, Day, Time, Court, Division, Round, Team A, Team B, Short A, Short B, Color A, Color B, Logo A, Logo B, Score A, Score B`. Playoff games with unknown teams show TBD. Scores are filled in only for Final games. Court stays empty (the template schedules one court), so cards show only the day and time. It also refreshes the website data file, which is harmless.
3. Run this tool with your files:
```
py make_match_cards.py --csv my_games.csv --config my_config.json --out cards
```
Run the converter again after each result, then use `--results` (see below) for the final score cards.

### Useful options
| Add this | Result |
|---|---|
| `--results` | Final score cards, only for games where Score A and Score B are filled in. The winner's score is shown in the accent color |
| `--story` | 1080x1920 story size for Instagram or WhatsApp status |
| `--game 12` | Only game 12 (handy during the event) |
| `--out folder_name` | Choose where the images go |
| `--size A3` or `--size both` | Poster paper size (default 11x17) |

### Team logos
Put the logo files (PNG with a transparent background works best) in a folder, and write the file name in `Logo A` / `Logo B`, for example `harbor.png`. Any game without a logo gets a clean colored circle with the short name, so you can start without logos and add them later. White logos are placed on a dark circle automatically.

### Printing the poster
The PDF includes a 0.125 inch bleed on every side, which is what print shops ask for. Tell them "11x17 with bleed, trim marks set in the PDF". Keep the JPG preview for email and social media.

## Change the look with an AI assistant

You do not need to know Python. Open Claude, ChatGPT or a similar assistant, then:

1. Paste the whole script (open `make_match_cards.py` in a text editor, select all, copy).
2. Attach one of the images from `sample_output/` so it can see the current look.
3. Ask for one change at a time, for example:
   * "Here is a Python script that makes match card images. Move the game number pill to the top right and make the team names larger. Give me the full updated script."
   * "Add a sponsor logo in the bottom left of every card. The file is sponsor.png in the same folder."
   * "On the poster, replace the day tiles with one line per day, and add a Spanish subline under the headline."
4. Save the answer over the old file (keep a copy of the original first), run it again, and look at the result.

Tip: if something breaks, paste the error message back to the assistant and ask it to fix the script.

## Limitations
* Graphics are images, not editable design files. To change wording, edit the config or CSV and run the tool again.
* Long team names are shrunk, then split over two lines. Past about 35 characters they get small, so use a shorter display name in the CSV if needed.
* Photos are picked in order from the photo folder (game 1 gets the first photo, and so on). There is no face detection, so choose photos where the action is near the center.
* Only Latin characters are covered by the included fonts.

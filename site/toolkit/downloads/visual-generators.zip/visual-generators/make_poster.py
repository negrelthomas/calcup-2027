"""Event poster generator for handball tournaments.

Makes a print ready poster (PDF with 0.125 inch bleed) plus a JPG preview,
using the same config.json as the match cards (see the "poster" section).
  python make_poster.py --config sample/config.json
  python make_poster.py --config sample/config.json --size A3
  python make_poster.py --config sample/config.json --size both --out posters

Sizes: 11x17 (US tabloid, default), A3, or both. 300 dpi.
The QR code points to "website_url" in the config.
Requires Python 3, Pillow, qrcode and reportlab (pip install -r requirements.txt).
"""
import argparse, io, json, os
import qrcode
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops
from reportlab.pdfgen import canvas as pdfcanvas
from reportlab.lib.utils import ImageReader

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.path.join(HERE, "fonts")
WHITE = (255, 255, 255)
DPI = 300
BLEED = round(0.125 * DPI)  # 38 px at 300 dpi
SIZES = {"11x17": (3300, 5100), "A3": (3508, 4961)}  # trim size in pixels at 300 dpi


# ---------------------------------------------------------------- helpers
def hex_rgb(value, fallback):
    v = (value or "").strip().lstrip("#")
    if len(v) == 3:
        v = "".join(c * 2 for c in v)
    try:
        return tuple(int(v[i:i + 2], 16) for i in (0, 2, 4))
    except (ValueError, IndexError):
        return fallback


def shade(c, f):
    if f <= 1:
        return tuple(int(x * f) for x in c)
    return tuple(int(x + (255 - x) * (f - 1)) for x in c)


def luminance(c):
    def ch(x):
        x /= 255
        return x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(x) for x in c)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def ink_on(bg, dark):
    def con(a, b):
        la, lb = sorted((luminance(a), luminance(b)), reverse=True)
        return (la + 0.05) / (lb + 0.05)
    return WHITE if con(bg, WHITE) >= con(bg, dark) else dark


def font(name, size):
    return ImageFont.truetype(os.path.join(FONT_DIR, name), max(8, int(size)))


def anton(s):
    return font("anton-400.ttf", s)


def oswald(s):
    return font("oswald-700.ttf", s)


def fit(d, text, maker, max_w, start, min_size=10):
    s = int(start)
    while s > min_size and d.textlength(text, font=maker(s)) > max_w:
        s -= 3
    return maker(s)


def bez(p0, p1, p2, n=120):
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0],
             (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1])
            for t in [i / n for i in range(n + 1)]]


def cover(img, w, h, fx=0.5, fy=0.4):
    s = max(w / img.width, h / img.height)
    img = img.resize((round(img.width * s), round(img.height * s)), Image.LANCZOS)
    x, y = int((img.width - w) * fx), int((img.height - h) * fy)
    return img.crop((x, y, x + w, y + h))


def hatched(canvas, xy, text, fnt, color, anchor="ls"):
    W, H = canvas.size
    m = Image.new("L", canvas.size, 0)
    ImageDraw.Draw(m).text(xy, text, font=fnt, fill=255, anchor=anchor)
    box = m.getbbox()
    if not box:
        return
    fill = Image.new("RGB", canvas.size, color)
    hd = ImageDraw.Draw(fill)
    dk = shade(color, 0.88)
    step = max(9, W // 210)
    for x in range(box[0] - (box[3] - box[1]) - step, box[2] + step, step):
        hd.line([(x, box[3]), (x + (box[3] - box[1]), box[1])], fill=dk, width=max(2, step // 4))
    canvas.paste(fill, (0, 0), m)


def rcard(w, h, r, fill=WHITE):
    c = Image.new("RGBA", (int(w), int(h)), (0, 0, 0, 0))
    ImageDraw.Draw(c).rounded_rectangle([0, 0, int(w) - 1, int(h) - 1], radius=int(r), fill=fill)
    return c


def shadow_paste(img, card, xy, k):
    pad = int(90 * k)
    sh = Image.new("RGBA", (card.width + 2 * pad, card.height + 2 * pad), (0, 0, 0, 0))
    a = card.split()[-1].point(lambda v: 120 if v else 0)
    sh.paste((0, 0, 0, 255), (pad, pad + int(20 * k)), a)
    sh = sh.filter(ImageFilter.GaussianBlur(30 * k))
    img.paste(sh, (int(xy[0]) - pad, int(xy[1]) - pad), sh)
    img.paste(card, (int(xy[0]), int(xy[1])), card)


def load_logo(path):
    logo = Image.open(path).convert("RGBA")
    box = logo.split()[-1].point(lambda v: 255 if v > 20 else 0).getbbox()
    return logo.crop(box) if box else logo


def is_light(logo):
    """True for white or near white logos that would vanish on a white card."""
    raw = logo.resize((48, 48)).tobytes()
    px = [raw[i:i + 3] for i in range(0, len(raw), 4) if raw[i + 3] > 128]
    if not px:
        return False
    return sum(0.299 * r + 0.587 * g + 0.114 * b for r, g, b in px) / len(px) > 215


# ---------------------------------------------------------------- poster
class Poster:
    def __init__(self, cfg, cfg_dir):
        self.cfg, self.p, self.dir = cfg, cfg.get("poster", {}), cfg_dir
        self.primary = hex_rgb(cfg.get("primary_color"), (18, 53, 91))
        self.accent = hex_rgb(cfg.get("accent_color"), (228, 87, 46))
        self.deep = shade(self.primary, 0.55)
        self.on_accent = ink_on(self.accent, self.deep)

    def path(self, rel):
        if not rel:
            return None
        p = rel if os.path.isabs(rel) else os.path.join(self.dir, rel)
        if os.path.isfile(p):
            return p
        print(f"note: file not found, skipped: {rel}")
        return None

    def render(self, TW, TH):
        """Return the full bleed image. Trim area starts at (BLEED, BLEED)."""
        cfg, p = self.cfg, self.p
        b = BLEED
        CW, CH = TW + 2 * b, TH + 2 * b
        k = min(TW / 3300, TH / 5100)
        X = lambda v: b + v          # trim space to canvas space
        M = int(150 * k)             # safe margin inside trim
        img = Image.new("RGB", (CW, CH), self.primary)
        grad = Image.new("L", (1, CH))
        for y in range(CH):
            grad.putpixel((0, y), int(255 * (y / CH) ** 1.4))
        img = Image.composite(Image.new("RGB", (CW, CH), self.deep), img, grad.resize((CW, CH)))
        d = ImageDraw.Draw(img, "RGBA")

        # hero: photo on the right, or a geometric handball motif
        hero = self.path(p.get("hero_photo"))
        if hero:
            pw, phh = int(CW * 0.80), int(CH * 0.60)
            ph = cover(Image.open(hero).convert("RGB"), pw, phh,
                       float(p.get("hero_focus_x", 0.5)), float(p.get("hero_focus_y", 0.3)))
            mask = Image.new("L", (pw, phh), 255)
            md = ImageDraw.Draw(mask)
            fx = int(pw * 0.42)
            for xx in range(fx):
                md.line([(xx, 0), (xx, phh)], fill=int(255 * (xx / fx) ** 1.6))
            m2 = Image.new("L", (pw, phh), 255)
            m2d = ImageDraw.Draw(m2)
            fy = int(phh * 0.32)
            for yy in range(fy):
                m2d.line([(0, phh - fy + yy), (pw, phh - fy + yy)], fill=int(255 * (1 - yy / fy) ** 1.3))
            img.paste(ph, (CW - pw, int(CH * 0.05)), ImageChops.multiply(mask, m2))
            d = ImageDraw.Draw(img, "RGBA")
        else:
            lite = shade(self.primary, 1.16)
            # big stylized ball, partly off the right edge (seams clipped to the ball)
            cx, cy, r = X(int(TW * 0.88)), X(int(TH * 0.42)), int(1000 * k)
            w = int(16 * k)
            layer = Image.new("RGBA", (CW, CH), (0, 0, 0, 0))
            ld = ImageDraw.Draw(layer)
            ld.ellipse([cx - r, cy - r, cx + r, cy + r], fill=lite + (70,))
            for ox, oy in ((-1.25, 0), (1.25, 0), (0, -1.25), (0, 1.25)):
                rr = int(r * 0.95)
                ex, ey = cx + ox * r, cy + oy * r
                ld.ellipse([ex - rr, ey - rr, ex + rr, ey + rr], outline=(255, 255, 255, 38), width=w)
            clip = Image.new("L", (CW, CH), 0)
            ImageDraw.Draw(clip).ellipse([cx - r, cy - r, cx + r, cy + r], fill=255)
            layer.putalpha(ImageChops.multiply(layer.split()[-1], clip))
            ImageDraw.Draw(layer).ellipse([cx - r, cy - r, cx + r, cy + r], outline=(255, 255, 255, 46), width=w)
            img.paste(layer, (0, 0), layer)
            d = ImageDraw.Draw(img, "RGBA")
            # court goal area lines, lower right
            gx, gy = X(TW + int(40 * k)), X(int(TH * 0.70))
            for rr, ww in ((int(1150 * k), 14), (int(1700 * k), 9)):
                d.arc([gx - rr, gy - rr, gx + rr, gy + rr], 90, 270, fill=(255, 255, 255, 30), width=int(ww * k))
        # speed lines
        for i, a in enumerate((110, 70, 40)):
            y0 = X(int(TH * 0.40)) + i * int(90 * k)
            d.line([(0, y0 + int(380 * k)), (int(CW * 0.55), y0 - int(380 * k))],
                   fill=(255, 255, 255, a // 2), width=max(3, int(5 * k)))

        # accent band top left with tournament name or logo
        bw, bh = CW * 0.97, CH * 0.20
        d.polygon([(0, 0), (bw, 0)] + bez((bw, 0), (CW * 0.45, CH * 0.085), (0, bh)), fill=self.accent)
        d.line(bez((CW * 1.03, 0), (CW * 0.47, CH * 0.098), (0, bh + 60 * k)), fill=(255, 255, 255, 180),
               width=max(4, int(10 * k)))
        logos = [x for x in (self.path(l) for l in p.get("logos", [])) if x]
        tlogo = self.path(cfg.get("tournament_logo"))
        top = X(int(150 * k))
        if tlogo:
            lg = load_logo(tlogo)
            lg.thumbnail((int(1500 * k), int(520 * k)), Image.LANCZOS)
            img.paste(lg, (X(M), top), lg)
        else:
            name = (cfg.get("tournament_name") or "").upper()
            nf = fit(d, name, anton, TW * 0.52, 250 * k)
            d.text((X(M), top), name, font=nf, fill=self.on_accent, anchor="lt")
            ed = (cfg.get("edition") or "").upper()
            if ed:
                d.text((X(M) + int(6 * k), top + int(nf.size * 1.25) + int(30 * k)), "  ".join(ed.split()),
                       font=oswald(84 * k), fill=self.on_accent, anchor="lt")

        # ---- vertical flow below the band
        foot_h = int(250 * k)
        lines = [s.upper() for s in p.get("headline", ["LIVE", "HAND", "BALL"]) if s] or ["HANDBALL"]
        hs = int(520 * k) if len(lines) <= 3 else int(1500 * k / len(lines))
        days = p.get("days") or []
        qs = int(560 * k)
        start = X(int(TH * 0.225))
        end = X(TH - foot_h - int(110 * k))
        while True:
            hfont = min((fit(d, ln, anton, TW * (0.62 if hero else 0.66), hs) for ln in lines), key=lambda f: f.size)
            line_h = int(hfont.size * 1.05)
            blocks = self.blocks(lines, line_h, days, qs, k)
            if start + sum(h for _, h in blocks) + int(370 * k) <= end or hs < 150 * k:
                break
            hs = int(hs * 0.95)
        used = sum(h for _, h in blocks)
        gaps = [int(60 * k), int(80 * k), int(60 * k), int(60 * k), int(110 * k)]
        spare = max(0, (end - start) - used - sum(gaps))
        gaps = [g + spare // len(gaps) for g in gaps]
        y = start
        x0, x1 = X(M), X(TW - M)
        self._draw_blocks(img, d, blocks, gaps, y, x0, x1, hfont, line_h, lines, days, qs, k)
        d = ImageDraw.Draw(img, "RGBA")
        self.footer(img, d, CW, CH, b, k, foot_h, logos)
        return img

    def blocks(self, lines, line_h, days, qs, k):
        p = self.p
        return [
            ("headline", line_h * len(lines)),
            ("subline", int(110 * k) if p.get("subline") else 0),
            ("free", int(250 * k) if p.get("free_entry") else 0),
            ("open", int(100 * k) if p.get("open_line") else 0),
            ("days", int(540 * k) if days else (int(200 * k) if p.get("dates") else 0)),
            ("venue", qs + int(72 * k) + int(110 * k)),
        ]

    def _draw_blocks(self, img, d, blocks, gaps, y, x0, x1, hfont, line_h, lines, days, qs, k):
        p = self.p
        for i, (kind, h) in enumerate(blocks):
            if not h:
                continue
            if kind == "headline":
                yy = y
                for ln in lines:
                    yy += int(hfont.size * 0.80)
                    hatched(img, (x0 - int(10 * k), yy), ln, hfont, self.accent)
                    yy += line_h - int(hfont.size * 0.80)
                d = ImageDraw.Draw(img, "RGBA")
            elif kind == "subline":
                t = p["subline"].upper()
                d.text((x0, y + h / 2), t, font=fit(d, t, oswald, x1 - x0, 96 * k), fill=WHITE, anchor="lm")
            elif kind == "free":
                t = p["free_entry"].upper()
                ff = fit(d, t, anton, x1 - x0 - int(160 * k), 190 * k)
                pw = d.textlength(t, font=ff) + int(160 * k)
                d.rounded_rectangle([x0, y, x0 + pw, y + h], radius=int(40 * k), fill=self.accent)
                d.text((x0 + pw / 2, y + h / 2), t, font=ff, fill=self.on_accent, anchor="mm")
            elif kind == "open":
                t = p["open_line"].upper()
                d.text((x0, y + h / 2), t, font=fit(d, t, oswald, x1 - x0, 92 * k), fill=WHITE, anchor="lm")
            elif kind == "days":
                if days:
                    self.day_tiles(img, d, days, x0, y, x1 - x0, h, k)
                else:
                    card = rcard(x1 - x0, h, int(38 * k))
                    shadow_paste(img, card, (x0, y), k)
                    t = p["dates"].upper()
                    d.text(((x0 + x1) / 2, y + h / 2), t, font=fit(d, t, anton, x1 - x0 - int(120 * k), 150 * k),
                           fill=self.deep, anchor="mm")
            elif kind == "venue":
                qx = x1 - qs - int(72 * k)
                self.venue_box(d, x0, y, qx - x0 - int(50 * k), qs + int(72 * k), k)
                self.qr_block(img, d, qx, y, qs, k)
            y += h + (gaps[i] if i < len(gaps) else 0)

    def day_tiles(self, img, d, days, x0, y0, total_w, th, k):
        n = len(days)
        gap = int(40 * k)
        tw = (total_w - (n - 1) * gap) // n
        for i, day in enumerate(days):
            x = x0 + i * (tw + gap)
            shadow_paste(img, rcard(tw, th, int(38 * k)), (x, y0), k)
            cx = x + tw / 2
            big = (day.get("day") or "").upper()
            d.text((cx, y0 + int(40 * k)), big, font=fit(d, big, anton, tw - int(60 * k), 200 * k), fill=self.deep, anchor="mt")
            dt = (day.get("date") or "").upper()
            d.text((cx, y0 + int(275 * k)), dt, font=fit(d, dt, oswald, tw - int(60 * k), 90 * k), fill=self.accent, anchor="mt")
            note = day.get("note") or ""
            if note:
                pf = fit(d, note, oswald, tw - int(120 * k), 62 * k)
                pw = d.textlength(note, font=pf) + int(60 * k)
                py = y0 + th - int(118 * k)
                d.rounded_rectangle([cx - pw / 2, py, cx + pw / 2, py + int(86 * k)], radius=int(43 * k), fill=self.accent)
                d.text((cx, py + int(43 * k)), note, font=pf, fill=self.on_accent, anchor="mm")

    def venue_box(self, d, x, y, w, h, k):
        p = self.p
        d.rounded_rectangle([x, y, x + w, y + h], radius=int(36 * k), fill=self.deep + (235,),
                            outline=(255, 255, 255, 120), width=max(3, int(6 * k)))
        pad = int(60 * k)
        r = int(46 * k)
        cx, cy = x + pad + r, y + pad + int(70 * k)
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=self.accent)
        d.polygon([(cx - r * 0.75, cy + r * 0.55), (cx + r * 0.75, cy + r * 0.55), (cx, cy + r * 2.0)], fill=self.accent)
        d.ellipse([cx - r * 0.38, cy - r * 0.38, cx + r * 0.38, cy + r * 0.38], fill=self.deep)
        tx = cx + r + int(45 * k)
        tw = x + w - pad - tx
        name = (p.get("venue_name") or "").upper()
        nf = fit(d, name, anton, tw, 130 * k)
        d.text((tx, y + pad), name, font=nf, fill=WHITE)
        addr = p.get("venue_address") or ""
        af = fit(d, addr, oswald, tw, 66 * k)
        ay = y + pad + int(nf.size * 1.30)
        d.text((tx, ay), addr, font=af, fill=self.accent)
        extra = p.get("extra_lines") or []
        ef = oswald(60 * k)
        ly = y + h - pad - len(extra) * int(84 * k)
        for ln in extra:
            d.text((tx, ly), ln, font=fit(d, ln, oswald, tw, 60 * k), fill=WHITE)
            ly += int(84 * k)

    def qr_block(self, img, d, x, y, size, k):
        url = self.cfg.get("website_url") or ""
        pad = int(36 * k)
        shadow_paste(img, rcard(size + 2 * pad, size + 2 * pad, int(36 * k)), (x, y), k)
        if url:
            q = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_Q, border=0, box_size=20)
            q.add_data(url)
            q.make(fit=True)
            im = q.make_image(fill_color=self.deep, back_color="white").convert("RGB")
            img.paste(im.resize((size, size), Image.NEAREST), (x + pad, y + pad))
        lbl = (self.p.get("qr_label") or "Scan for schedule").upper()
        lf = fit(d, lbl, oswald, size + 2 * pad - int(40 * k), 52 * k)
        lw = d.textlength(lbl, font=lf) + int(60 * k)
        cx, ly = x + (size + 2 * pad) / 2, y + size + 2 * pad + int(26 * k)
        d.rounded_rectangle([cx - lw / 2, ly, cx + lw / 2, ly + int(80 * k)], radius=int(40 * k), fill=self.accent)
        d.text((cx, ly + int(40 * k)), lbl, font=lf, fill=self.on_accent, anchor="mm")

    def footer(self, img, d, CW, CH, b, k, fh, logos):
        y = CH - b - fh
        d.rectangle([0, y, CW, CH], fill=self.deep)
        d.rectangle([0, y, CW, y + max(4, int(10 * k))], fill=self.accent)
        M = b + int(150 * k)
        mid = y + (fh + b) / 2 - b / 2
        side_w = 0
        slots = [(M, "l"), (CW - M, "r")]
        for lp, (sx, side) in zip(logos[:2], slots):
            lg = load_logo(lp)
            lg.thumbnail((int(420 * k), int(150 * k)), Image.LANCZOS)
            card = rcard(lg.width + int(40 * k), lg.height + int(30 * k), int(14 * k),
                         shade(self.primary, 0.8) if is_light(lg) else WHITE)
            card.paste(lg, (int(20 * k), int(15 * k)), lg)
            cx = sx if side == "l" else sx - card.width
            img.paste(card, (int(cx), int(mid - card.height / 2)), card)
            side_w = max(side_w, card.width)
        avail = CW - 2 * M - 2 * (side_w + int(60 * k) if side_w else 0)
        host = self.p.get("host_line") or self.cfg.get("footer_text") or ""
        url = (self.cfg.get("website_url") or "").replace("https://", "").replace("http://", "").rstrip("/")
        if host:
            d.text((CW / 2, mid - int(40 * k)), host, font=fit(d, host, oswald, avail, 68 * k), fill=WHITE, anchor="mm")
        if url:
            d.text((CW / 2, mid + int(50 * k)), url, font=fit(d, url, oswald, avail, 60 * k), fill=self.accent, anchor="mm")


# ---------------------------------------------------------------- output
def save(img, TW, TH, base):
    b = BLEED
    rgb = img.convert("RGB")
    buf = io.BytesIO()
    rgb.save(buf, "JPEG", quality=95, dpi=(DPI, DPI))
    buf.seek(0)
    pt = 72 / DPI
    CW, CH = rgb.size
    c = pdfcanvas.Canvas(base + ".pdf", pagesize=(CW * pt, CH * pt))
    c.setTitle(os.path.basename(base))
    c.drawImage(ImageReader(buf), 0, 0, width=CW * pt, height=CH * pt)
    c.setBleedBox([0, 0, CW * pt, CH * pt])
    c.setTrimBox([b * pt, b * pt, (b + TW) * pt, (b + TH) * pt])
    c.showPage()
    c.save()
    pv = rgb.crop((b, b, b + TW, b + TH))
    pv.thumbnail((1100, 1700), Image.LANCZOS)
    pv.save(base + "_preview.jpg", quality=88)


def main():
    ap = argparse.ArgumentParser(description="Make a print ready event poster.")
    ap.add_argument("--config", required=True, help="config.json with a poster section")
    ap.add_argument("--size", default="11x17", choices=["11x17", "A3", "both"])
    ap.add_argument("--out", default="posters", help="output folder (default: posters)")
    a = ap.parse_args()
    with open(a.config, encoding="utf-8") as f:
        cfg = json.load(f)
    poster = Poster(cfg, os.path.dirname(os.path.abspath(a.config)))
    os.makedirs(a.out, exist_ok=True)
    stem = cfg.get("poster", {}).get("file_name") or "Poster"
    for sz in (["11x17", "A3"] if a.size == "both" else [a.size]):
        TW, TH = SIZES[sz]
        base = os.path.join(a.out, f"{stem}_{sz}")
        save(poster.render(TW, TH), TW, TH, base)
        print(f"wrote {base}.pdf and {base}_preview.jpg")


if __name__ == "__main__":
    main()

# Tournament Website Starter

A small website for your handball tournament: home page, schedule, standings, top scorers, teams, event info and a live stream page. It works well on phones.

The site is plain files. There is nothing to install to view it and no build step. All the tournament data comes from one file, `data/data.js`, which a small converter script creates from your workbook. The website computes standings and top scorers by itself from the games and goals.

## Status

Built and tested end to end with mock data. Not yet used in a live tournament.

The GitHub workflow (Level 3) is built and tested with mock data, not yet used in a live tournament. Its steps were run locally; the workflow itself has not run on GitHub yet.

## The workbook it expects

The converter reads the toolkit's **Tournament Master Template** (`Tournament_Master_Template.xlsx`). Keep its tab names and column headers as they are. It reads only these tabs:

| Tab | What the site takes from it |
|---|---|
| Control Panel | The tournament name (title cell) |
| Inputs | Tournament Start Date, Venue Name / Location |
| Past Winners | The edition number (one more than the last "Edition n" column) |
| Teams Master | Team name, Short Name, Division, Group Code, host team (Reg Status), and the Team Styles table (Short Name, Jersey Home) for team colors |
| Games Schedule | Game number, date, time, division, group or playoff place, teams, scores, referees, and the "URLs to share" box |
| Rosters Master | Players: team, jersey number, first and last name |
| Individuals Stats Men, Individuals Stats Women | Goals per player per game |

It never reads Registration 2027, Officials Contacts, the volunteer tabs, Medical Staff Master, Referees Master or any contact column (email, phone, WhatsApp). The site is public.

How the workbook maps to the site:

* Team IDs are the Short Names (for example HAR, HARW). Colors come from Jersey Home in Team Styles (color names such as Navy or Sky Blue, or hex codes such as `#12355B`).
* Group games show as "Group A", "Group B". A division with a single group (the women in the 8M+4W format) shows as "Round robin". Playoff games are named from the place they decide: "Final", "3rd place", "5th place", "7th place".
* Playoff teams stay TBD on the site until every group game of that division has a score. The workbook already fills in provisional names from the live standings; the site waits so nobody reads them as confirmed.
* A game is Final as soon as both scores are entered on Games Schedule.
* In Individuals Stats, "Game 1", "Game 2" and so on are each team's own games in schedule order (Game # order). For example, a team that plays games 2, 8 and 15 has those as its Game 1, 2 and 3. The playoff game is the last one.
* Points (win, draw, loss) come from the Points formula on Games Schedule (2, 1, 0 in the template).

## Important: save the workbook in Excel first

The template is built from formulas. The converter reads the **calculated values**, which only exist after a spreadsheet program has calculated and saved the file.

* Open the workbook in Excel (or Google Sheets, then download it as .xlsx) and save it before every run.
* If you run the converter on a file that was never saved by Excel, it stops with: "Open the workbook in Excel or Google Sheets and save it first; the converter reads calculated values."
* The template uses newer Excel functions (FILTER, SORT, XLOOKUP). Use Excel 2021 or Microsoft 365, or Google Sheets. LibreOffice cannot calculate the schedule.

## What is in this folder

| Item | What it is |
|---|---|
| `index.html`, `schedule.html`, `standings.html`, `scorers.html`, `teams.html`, `history.html`, `info.html`, `watch.html` | The pages |
| `assets/styles.css` | The look of the site |
| `assets/app.js` | Reads the data and draws each page |
| `assets/logos/` | Put team logo files here (optional) |
| `data/data.js` | The tournament data. Created by the converter. Never edit it by hand. |
| `tools/workbook_to_site.py` | The converter: workbook in, `data/data.js` out |
| `tools/requirements.txt` | What the converter needs (openpyxl) |
| `netlify.toml` | Netlify settings |
| `.github/workflows/update-site.yml` | Optional automation for Level 3 |
| `refquiz.html`, `flashcards.html`, `assets/refquiz.js`, `assets/quiz.css`, `data/ihf_rules_catalogue_2025.js` | Referee rules quiz and flashcards (IHF Catalogue of Rules Questions 2025) |
| `vote.html`, `vote-admin.html`, `assets/vote.js` | MVP and MVG voting pages |
| `ack.html`, `ack-admin.html`, `assets/ack.js` | Head coach confirmation of the technical document |
| `netlify/functions/leaderboard.mjs`, `netlify/functions/vote.mjs`, `netlify/functions/ack.mjs` | Server side of the quiz leaderboard, the vote and the coach confirmation |
| `workbook/` | Level 3 only: where the workbook goes in a private repository |


## Referee quiz and flashcards

`refquiz.html` is a timed rules quiz: 15 questions per round, 15 to 45 seconds each depending on length, one question per rule, some with more than one correct answer. `flashcards.html` shows all 430 questions grouped by rule, to study before playing.

All questions come from the IHF Catalogue of Rules Questions 2025 (valid from 1 July 2025) with the official answer key, text unchanged. Use only the Catalogue: a national referee found errors in the questions we had first written ourselves, which is why CalCup moved to it. Credit the IHF wherever the questions appear (the pages already do).

The quiz has a public leaderboard (`netlify/functions/leaderboard.mjs`, Netlify Blobs, no setup needed). The browser reports its own score, so a determined player can fake one. Play it for fun; do not attach a prize to it unless you add verified sign in and server side scoring. To clear the board, add `QUIZ_RESET_TOKEN` in Netlify (Site configuration, Environment variables) and open `/.netlify/functions/leaderboard?reset=YOUR_TOKEN`. To close the board at a set time, add `"quizClose": "2027-02-14T12:00:00-08:00"` to meta in the converter output.

Status: the same quiz runs on the CalCup 2027 site; this copy is tested with mock data.

Both the leaderboard and the vote run as Netlify Functions. Functions deploy when the site is connected to GitHub (Level 3) or published with the Netlify CLI; a drag and drop upload to Netlify Drop publishes the pages but not the functions, so the quiz then keeps scores on each phone only and the vote does not work.

## History page (Hall of Champions)

`history.html` lists past champions, runners up, third place, MVP, MVG and top scorer per division and year. The converter reads them from the workbook Past Winners tab: one block per division (a row with DIVISION in column B and "Edition n (year)" labels to the right), then one row per result. Add a column for each new edition after the tournament.

* Build the record from sources you can check: engraved trophy plates, past event reports, official results and photos. CalCup rebuilt its Hall of Champions this way.
* Leave a cell empty when the result is not known. The page shows "Not on record". Never fill a gap with a guess.
* End a name with "?" when a source suggests it but you have not confirmed it. The page shows it with "to confirm", and you remove the "?" once confirmed.
* Add a contact line inviting corrections and photos from past players. Former players are the best source for early editions.

## MVP and MVG voting (needs the website)

The vote follows the rules of the master workbook (Voters Master and MVP Voting tabs):

* Voters: each team's Official A (the head coach on the game sheet) and every referee, as individuals. Both come from the published data: Official A from Rosters Master (Role / Official column), referees from the names on Games Schedule. A team with no Official A on the roster has no ballot, and the admin page says so.
* Awards per division: MVP (field players only) and MVG (goalkeepers, Position = GK on Rosters Master).
* Each voter ranks up to three players per award: 3, 2 and 1 points. Nobody can vote for their own team; a person who coaches two teams cannot vote for players of either team. Ties are broken on the number of 1st choices, then 2nd choices; a remaining tie is flagged for the organizer.

How it is secured:

* Every voter receives a personal ballot link, signed on the server. A link cannot be guessed or edited into someone else's.
* One ballot per voter, final once submitted. Every check (eligibility, own team, position, duplicates) and the count run on the server.
* Voting stays closed until you open it, and closes when you click Close or at the time you set.
* "Start a new round" makes every earlier link and ballot stop counting (use it after a test).
* A forwarded link votes in that person's name, so send each link directly to its owner.

Setup (about 15 minutes):

1. In Netlify, Site configuration, Environment variables, add `VOTE_ADMIN_TOKEN` with a long random value (16 characters or more). Keep it private: it opens the admin page and signs the links. Redeploy once.
2. Open `/vote-admin.html`, paste the token, click Load. Check the voter list against your game sheets.
3. Download the ballot links (CSV) and send each person their link by email or text. An AI assistant connected to your mailbox can prepare one draft per voter from that CSV for you to review and send.
4. On the last day: click Open voting, and set the closing time to the start of the first final, so the count is ready well before the ceremony.
5. After the closing time: click Results. Download the ballots CSV and paste the choices into the MVP Voting tab of the workbook, so the workbook stays your record.

Status: built and tested with mock data (forged links, own team votes, goalkeepers on the MVP ballot, duplicates and second ballots are refused). Not yet used live.

## Head coach confirmation of the technical document (needs the website)

Each team's head coach (Official A on the Rosters Master) confirms on the site, before the team's first game, that they have read the current version of your technical document (rules, rosters, bonds, schedule) and that the team accepts it. A technical meeting reaches only the people in the room; this reaches every team and leaves a record.

How it works:
* Set up is the same as the vote: VOTE_ADMIN_TOKEN in Netlify, and a deploy from GitHub or the Netlify CLI (Netlify Drop does not run functions).
* Open `/ack-admin.html`, enter the token, and publish a version: title, version number (for example 1.0) and a link to the document (a PDF on your site or a shared link).
* The admin page lists every team with its head coach, first game, status and a personal link. Send each link from your own mailbox. Nothing is sent by the site.
* The coach opens the link, reads the document, types their name and ticks the confirmation. The admin page shows the name and the time.
* When you change the document, publish a new version number. Every team then shows "Older version" and the coach confirms again with the same link.
* The Reminder column shows which reminder is due: 7 days, 3 days and 1 day before each team's first game, then a last call on game day. "Copy reminder" gives a ready message with the team's link; "Download pending teams" gives all of them in a CSV for a mail merge.

Without a website, ask for a reply to a fixed email or a signature on the check in sheet. Tested with mock data, not yet used live.

## One time setup for the converter

1. Install Python 3 from python.org (tick "Add Python to PATH" on Windows).
2. Open a terminal in this folder and run:

```
pip install -r tools/requirements.txt
```

## Level 2: update by hand and drag to Netlify Drop

This is the simplest way. No accounts other than a free Netlify account.

1. After each game, enter the result in the workbook: Score Team A and Score Team B on Games Schedule, and each scorer's goals in that team's Game column on Individuals Stats Men or Individuals Stats Women. Save the workbook in Excel.
2. Run the converter from this folder:

```
python tools/workbook_to_site.py path/to/Tournament_Master_Template.xlsx
```

   It writes `data/data.js` and prints a short summary (teams, games, final games, goals). If it prints warnings (for example goals that do not add up to the score), the site is still updated. Fix the workbook when you have a minute and run it again.
3. Go to app.netlify.com/drop and drag this whole folder onto the page. The first time, Netlify gives you a web address. Later, open your site in Netlify, go to Deploys, and drag the folder onto the deploy area to update the same address.

Keep your workbook outside this folder for Level 2, so it is never uploaded.

## Level 3: automatic updates with GitHub and Netlify

With this setup you only upload the workbook. GitHub runs the converter and Netlify publishes the new results within a minute or two.

1. Create a **private** repository on GitHub and upload the contents of this folder. It must be private because the workbook contains contact details (Registration 2027, Teams Master, Rosters Master and other tabs).
2. In the repository, go to Settings, then Actions, then General. Under Workflow permissions choose "Read and write permissions" and save.
3. In Netlify, choose "Add new site", then "Import an existing project", and pick the repository. There is no build command. The publish directory is the repository root (already set in `netlify.toml`).
4. Upload your workbook into the `workbook/` folder of the repository (keep only one .xlsx file there). You can do this in the GitHub website with "Add file", then "Upload files". Upload the file as saved by Excel, never a copy that was not opened and saved.
5. The workflow in `.github/workflows/update-site.yml` runs the converter and commits a new `data/data.js`. Netlify sees the commit and redeploys.

To post a new result: enter it in the workbook, save it in Excel, upload it again to `workbook/` (replace the old file), and wait a minute or two. You can watch progress on the Actions tab in GitHub. If the converter stops (for example a workbook without calculated values), the run shows a red cross and the site keeps the previous results. `netlify.toml` blocks the `workbook/` and `tools/` folders from being served on the public site.

## Optional settings

The template has no cells for these. Add a row on Inputs with the label in column B and the value in column C, then run the converter again:

| Label on Inputs | Effect |
|---|---|
| `Contact email` | Shown on the Info page (use a general address, never a personal one) |
| `Venue address` | Street address on the Info page and in the map link. Without it, the text after the first comma of Venue Name / Location is used |
| `Stream URL` | The Watch page link. Without it, the "Live Streaming" link from the "URLs to share" box on Games Schedule is used |
| `Primary color`, `Accent color` | Hex codes such as `#12355B`. Default: `#12355B` and `#E4572E` |

YouTube links (watch, live, youtu.be) are shown inside the Watch page. Any other link (Facebook, Twitch and so on) is shown as a button that opens the stream. If there is no link, the Watch page says the link is not posted yet. The site picks black or white header text automatically so it stays readable.

## Add team logos

1. Save each logo as a PNG or SVG file, ideally square, under 200 KB.
2. Put the files in `assets/logos/`.
3. Add a `Logo` column to the Team Styles table on Teams Master and type the file name for each team (for example `harbor.png`).
4. Run the converter again.

If a logo is missing, the team card shows a colored badge with the short name instead.

## QR code tip

Make a QR code that points to your site address and print it on the schedule, at the check in desk and on the scoreboard table. Most phone cameras open it directly. Test it on two phones before printing. Point it at the home page so it keeps working all weekend.

## How standings are computed

* Only Final games count (both scores entered).
* Only group stage games count: "Group A", "Group B" or "Round robin". Playoff games do not count.
* Points come from the workbook (win 2, draw 1, loss 0 in the template).
* Order: points, then goal difference, then goals for. This matches the Rankings tab. If teams are still tied, apply the head to head result by hand and announce it.
* One table per group. A division with a single group gets one table for the division.

Top scorers list the top 20 players per division, from Individuals Stats. Players tied on goals are listed by last name, so the first name shown can differ from the Stats & MVP tab, which keeps roster order for ties.

## Match cards

The visual generators (`make_match_cards.py`) make one image per game for social media. The converter writes the games CSV they need, straight from the workbook:

```
python tools/workbook_to_site.py path/to/Tournament_Master_Template.xlsx --cards-csv games_cards.csv
```

Team names, short names and jersey colors come from Teams Master. Playoff games with unknown teams are kept and show TBD. Scores are filled in only for Final games. The Court column stays empty because the template schedules one court. Then, from the visual generators folder:

```
python make_match_cards.py --csv games_cards.csv --config my_config.json
python make_match_cards.py --csv games_cards.csv --config my_config.json --results
```

## Lessons learned

* Keep this site folder out of OneDrive, Dropbox and Google Drive sync. Sync tools can lock files or upload half written files, which breaks updates. Keep the workbook wherever you like, but keep the site folder in a normal local folder (or in GitHub for Level 3).
* Never edit `data/data.js` by hand. Your changes are overwritten the next time the converter runs. Change the workbook instead.
* Always save in Excel before converting. A file that was only edited by another tool may hold old or missing calculated values.
* The converter warns instead of stopping when the data has a problem. A typo should not keep results off the site during the event. Read the warnings and clean up between games.
* Do the whole update loop once before the tournament: enter a fake result, save, convert, publish, check it on your phone, then undo it.

## Converter reference

```
python tools/workbook_to_site.py path/to/workbook.xlsx [--out data/data.js] [--cards-csv games_cards.csv]
```

It finds columns by their header names, so moving a column is fine, but renaming a header or a tab is not: the converter then stops with an error that names the tab and the header it could not find. One exception: the playoff place column on Games Schedule (1 for the final, 3 for 3rd place...) has no header in the template and is read as the column right after "Gr.".

Warnings (the file is still written): a team name in the schedule that is not a Short Name in Teams Master, a game with only one score, a jersey color name it does not know, players in Individuals Stats who are not on Rosters Master, goals entered for a game without a final score, and goals that do not add up to a team's score.

## Test locally

Open a terminal in this folder and run `python -m http.server 8000`, then open http://localhost:8000 in your browser.

// Head coach confirmation of the technical document.
//
// Each team's Official A (head coach) confirms, before the team's first game, that they have
// read the current version of the technical document (rules, rosters, bonds, schedule).
// The organizer sets the document version and link on /ack-admin.html, sees the status of
// every team, and copies reminder messages for the teams still to confirm. Nothing is sent
// from here: reminders go from the organizer's own mailbox or phone.
//
// Security:
//   * Every team gets a personal link signed with a key derived from VOTE_ADMIN_TOKEN (the same
//     Netlify environment variable as the vote), so links cannot be forged or guessed.
//   * A new document version does not change the links. Confirmations of an older version stay
//     on record but no longer count: the coach confirms the new version with the same link.
//   * Coach names come from the published rosters (data/data.js). No email is stored here.

import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";
import { parseDataJs, normalize } from "./vote.mjs";

const STORE = "coachack";

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } });
}
const fail = (msg, status = 400) => json({ error: msg }, status);

function adminToken() { const t = process.env.VOTE_ADMIN_TOKEN || ""; return t.length >= 16 ? t : null; }
function signKey() { const t = adminToken(); return t ? crypto.createHmac("sha256", t).update("ack-links-v1").digest() : null; }
const b64u = (buf) => Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const unb64u = (s) => Buffer.from(String(s).replace(/-/g, "+").replace(/_/g, "/"), "base64");

export function makeToken(teamId) {
  const body = b64u(JSON.stringify({ team: teamId }));
  return body + "." + b64u(crypto.createHmac("sha256", signKey()).update(body).digest()).slice(0, 32);
}
export function readToken(token) {
  const k = signKey();
  if (!k || typeof token !== "string" || token.length > 300) return null;
  const [body, mac] = token.split(".");
  if (!body || !mac) return null;
  const want = b64u(crypto.createHmac("sha256", k).update(body).digest()).slice(0, 32);
  const a = Buffer.from(mac), b = Buffer.from(want);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try { const p = JSON.parse(unb64u(body).toString("utf8")); return p && typeof p.team === "string" ? p : null; } catch (e) { return null; }
}
function isAdmin(given) {
  const t = adminToken();
  if (!t || typeof given !== "string") return false;
  return crypto.timingSafeEqual(crypto.createHash("sha256").update(given).digest(), crypto.createHash("sha256").update(t).digest());
}

/* Teams with their head coach (Official A) and first game, from the published data file. */
export function teamList(D) {
  const model = normalize(D);
  const coach = {};
  model.voters.forEach((v) => { if (v.team && !coach[v.team]) coach[v.team] = v.name; });
  const first = {};
  (D.games || []).forEach((g) => {
    [g.a, g.b].forEach((tid) => {
      if (!tid || !model.teams[tid] || !g.date) return;
      const key = g.date + " " + (g.time || "00:00");
      if (!first[tid] || key < first[tid].key) first[tid] = { key, date: g.date, time: g.time || "", no: g.no };
    });
  });
  return {
    event: model.name,
    teams: Object.values(model.teams).filter((t) => !/^tbd/i.test(t.id)).map((t) => ({
      id: t.id, name: t.name, div: t.div, coach: coach[t.id] || "",
      firstGame: first[t.id] ? { date: first[t.id].date, time: first[t.id].time, no: first[t.id].no } : null
    })).sort((a, b) => (a.div > b.div ? 1 : a.div < b.div ? -1 : a.name.localeCompare(b.name)))
  };
}
async function loadTeams(origin) {
  const res = await fetch(origin + "/data/data.js?v=" + Date.now(), { headers: { "Cache-Control": "no-cache" } });
  if (!res.ok) throw new Error("data.js " + res.status);
  return teamList(parseDataJs(await res.text()));
}
async function getConfig(store) {
  const c = (await store.get("config", { type: "json" })) || {};
  return { version: c.version || "", docUrl: c.docUrl || "", docTitle: c.docTitle || "Technical document" };
}
async function allRecords(store) {
  const { blobs } = await store.list({ prefix: "a/" });
  const out = [];
  for (const b of blobs) { const v = await store.get(b.key, { type: "json" }); if (v) out.push(v); }
  return out;
}
const recKey = (version, team) => "a/" + encodeURIComponent(version) + "/" + team;

export default async (req) => {
  const origin = new URL(req.url).origin;
  if (req.method !== "POST") return fail("Use POST.", 405);
  if (!signKey()) return fail("Not set up yet: VOTE_ADMIN_TOKEN is missing on the server (16 characters or more).", 503);
  const body = await req.json().catch(() => null);
  if (!body || typeof body.action !== "string") return fail("Bad request.");
  const store = getStore(STORE);
  try {
    /* ----- head coach ----- */
    if (body.action === "doc" || body.action === "confirm") {
      const tok = readToken(body.t);
      if (!tok) return fail("This link is not valid. Use the link you received, without changes.", 403);
      const L = await loadTeams(origin);
      const team = L.teams.find((t) => t.id === tok.team);
      if (!team) return fail("This team is no longer on the team list. Please contact the organizer.", 403);
      const cfg = await getConfig(store);
      if (!cfg.version) return fail("The technical document is not published yet. Keep this link: it will work once it is.", 409);
      const key = recKey(cfg.version, team.id);
      const existing = await store.get(key, { type: "json" });
      if (body.action === "doc") {
        const older = (await allRecords(store)).filter((r) => r.team === team.id && r.version !== cfg.version).sort((a, b) => (a.ts < b.ts ? 1 : -1))[0] || null;
        return json({ event: L.event, team: { name: team.name, div: team.div, coach: team.coach, firstGame: team.firstGame }, doc: cfg, confirmed: existing, older: older ? { version: older.version, ts: older.ts } : null });
      }
      if (existing) return json({ ok: true, record: existing });
      if (body.agree !== true) return fail("Tick the confirmation box first.");
      if (body.version !== cfg.version) return fail("The document was updated while this page was open. Reload the page and read the new version.", 409);
      const name = String(body.name || "").trim().slice(0, 80);
      if (name.length < 3) return fail("Type your full name.");
      const record = { team: team.id, teamName: team.name, name, version: cfg.version, ts: new Date().toISOString() };
      try { await store.setJSON(key, record, { onlyIfNew: true }); } catch (e) { if (!(await store.get(key, { type: "json" }))) await store.setJSON(key, record); }
      return json({ ok: true, record: (await store.get(key, { type: "json" })) || record });
    }

    /* ----- organizer ----- */
    if (!isAdmin(body.token)) return fail("Wrong organizer token.", 403);
    let cfg = await getConfig(store);
    if (body.action === "setdoc") {
      const version = String(body.version || "").trim().slice(0, 20);
      const docUrl = String(body.docUrl || "").trim().slice(0, 500);
      if (!version) return fail("Enter a version, for example 1.0.");
      if (docUrl && !/^https?:\/\/|^\/|^[\w.-]+\.(pdf|html)$/i.test(docUrl)) return fail("The document link should start with https:// or point to a file on this site.");
      cfg = { version, docUrl, docTitle: String(body.docTitle || "Technical document").trim().slice(0, 80) || "Technical document" };
      await store.setJSON("config", cfg);
    }
    const L = await loadTeams(origin);
    const recs = await allRecords(store);
    const teams = L.teams.map((t) => {
      const cur = recs.find((r) => r.team === t.id && r.version === cfg.version) || null;
      const old = recs.filter((r) => r.team === t.id && r.version !== cfg.version).sort((a, b) => (a.ts < b.ts ? 1 : -1))[0] || null;
      return { ...t, link: origin + "/ack.html?t=" + makeToken(t.id), confirmed: cur, older: old ? { version: old.version, ts: old.ts, name: old.name } : null };
    });
    return json({ event: L.event, doc: cfg, teams });
  } catch (e) {
    return fail("Server error: " + (e && e.message ? e.message : "unknown"), 500);
  }
};

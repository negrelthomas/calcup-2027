// MVP and MVG voting for the tournament website.
//
// Who votes: each team's Official A (head coach on the game sheet) and every referee,
// as individuals. Rules follow the master workbook (Voters Master and MVP Voting tabs):
//   MVP = field players only, MVG = goalkeepers only, one ballot per division and award,
//   1st, 2nd and 3rd choice worth 3, 2 and 1 points, no vote for one's own team (a person who
//   coaches two teams cannot vote for players of either team, on either ballot),
//   ties broken on the number of 1st choices, then flagged for the organizer.
//
// Security:
//   * Every voter gets a personal ballot link. The link is signed with a key derived from
//     the VOTE_ADMIN_TOKEN environment variable, so it cannot be forged or guessed.
//   * One ballot per voter, final once submitted. Scoring and every check run here, on the
//     server; nothing the browser sends is trusted.
//   * Voting is closed until the organizer opens it, and closes on demand or at a set time.
//   * Starting a new round invalidates every link and every ballot of the previous round.
//   * The candidate lists come from the published rosters (data/data.js); voter emails are
//     never stored here.
//
// Setup: in Netlify, Site configuration > Environment variables, add VOTE_ADMIN_TOKEN
// (any long random text, 16 characters or more). Then open /vote-admin.html.

import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

const STORE = "mvpvote";
const AWARDS = [
  { id: "mvp", label: "MVP", sub: "Most valuable player, field players only", gk: false },
  { id: "mvg", label: "MVG", sub: "Most valuable goalkeeper", gk: true }
];
const POINTS = [3, 2, 1];
const DIV_LABEL = { M: "Men", W: "Women", Men: "Men", Women: "Women" };

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }
  });
}
const fail = (msg, status = 400) => json({ error: msg }, status);

/* ---------- signing ---------- */
function adminToken() {
  const t = process.env.VOTE_ADMIN_TOKEN || "";
  return t.length >= 16 ? t : null;
}
function signKey() {
  const t = adminToken();
  return t ? crypto.createHmac("sha256", t).update("ballot-links-v1").digest() : null;
}
const b64u = (buf) => Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const unb64u = (s) => Buffer.from(String(s).replace(/-/g, "+").replace(/_/g, "/"), "base64");

export function makeToken(voterId, round) {
  const body = b64u(JSON.stringify({ v: voterId, r: round }));
  const mac = b64u(crypto.createHmac("sha256", signKey()).update(body).digest()).slice(0, 32);
  return body + "." + mac;
}
export function readToken(token) {
  const k = signKey();
  if (!k || typeof token !== "string" || token.length > 400) return null;
  const [body, mac] = token.split(".");
  if (!body || !mac) return null;
  const want = b64u(crypto.createHmac("sha256", k).update(body).digest()).slice(0, 32);
  const a = Buffer.from(mac), b = Buffer.from(want);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try { const p = JSON.parse(unb64u(body).toString("utf8")); return (p && typeof p.v === "string" && Number.isInteger(p.r)) ? p : null; }
  catch (e) { return null; }
}
function isAdmin(given) {
  const t = adminToken();
  if (!t || typeof given !== "string") return false;
  const a = crypto.createHash("sha256").update(given).digest();
  const b = crypto.createHash("sha256").update(t).digest();
  return crypto.timingSafeEqual(a, b);
}

/* ---------- tournament data ---------- */
export function parseDataJs(text) {
  const m = /window\.(CALCUP|TOURNAMENT)\s*=\s*/.exec(text);
  if (!m) throw new Error("data.js not recognized");
  const start = m.index + m[0].length, end = text.lastIndexOf("}");
  return JSON.parse(text.slice(start, end + 1));
}
const slug = (s) => String(s).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const isPlaceholder = (s) => !s || /\btbd\b|tbc|assign|^referee\s*\d|^ref\s*\d|\(tbd\)/i.test(s);
const isGK = (pos) => /^\s*(gk|g|goal ?keeper|goalie)\s*$/i.test(pos || "");
const isOfficialA = (s) => /official\s*a\b/i.test(s || "") || /^\s*a\s*$/i.test(s || "");

// Works with the CalCup data model (window.CALCUP) and the toolkit website starter (window.TOURNAMENT).
export function normalize(D) {
  const teams = {};
  (D.teams || []).forEach((t) => { teams[t.id] = { id: t.id, name: t.name || t.id, short: t.short || t.id, div: DIV_LABEL[t.division] || t.division || "Open" }; });
  const players = [], coaches = [];
  if (D.rosters && !Array.isArray(D.rosters)) {
    Object.keys(D.rosters).forEach((tid) => {
      if (!teams[tid]) return;
      (D.rosters[tid] || []).forEach((p) => {
        if (!p || !p.name) return;
        if (p.official) { if (isOfficialA(p.pos)) coaches.push({ team: tid, name: p.name }); return; }
        players.push({ id: tid + "|" + p.name, team: tid, name: p.name, n: p.n, gk: isGK(p.pos) });
      });
    });
  }
  if (Array.isArray(D.players)) {
    D.players.forEach((p) => {
      if (!teams[p.team]) return;
      const name = ((p.first || "") + " " + (p.last || "")).trim() || p.name;
      if (!name) return;
      players.push({ id: String(p.id || p.team + "|" + name), team: p.team, name, n: p.number != null ? p.number : p.n, gk: isGK(p.pos) });
    });
  }
  (D.officials || []).forEach((o) => { if (teams[o.team] && o.name && isOfficialA(o.role)) coaches.push({ team: o.team, name: o.name }); });

  const refNames = new Set();
  (D.referees || []).forEach((r) => {
    const list = Array.isArray(r.refs) ? r.refs : (r.name ? [r.name] : []);
    list.forEach((n) => { n = String(n || "").trim(); if (!isPlaceholder(n)) refNames.add(n); });
  });
  (D.games || []).forEach((g) => {
    String(g.refs || "").split(/\s*(?:\/|&|,|\band\b)\s*/i).forEach((n) => { n = n.trim(); if (!isPlaceholder(n)) refNames.add(n); });
  });

  const divisions = [];
  Object.values(teams).forEach((t) => { if (!divisions.includes(t.div)) divisions.push(t.div); });
  const order = { Men: 0, Women: 1 };
  divisions.sort((a, b) => (order[a] ?? 9) - (order[b] ?? 9));

  const voters = [];
  const seenCoach = new Set();
  coaches.forEach((c) => {
    if (seenCoach.has(c.team)) return; seenCoach.add(c.team);
    voters.push({ id: "c-" + slug(c.team), name: c.name, role: "Official A", team: c.team, teamName: teams[c.team].name, div: teams[c.team].div });
  });
  // A person who coaches several teams cannot vote for players of any of them.
  voters.forEach((v) => { v.excl = voters.filter((w) => w.team && w.name.toLowerCase() === v.name.toLowerCase()).map((w) => w.team); });
  [...refNames].sort().forEach((n) => voters.push({ id: "r-" + slug(n), name: n, role: "Referee", team: null, teamName: "", div: "" }));
  const missingCoach = Object.values(teams).filter((t) => !seenCoach.has(t.id) && !/^tbd/i.test(t.id)).map((t) => t.name);

  return { name: (D.meta && D.meta.name) || "Tournament", teams, players, voters, divisions, missingCoach };
}

export function candidates(model, div, award, voter) {
  return model.players
    .filter((p) => model.teams[p.team].div === div && p.gk === award.gk && !(voter.excl || []).includes(p.team))
    .sort((a, b) => model.teams[a.team].name.localeCompare(model.teams[b.team].name) || (Number(a.n) || 999) - (Number(b.n) || 999))
    .map((p) => ({ id: p.id, label: p.name + (p.n != null && p.n !== "" ? " #" + p.n : ""), team: model.teams[p.team].name }));
}

async function loadModel(origin) {
  const res = await fetch(origin + "/data/data.js?v=" + Date.now(), { headers: { "Cache-Control": "no-cache" } });
  if (!res.ok) throw new Error("data.js " + res.status);
  return normalize(parseDataJs(await res.text()));
}

/* ---------- state ---------- */
async function getConfig(store) {
  const c = (await store.get("config", { type: "json" })) || {};
  return { round: Number.isInteger(c.round) ? c.round : 1, open: !!c.open, closeAt: c.closeAt || null, openedAt: c.openedAt || null };
}
const isOpen = (c) => c.open && (!c.closeAt || Date.now() < Date.parse(c.closeAt));
const ballotKey = (round, voterId) => "b/" + round + "/" + voterId;

async function listBallots(store, round) {
  const { blobs } = await store.list({ prefix: "b/" + round + "/" });
  const out = [];
  for (const b of blobs) { const v = await store.get(b.key, { type: "json" }); if (v) out.push(v); }
  return out;
}

export function tally(model, ballots) {
  const byId = {}; model.players.forEach((p) => { byId[p.id] = p; });
  const results = [];
  model.divisions.forEach((div) => {
    AWARDS.forEach((aw) => {
      const k = div + "|" + aw.id, rows = {};
      let voters = 0;
      ballots.forEach((b) => {
        const picks = (b.picks && b.picks[k]) || [];
        if (picks.length) voters++;
        picks.forEach((pid, i) => {
          const p = byId[pid]; if (!p) return;
          const r = rows[pid] || (rows[pid] = { id: pid, name: p.name, n: p.n, team: model.teams[p.team].name, points: 0, firsts: 0, seconds: 0, thirds: 0 });
          r.points += POINTS[i]; if (i === 0) r.firsts++; else if (i === 1) r.seconds++; else r.thirds++;
        });
      });
      const list = Object.values(rows).sort((a, b) => b.points - a.points || b.firsts - a.firsts || b.seconds - a.seconds || a.name.localeCompare(b.name));
      list.forEach((r, i) => { r.rank = i + 1; });
      const tie = list.length > 1 && list[0].points === list[1].points && list[0].firsts === list[1].firsts;
      results.push({ div, award: aw.id, label: aw.label + " " + div, ballots: voters, rows: list, tieForFirst: tie });
    });
  });
  return results;
}

/* ---------- handler ---------- */
export default async (req) => {
  const url = new URL(req.url);
  const origin = url.origin;
  if (req.method !== "POST") return fail("Use POST.", 405);
  if (!signKey()) return fail("Voting is not set up yet: VOTE_ADMIN_TOKEN is missing on the server (16 characters or more).", 503);
  const body = await req.json().catch(() => null);
  if (!body || typeof body.action !== "string") return fail("Bad request.");
  const store = getStore(STORE);

  try {
    /* ----- voter actions ----- */
    if (body.action === "ballot" || body.action === "submit") {
      const tok = readToken(body.t);
      if (!tok) return fail("This ballot link is not valid. Use the link you received, without changes.", 403);
      const cfg = await getConfig(store);
      if (tok.r !== cfg.round) return fail("This ballot link belongs to an earlier round and is no longer valid.", 403);
      const model = await loadModel(origin);
      const voter = model.voters.find((v) => v.id === tok.v);
      if (!voter) return fail("This ballot link is no longer on the voter list. Please contact the organizer.", 403);
      const key = ballotKey(cfg.round, voter.id);
      const existing = await store.get(key, { type: "json" });

      if (body.action === "ballot") {
        return json({
          event: model.name,
          voter: { name: voter.name, role: voter.role, team: voter.teamName },
          open: isOpen(cfg), closeAt: cfg.closeAt,
          voted: existing ? { ts: existing.ts } : null,
          points: POINTS,
          divisions: model.divisions.map((div) => ({
            div,
            awards: AWARDS.map((aw) => ({ id: aw.id, label: aw.label + " " + div, sub: aw.sub, candidates: candidates(model, div, aw, voter) }))
          }))
        });
      }

      // submit
      if (!isOpen(cfg)) return fail("Voting is closed.", 409);
      if (existing) return fail("Your ballot was already recorded. A ballot is final once submitted.", 409);
      const picksIn = (body.picks && typeof body.picks === "object") ? body.picks : {};
      const picks = {};
      let count = 0;
      for (const div of model.divisions) {
        for (const aw of AWARDS) {
          const k = div + "|" + aw.id;
          const list = Array.isArray(picksIn[k]) ? picksIn[k].filter((x) => typeof x === "string" && x) : [];
          if (!list.length) continue;
          if (list.length > POINTS.length) return fail(aw.label + " " + div + ": at most " + POINTS.length + " choices.");
          if (new Set(list).size !== list.length) return fail(aw.label + " " + div + ": the same player is chosen twice.");
          const allowed = new Set(candidates(model, div, aw, voter).map((c) => c.id));
          for (const pid of list) if (!allowed.has(pid)) return fail(aw.label + " " + div + ": one choice is not eligible (own team, wrong position or not on the roster).");
          picks[k] = list; count++;
        }
      }
      if (!count) return fail("The ballot is empty. Choose at least one player.");
      const record = { voter: voter.id, name: voter.name, role: voter.role, team: voter.teamName, ts: new Date().toISOString(), picks };
      let written = true;
      try {
        const r = await store.setJSON(key, record, { onlyIfNew: true });
        if (r && r.modified === false) written = false;
      } catch (e) {
        if (await store.get(key, { type: "json" })) written = false; else await store.setJSON(key, record);
      }
      if (!written) return fail("Your ballot was already recorded. A ballot is final once submitted.", 409);
      return json({ ok: true, ts: record.ts });
    }

    /* ----- organizer actions ----- */
    if (!isAdmin(body.token)) return fail("Wrong organizer token.", 403);
    let cfg = await getConfig(store);

    if (body.action === "open" || body.action === "close" || body.action === "schedule") {
      if (body.action === "open") { cfg.open = true; cfg.openedAt = new Date().toISOString(); if (cfg.closeAt && Date.parse(cfg.closeAt) <= Date.now()) cfg.closeAt = null; }
      if (body.action === "close") { cfg.open = false; }
      if (body.action === "schedule") {
        if (body.closeAt == null || body.closeAt === "") cfg.closeAt = null;
        else { const t = Date.parse(body.closeAt); if (isNaN(t)) return fail("Closing time not understood."); cfg.closeAt = new Date(t).toISOString(); }
      }
      await store.setJSON("config", cfg);
    }
    if (body.action === "newround") {
      if (body.confirm !== "NEW ROUND") return fail("Type NEW ROUND to confirm.");
      cfg = { round: cfg.round + 1, open: false, closeAt: null, openedAt: null };
      await store.setJSON("config", cfg);
    }

    const model = await loadModel(origin);
    const ballots = await listBallots(store, cfg.round);
    const votedBy = {}; ballots.forEach((b) => { votedBy[b.voter] = b.ts; });
    const voters = model.voters.map((v) => ({
      id: v.id, name: v.name, role: v.role, team: v.teamName,
      link: origin + "/vote.html?t=" + makeToken(v.id, cfg.round),
      voted: votedBy[v.id] || null
    }));
    const out = {
      event: model.name, round: cfg.round, open: isOpen(cfg), openFlag: cfg.open, closeAt: cfg.closeAt,
      voters, ballots: ballots.length, missingCoach: model.missingCoach, points: POINTS
    };
    if (body.action === "results") {
      out.results = tally(model, ballots);
      out.detail = ballots.map((b) => ({ name: b.name, role: b.role, team: b.team, ts: b.ts, picks: b.picks }));
    }
    return json(out);
  } catch (e) {
    return fail("Server error: " + (e && e.message ? e.message : "unknown"), 500);
  }
};

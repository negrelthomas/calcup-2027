#!/usr/bin/env python3
"""Convert the Tournament Master Template workbook into data/data.js for the website.

Usage:
    python tools/workbook_to_site.py path/to/workbook.xlsx [--out data/data.js] [--cards-csv games_cards.csv]

--cards-csv also writes the games CSV used by the visual generators (make_match_cards.py),
with team names, short names and jersey colors joined from Teams Master.

The converter reads CALCULATED values. Open the workbook in Excel (or Google Sheets) and
save it before running the converter, otherwise the formula cells have no values to read.

Tabs read (and only the columns named here):
    Control Panel        title cell (tournament name)
    Inputs               Tournament Start Date, Venue Name / Location (plus any Email or Stream row if you add one)
    Past Winners         "Edition n (year)" headers, to number this edition
    Teams Master         TeamID, Team Name, Short Name, Division, Group Code, Reg Status,
                         and the Team Styles table (Short Name, Jersey Home)
    Games Schedule       Date, Game #, Court Time / Game time, Div., Gr., playoff place column,
                         Code Team A/B, NameTeam A/B, Referees, Score Team A/B, Points Team A,
                         and the "URLs to share" box
    Rosters Master       Team, Type, Jersey, First Name, Last Name, Position, Role / Official (names only)
    Individuals Stats Men / Individuals Stats Women   Team, Jersey #, First Name, Last Name, Game 1..n
Never read: Registration 2027, Officials Contacts, Volunteer tabs, Medical Staff Master,
Referees Master, or any contact column (email, phone, WhatsApp). The site is public.

Problems in the workbook are printed as WARNINGS and the file is still written,
so a small mistake never blocks a results update. A workbook whose structure cannot be
found stops with an error that names the tab and the header.
"""
import argparse
import csv
import datetime as dt
import json
import os
import re
import sys

try:
    from openpyxl import load_workbook
except ImportError:
    sys.exit("openpyxl is missing. Run: pip install -r tools/requirements.txt")

DEFAULT_PRIMARY = "#12355B"
DEFAULT_ACCENT = "#E4572E"
DEFAULT_POINTS = {"win": 2, "draw": 1, "loss": 0}

# Private tabs: the converter refuses to open them, whatever happens.
PRIVATE_TABS = ("registration", "officials contacts", "volunteer", "medical staff", "referees master",
                "gym prep", "referee pickup", "pre-orders", "voters")
# Columns that must never be read, even on tabs we do read.
PRIVATE_HEADER = re.compile(r"e-?mail|phone|whatsapp|contact|address|payment|handle", re.I)

# Jersey color names used in Team Styles, mapped to hex for the site and the cards.
COLOR_NAMES = {
    "navy": "#1F2A5A", "navy blue": "#1F2A5A", "dark blue": "#1F3A93", "blue": "#1565C0", "royal": "#2747B8",
    "royal blue": "#2747B8", "sky blue": "#4FA3E0", "light blue": "#7FB8E6", "teal": "#00897B",
    "turquoise": "#1AA6A6", "green": "#2E7D32", "dark green": "#1B5E20", "lime": "#7CB342", "yellow": "#F2C200",
    "gold": "#C9A227", "orange": "#EF6C00", "red": "#C62828", "maroon": "#7B1E2B", "burgundy": "#7B1E2B",
    "crimson": "#B0122C", "pink": "#D81B60", "purple": "#6A1B9A", "violet": "#7E57C2", "black": "#1A1A1A",
    "gray": "#757575", "grey": "#757575", "silver": "#A7A9AC", "white": "#FFFFFF", "brown": "#6D4C41",
}

warnings = []


class StructureError(Exception):
    pass


def warn(msg):
    warnings.append(msg)


def clean(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


def num(v):
    if v is None or (isinstance(v, str) and not v.strip()):
        return None
    if isinstance(v, bool):
        return "bad"
    try:
        f = float(v)
        return int(f) if f.is_integer() else f
    except (TypeError, ValueError):
        return "bad"


def norm(s):
    return re.sub(r"[^a-z0-9#]+", " ", clean(s).lower()).strip()


def ordinal(n):
    n = int(n)
    suf = "th" if 10 <= n % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return f"{n}{suf}"


def as_date(v):
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    if isinstance(v, (int, float)) and 20000 < v < 80000:  # Excel serial date
        return (dt.datetime(1899, 12, 30) + dt.timedelta(days=float(v))).date()
    s = clean(v)
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d %H:%M:%S"):
        try:
            return dt.datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


def as_time(v):
    if isinstance(v, (dt.time, dt.datetime)):
        return v.strftime("%H:%M")
    if isinstance(v, float) and 0 <= v < 1:  # Excel time fraction
        m = round(v * 24 * 60)
        return f"{m // 60:02d}:{m % 60:02d}"
    s = clean(v)
    m = re.match(r"^(\d{1,2}):(\d{2})", s)
    if m:
        return f"{int(m.group(1)):02d}:{m.group(2)}"
    return s


def color_hex(v, where):
    s = clean(v)
    if not s:
        return ""
    if re.match(r"^#?([0-9a-fA-F]{6}|[0-9a-fA-F]{3})$", s):
        return "#" + s.lstrip("#").upper()
    h = COLOR_NAMES.get(s.lower())
    if not h:
        warn(f"{where}: jersey color '{s}' is not a known color name. Use a hex code such as #12355B. No color used.")
    return h or ""


# ------------------------------------------------------------------ workbook access
class Book:
    def __init__(self, path):
        self.path = path
        self.wb = load_workbook(path, data_only=True, read_only=True)
        self.names = {n.strip().lower(): n for n in self.wb.sheetnames}

    def sheet(self, name, required=True):
        key = name.strip().lower()
        if any(key.startswith(p) for p in PRIVATE_TABS):
            raise RuntimeError(f"Refusing to read private tab '{name}'.")
        if key not in self.names:
            if required:
                raise StructureError(f"Tab '{name}' not found. This converter expects the toolkit's Tournament Master Template.")
            return None
        return self.wb[self.names[key]]


def row_values(ws, row, max_col=60):
    for r in ws.iter_rows(min_row=row, max_row=row, max_col=max_col, values_only=True):
        return list(r)
    return []


def find_header_row(ws, tab, must_have, max_scan=15, max_col=60):
    """Return (row number, header list) of the first row that contains every label in must_have."""
    want = [norm(h) for h in must_have]
    for i, r in enumerate(ws.iter_rows(min_row=1, max_row=max_scan, max_col=max_col, values_only=True), 1):
        labels = [norm(v) for v in r]
        if all(w in labels for w in want):
            return i, [clean(v) for v in r]
    raise StructureError(f"Tab '{tab}': no header row with {', '.join(repr(h) for h in must_have)} in the first {max_scan} rows.")


def col_of(headers, tab, *names, occurrence=1, required=True, start=0):
    """0-based column index of a header (first matching name wins). occurrence=2 finds the second copy."""
    for name in names:
        n = norm(name)
        hits = [i for i, h in enumerate(headers) if i >= start and norm(h) == n]
        if len(hits) >= occurrence:
            if PRIVATE_HEADER.search(headers[hits[occurrence - 1]]):
                raise RuntimeError(f"Refusing to read private column '{headers[hits[occurrence - 1]]}' on '{tab}'.")
            return hits[occurrence - 1]
    if required:
        raise StructureError(f"Tab '{tab}': header {' or '.join(repr(n) for n in names)} not found.")
    return None


def read_cols(ws, first_row, cols, last_row=None):
    """Read only the given 0-based columns, row by row. Other columns (contacts) are never loaded."""
    cols = [c for c in cols if c is not None]
    per_col = {}
    for c in cols:
        vals = []
        for r in ws.iter_rows(min_row=first_row, max_row=last_row, min_col=c + 1, max_col=c + 1, values_only=True):
            vals.append(r[0] if r else None)
        per_col[c] = vals
    n = max((len(v) for v in per_col.values()), default=0)
    out = []
    for i in range(n):
        out.append({c: (per_col[c][i] if i < len(per_col[c]) else None) for c in cols})
    return out


# ------------------------------------------------------------------ cached values check
def check_cached_values(path):
    """The template ships with formulas only. Without a save in Excel there are no values to read."""
    wbv = load_workbook(path, data_only=True, read_only=True)
    wbf = load_workbook(path, data_only=False, read_only=True)
    try:
        if "Games Schedule" not in wbv.sheetnames:
            return None
        formulas = values = 0
        rows_f = wbf["Games Schedule"].iter_rows(min_row=1, max_row=40, max_col=30, values_only=True)
        rows_v = wbv["Games Schedule"].iter_rows(min_row=1, max_row=40, max_col=30, values_only=True)
        for rf, rv in zip(rows_f, rows_v):
            for f, v in zip(rf, rv):
                if (isinstance(f, str) and f.startswith("=")) or type(f).__name__ == "ArrayFormula":
                    formulas += 1
                    if v not in (None, ""):
                        values += 1
        if formulas and values == 0:
            sys.exit("ERROR: this workbook has formulas but no calculated values.\n"
                     "Open the workbook in Excel or Google Sheets and save it first; the converter reads calculated values.")
        # Points formula of the model (Points Team A), e.g. IF(S5>T5,2,IF(S5=T5,1,0))
        for r in wbf["Games Schedule"].iter_rows(min_row=1, max_row=12, max_col=30, values_only=True):
            for f in r:
                if isinstance(f, str):
                    m = re.search(r"IF\(\s*S\d+\s*>\s*T\d+\s*,\s*(\d+)\s*,\s*IF\(\s*S\d+\s*=\s*T\d+\s*,\s*(\d+)\s*,\s*(\d+)\s*\)", f)
                    if m:
                        return {"win": int(m.group(1)), "draw": int(m.group(2)), "loss": int(m.group(3))}
        return None
    finally:
        wbv.close()
        wbf.close()


# ------------------------------------------------------------------ readers
def title_name(raw):
    """'🏆 BAY CLASSIC 2027: CONTROL PANEL' -> 'BAY CLASSIC 2027'."""
    s = re.sub(r"^[^\w]+", "", clean(raw), flags=re.UNICODE)
    s = re.split(r"\s*:\s*", s)[0]
    s = re.sub(r"\s+(CONTROL PANEL|WORKBOOK NAVIGATION|GAME SCHEDULE|MODEL NOTES.*)$", "", s, flags=re.I)
    return s.strip()


def smart_title(s):
    if s != s.upper():
        return s
    return " ".join(w if any(ch.isdigit() for ch in w) else w.capitalize() for w in s.split())


def read_meta(book, points_from_formula):
    meta = {"name": "", "edition": "", "year": "", "host": "", "dates": "", "venue": "", "venueAddress": "",
            "contactEmail": "", "streamUrl": "", "websiteUrl": "", "primaryColor": DEFAULT_PRIMARY,
            "accentColor": DEFAULT_ACCENT}

    # Name: Control Panel title, with the casing of another title cell when one exists.
    cp = book.sheet("Control Panel")
    raw = ""
    for r in cp.iter_rows(min_row=1, max_row=6, max_col=12, values_only=True):
        for v in r:
            if isinstance(v, str) and "control panel" in v.lower():
                raw = v
                break
        if raw:
            break
    if not raw:
        raise StructureError("Tab 'Control Panel': title cell ending in 'CONTROL PANEL' not found.")
    name = title_name(raw)
    for tab in ("Printable Schedule", "Model Notes"):
        ws = book.sheet(tab, required=False)
        if ws is None:
            continue
        for r in ws.iter_rows(min_row=1, max_row=2, max_col=4, values_only=True):
            for v in r:
                if isinstance(v, str) and title_name(v).lower() == name.lower() and title_name(v) != title_name(v).upper():
                    name = title_name(v)
    meta["name"] = smart_title(name)

    # Inputs: label in one column, value in the next.
    ws = book.sheet("Inputs")
    found = {}
    for r in ws.iter_rows(min_row=1, max_row=200, max_col=10, values_only=True):
        for i, v in enumerate(r[:-1]):
            if isinstance(v, str) and v.strip():
                found.setdefault(norm(v), r[i + 1])
    start = None
    for k in ("tournament start date", "start date"):
        if k in found:
            start = as_date(found[k])
    if start is None:
        raise StructureError("Tab 'Inputs': label 'Tournament Start Date' (with a date next to it) not found.")
    meta["year"] = str(start.year)
    venue = ""
    for k in ("venue name location", "venue name", "venue"):
        if k in found and clean(found[k]):
            venue = clean(found[k])
            break
    if not venue:
        warn("Inputs: 'Venue Name / Location' is empty.")
    addr = ""
    for k, v in found.items():
        if "address" in k and "email" not in k and clean(v):
            addr = clean(v)
    if addr:
        meta["venue"], meta["venueAddress"] = venue, addr
    elif "," in venue:  # "Gym name, City, ST"
        meta["venue"], meta["venueAddress"] = [x.strip() for x in venue.split(",", 1)]
    else:
        meta["venue"] = venue
    for k, v in found.items():
        if ("email" in k or "contact" in k) and "@" in clean(v):
            meta["contactEmail"] = clean(v)
        if "stream" in k and clean(v).startswith("http"):
            meta["streamUrl"] = clean(v)
        if ("website" in k or "site url" in k) and clean(v).startswith("http"):
            meta["websiteUrl"] = clean(v)
        if "primary color" in k and re.match(r"^#[0-9a-fA-F]{6}$", clean(v)):
            meta["primaryColor"] = clean(v)
        if "accent color" in k and re.match(r"^#[0-9a-fA-F]{6}$", clean(v)):
            meta["accentColor"] = clean(v)

    # Edition: one more than the highest "Edition n (year)" on Past Winners.
    pw = book.sheet("Past Winners", required=False)
    if pw is not None:
        best = 0
        for r in pw.iter_rows(min_row=1, max_row=30, max_col=20, values_only=True):
            for v in r:
                m = re.match(r"^\s*Edition\s+(\d+)\s*\((\d{4})\)", clean(v), re.I)
                if m and int(m.group(2)) < start.year:
                    best = max(best, int(m.group(1)))
        if best:
            meta["edition"] = f"{ordinal(best + 1)} edition"
    meta["points"] = points_from_formula or dict(DEFAULT_POINTS)
    return meta, start


def read_teams(book):
    tab = "Teams Master"
    ws = book.sheet(tab)
    hr, hdr = find_header_row(ws, tab, ["TeamID", "Short Name", "Division", "Group Code"])
    c_id = col_of(hdr, tab, "TeamID")
    c_name = col_of(hdr, tab, "Team Name")
    c_short = col_of(hdr, tab, "Short Name")
    c_div = col_of(hdr, tab, "Division")
    c_grp = col_of(hdr, tab, "Group Code")
    c_status = col_of(hdr, tab, "Reg Status", required=False)
    # Team Styles table (to the right): Short Name / Jersey Home
    c_s_short = col_of(hdr, tab, "Short Name", occurrence=2, required=False)
    c_s_home = col_of(hdr, tab, "Jersey Home", "Jersey Color Home", required=False)
    c_s_logo = col_of(hdr, tab, "Logo", "Logo file", required=False)
    if c_s_short is None or c_s_home is None:
        warn("Teams Master: Team Styles table (Short Name, Jersey Home) not found. Jersey colors are left empty.")

    styles = {}
    if c_s_short is not None and c_s_home is not None:
        for r in read_cols(ws, hr + 1, [c_s_short, c_s_home, c_s_logo]):
            s = clean(r[c_s_short])
            if s:
                styles[s.upper()] = (r[c_s_home], clean(r.get(c_s_logo)) if c_s_logo is not None else "")

    raw = []
    for r in read_cols(ws, hr + 1, [c_id, c_name, c_short, c_div, c_grp, c_status]):
        short = clean(r[c_short])
        if not short or short.upper() == "TBD":
            continue
        raw.append(r)

    # Groups per division, so a division with a single group becomes a round robin (group "").
    def prefix(code):
        return re.sub(r"\d+$", "", clean(code).upper())
    div_groups = {}
    for r in raw:
        div_groups.setdefault(division_name(r[c_div]), set()).add(prefix(r[c_grp]))

    teams, by_short, hosts = [], {}, []
    for r in raw:
        short = clean(r[c_short])
        tid = re.sub(r"[^A-Za-z0-9]+", "", short).upper()
        div = division_name(r[c_div])
        if not div:
            warn(f"Teams Master: team {short} has no Division.")
        p = prefix(r[c_grp])
        if not p:
            warn(f"Teams Master: team {short} has no Group Code yet.")
        grp = ""
        if len(div_groups.get(div, ())) > 1:
            grp = p[1:] if (div == "Women" and len(p) > 1 and p.startswith("W")) else p
        if tid in by_short:
            warn(f"Teams Master: duplicate Short Name '{short}'.")
        st = styles.get(short.upper())
        if st is None:
            warn(f"Teams Master: team {short} is not in the Team Styles table. No jersey color.")
            color, logo = "", ""
        else:
            color, logo = color_hex(st[0], f"Team Styles, {short}"), st[1]
        t = {"id": tid, "name": clean(r[c_name]) or short, "short": short, "club": "", "city": "",
             "division": div, "group": grp, "logo": logo, "color": color, "code": clean(r[c_grp]).upper()}
        teams.append(t)
        by_short[short.upper()] = t
        if c_status is not None and "host" in clean(r[c_status]).lower():
            hosts.append(t)
    return teams, by_short, hosts


def division_name(v):
    s = clean(v).lower()
    if s in ("m", "men", "male", "mens", "men's"):
        return "Men"
    if s in ("w", "women", "female", "womens", "women's", "f"):
        return "Women"
    return clean(v)


def round_label(gr, place, div, code_a, teams_by_code):
    gr = clean(gr).upper()
    if gr == "P":
        p = clean(place)
        if not p:
            return "Playoff"
        n = num(p)
        if n not in (None, "bad"):
            return "Final" if int(n) == 1 else f"{ordinal(n)} place"
        key = p.lower()
        return {"sf": "Semifinal", "semi": "Semifinal", "semifinal": "Semifinal", "qf": "Quarterfinal",
                "quarterfinal": "Quarterfinal", "f": "Final", "final": "Final"}.get(key, p)
    t = teams_by_code.get(clean(code_a).upper())
    if t is not None:
        return f"Group {t['group']}" if t["group"] else "Round robin"
    return f"Group {gr}" if gr and gr not in ("W",) else "Round robin"


def read_games(book, by_short, teams):
    tab = "Games Schedule"
    ws = book.sheet(tab)
    hr, hdr = find_header_row(ws, tab, ["Game #", "Code Team A", "Score Team A"])
    c = {
        "date": col_of(hdr, tab, "Date"),
        "no": col_of(hdr, tab, "Game #"),
        "time": col_of(hdr, tab, "Game time", "Court Time"),
        "div": col_of(hdr, tab, "Div.", "Div", "Division"),
        "gr": col_of(hdr, tab, "Gr.", "Gr", "Group"),
        "codeA": col_of(hdr, tab, "Code Team A"),
        "codeB": col_of(hdr, tab, "Code Team B"),
        "nameA": col_of(hdr, tab, "NameTeam A", "Name Team A", "Team A"),
        "nameB": col_of(hdr, tab, "NameTeam B", "Name Team B", "Team B"),
        "sa": col_of(hdr, tab, "Score Team A"),
        "sb": col_of(hdr, tab, "Score Team B"),
        "refs": col_of(hdr, tab, "Referees", required=False),
        "court": col_of(hdr, tab, "Court", required=False),
        "pts": col_of(hdr, tab, "Points Team A", required=False),
        "ptsb": col_of(hdr, tab, "Points Team B", required=False),
    }
    # The playoff place column (1 = final, 3 = 3rd place...) has no header: it sits right after "Gr.".
    c["place"] = col_of(hdr, tab, "Place", "Placement", "K", required=False)
    if c["place"] is None and c["gr"] + 1 < len(hdr) and not hdr[c["gr"] + 1]:
        c["place"] = c["gr"] + 1
    rows = read_cols(ws, hr + 1, list(c.values()), last_row=hr + 400)

    teams_by_code = {t["code"]: t for t in teams if t["code"]}
    games, observed = [], {"win": set(), "draw": set(), "loss": set()}
    for r in rows:
        no = num(r[c["no"]])
        if no in (None, "bad"):
            if games:
                break  # end of the schedule block
            continue
        d = as_date(r[c["date"]])
        if d is None:
            warn(f"Game {no}: date missing or not a date.")
        div = division_name(r[c["div"]])
        gr = clean(r[c["gr"]]).upper()
        place = r[c["place"]] if c["place"] is not None else None
        rnd = round_label(gr, place, div, r[c["codeA"]], teams_by_code)
        ids = []
        for side in ("nameA", "nameB"):
            nm = clean(r[c[side]])
            if not nm or nm.upper() == "TBD":
                ids.append("TBD")
            elif nm.upper() in by_short:
                ids.append(by_short[nm.upper()]["id"])
            else:
                warn(f"Game {no}: unknown team '{nm}' (not a Short Name in Teams Master). Shown as TBD.")
                ids.append("TBD")
        sa, sb = num(r[c["sa"]]), num(r[c["sb"]])
        for lbl, v in (("A", sa), ("B", sb)):
            if v == "bad":
                warn(f"Game {no}: Score Team {lbl} is not a number.")
        sa = None if sa == "bad" else sa
        sb = None if sb == "bad" else sb
        if (sa is None) != (sb is None):
            warn(f"Game {no}: only one score is entered. Shown as Scheduled.")
        final = sa is not None and sb is not None
        if final and "TBD" in ids:
            warn(f"Game {no}: has a score but a team is unknown (TBD).")
        if final and c["pts"] is not None and c["ptsb"] is not None:
            pa, pb = num(r[c["pts"]]), num(r[c["ptsb"]])
            if pa not in (None, "bad") and pb not in (None, "bad") and sa > 0 and sb > 0:
                if sa > sb:
                    observed["win"].add(pa); observed["loss"].add(pb)
                elif sa < sb:
                    observed["win"].add(pb); observed["loss"].add(pa)
                else:
                    observed["draw"].add(pa); observed["draw"].add(pb)
        games.append({"no": no, "date": d.isoformat() if d else "", "day": d.strftime("%A") if d else "",
                      "time": as_time(r[c["time"]]), "court": clean(r[c["court"]]) if c["court"] is not None else "",
                      "division": div, "round": rnd, "a": ids[0], "b": ids[1],
                      "scoreA": sa if final else None, "scoreB": sb if final else None,
                      "status": "Final" if final else "Scheduled",
                      "refs": clean(r[c["refs"]]) if c["refs"] is not None else "",
                      "_playoff": gr == "P"})
    if not games:
        raise StructureError(f"Tab '{tab}': no games found under the header row (column 'Game #' is empty).")

    # Playoff teams in the model follow the live group standings. Show them only once every
    # group game of that division has a final score; until then they are TBD.
    for div in {g["division"] for g in games}:
        open_groups = [g for g in games if g["division"] == div and not g["_playoff"] and g["status"] != "Final"]
        if open_groups:
            for g in games:
                if g["division"] == div and g["_playoff"]:
                    if g["status"] == "Final":
                        warn(f"Game {g['no']}: playoff score entered while {len(open_groups)} group game(s) of {div} have no score.")
                        continue
                    g["a"] = g["b"] = "TBD"
    return games, observed


def read_players(book, by_short):
    tab = "Rosters Master"
    ws = book.sheet(tab)
    hr, hdr = find_header_row(ws, tab, ["Team", "Type", "Jersey", "First Name", "Last Name"])
    c_team, c_type = col_of(hdr, tab, "Team"), col_of(hdr, tab, "Type")
    c_no, c_first, c_last = col_of(hdr, tab, "Jersey"), col_of(hdr, tab, "First Name"), col_of(hdr, tab, "Last Name")
    # Optional columns: Position (GK marks goalkeepers for the MVG ballot) and Role / Official
    # (Official A is the team's head coach, who votes for MVP and MVG). Names only, never contacts.
    c_pos = col_of(hdr, tab, "Position", required=False)
    c_role = col_of(hdr, tab, "Role / Official", required=False)
    cols = [c for c in (c_team, c_type, c_no, c_first, c_last, c_pos, c_role) if c is not None]
    players, key_to_id, used = [], {}, set()
    officials = []
    for r in read_cols(ws, hr + 1, cols):
        kind = clean(r[c_type]).lower()
        if kind.startswith("official"):
            role = clean(r[c_role]) if c_role is not None else ""
            name = (clean(r[c_first]) + " " + clean(r[c_last])).strip()
            t = by_short.get(clean(r[c_team]).upper())
            if name and t is not None and re.search(r"official\s*a\b", role, re.I):
                officials.append({"team": t["id"], "name": name, "role": "Official A"})
            continue
        if kind != "player":
            continue
        first, last = clean(r[c_first]), clean(r[c_last])
        if not (first or last):
            continue
        short = clean(r[c_team]).upper()
        t = by_short.get(short)
        if t is None:
            warn(f"Rosters Master: player {first} {last} is on unknown team '{clean(r[c_team])}'.")
            continue
        n = num(r[c_no])
        n = None if n in (None, "bad") else n
        pid = f"{t['id']}-{n}" if n is not None else f"{t['id']}-X"
        k = 1
        base = pid
        while pid in used:
            k += 1
            pid = f"{base}-{k}"
        if n is not None and base != pid:
            warn(f"Rosters Master: jersey #{n} is used twice on {t['short']}.")
        used.add(pid)
        pos = clean(r[c_pos]).upper() if c_pos is not None else ""
        players.append({"id": pid, "team": t["id"], "first": first, "last": last, "number": n, "pos": pos})
        key_to_id[(t["id"], n, first.lower(), last.lower())] = pid
        key_to_id.setdefault((t["id"], None, first.lower(), last.lower()), pid)
    return players, key_to_id, officials


def read_goals(book, games, by_short, key_to_id):
    """Individuals Stats: 'Game n' is the n-th game of that player's team in schedule order
    (Game # order), group games first, then the playoff game once the opponent is known."""
    team_games = {}
    for g in sorted(games, key=lambda g: g["no"]):
        for side in ("a", "b"):
            if g[side] != "TBD":
                team_games.setdefault(g[side], []).append(g)
    goals, problems = [], 0
    for tab in ("Individuals Stats Men", "Individuals Stats Women"):
        ws = book.sheet(tab, required=False)
        if ws is None:
            warn(f"Tab '{tab}' not found. No goals read for it.")
            continue
        hr, hdr = find_header_row(ws, tab, ["Team", "First Name", "Last Name", "Game 1"])
        c_team, c_first, c_last = col_of(hdr, tab, "Team"), col_of(hdr, tab, "First Name"), col_of(hdr, tab, "Last Name")
        c_no = col_of(hdr, tab, "Jersey #", "Jersey", required=False)
        gcols = [(int(m.group(1)), i) for i, h in enumerate(hdr) for m in [re.match(r"^game\s*(\d+)$", norm(h))] if m]
        for r in read_cols(ws, hr + 1, [c_team, c_first, c_last, c_no] + [i for _, i in gcols]):
            short = clean(r[c_team]).upper()
            if not short:
                continue
            first, last = clean(r[c_first]), clean(r[c_last])
            t = by_short.get(short)
            if t is None:
                warn(f"{tab}: row for {first} {last} has unknown team '{short}'.")
                continue
            n = num(r[c_no]) if c_no is not None else None
            n = None if n in (None, "bad") else n
            pid = key_to_id.get((t["id"], n, first.lower(), last.lower())) or key_to_id.get((t["id"], None, first.lower(), last.lower()))
            for gi, ci in gcols:
                v = num(r[ci])
                if v in (None, 0):
                    continue
                if v == "bad":
                    warn(f"{tab}: Game {gi} for {first} {last} ({t['short']}) is not a number.")
                    continue
                if pid is None:
                    warn(f"{tab}: {first} {last} ({t['short']}) is not on Rosters Master. Goals skipped.")
                    break
                tg = team_games.get(t["id"], [])
                if gi > len(tg):
                    warn(f"{tab}: {first} {last} ({t['short']}) has goals in Game {gi}, but {t['short']} has only {len(tg)} known games.")
                    continue
                g = tg[gi - 1]
                if g["status"] != "Final":
                    warn(f"{tab}: {first} {last} ({t['short']}) has goals in Game {gi} (game #{g['no']}), which has no final score. Skipped.")
                    continue
                goals.append({"game": g["no"], "player": pid, "goals": v})
    return goals


# ------------------------------------------------------------------ cards CSV
CARDS_COLUMNS = ["Game #", "Date", "Day", "Time", "Court", "Division", "Round", "Team A", "Team B",
                 "Short A", "Short B", "Color A", "Color B", "Logo A", "Logo B", "Score A", "Score B"]


def write_cards_csv(path, games, teams):
    """Games CSV for the visual generators. Team details come from Teams Master (one source of truth)."""
    by_id = {t["id"]: t for t in teams}

    def side(tid):
        if tid == "TBD":
            return "TBD", "TBD", "", ""
        t = by_id.get(tid)
        if not t:
            return tid, tid, "", ""
        return t["name"] or tid, t["short"] or tid, t["color"], t["logo"]

    path = os.path.abspath(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    # utf-8-sig so Excel opens names with accents correctly
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(CARDS_COLUMNS)
        for g in games:
            na, sa, ca, la = side(g["a"])
            nb, sb, cb, lb = side(g["b"])
            w.writerow([g["no"] if g["no"] is not None else "", g["date"], g["day"], g["time"], g["court"],
                        g["division"], g["round"], na, nb, sa, sb, ca, cb, la, lb,
                        "" if g["scoreA"] is None else g["scoreA"], "" if g["scoreB"] is None else g["scoreB"]])


def dates_text(games, start):
    ds = sorted({g["date"] for g in games if g["date"]})
    if not ds:
        return start.strftime("%b %d, %Y").replace(" 0", " ")
    a, b = dt.date.fromisoformat(ds[0]), dt.date.fromisoformat(ds[-1])
    if a == b:
        return f"{a:%b} {a.day}, {a.year}"
    if a.year != b.year:
        return f"{a:%b} {a.day}, {a.year} to {b:%b} {b.day}, {b.year}"
    if a.month != b.month:
        return f"{a:%b} {a.day} to {b:%b} {b.day}, {b.year}"
    return f"{a:%b} {a.day} to {b.day}, {b.year}"


def share_urls(book):
    """'URLs to share (Schedule / Live Streaming / ...)' box on Games Schedule: map each label to the URL in that position."""
    ws = book.sheet("Games Schedule")
    labels, urls, col = None, [], None
    for i, r in enumerate(ws.iter_rows(min_row=1, max_row=200, max_col=30, values_only=True), 1):
        if labels is None:
            for j, v in enumerate(r):
                if isinstance(v, str) and v.lower().startswith("urls to share"):
                    m = re.search(r"\(([^)]*)\)", v)
                    labels = [x.strip().lower() for x in (m.group(1) if m else "").split("/")]
                    col = j
                    break
        elif col is not None:
            v = clean(r[col])
            if v.startswith("http"):
                urls.append(v)
            elif urls:
                break
    out = {}
    for lbl, u in zip(labels or [], urls):
        out[lbl] = u
    return out


def main():
    ap = argparse.ArgumentParser(description="Tournament Master Template to data/data.js converter")
    ap.add_argument("workbook")
    ap.add_argument("--out", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "data.js"))
    ap.add_argument("--cards-csv", metavar="PATH", help="also write the games CSV for make_match_cards.py")
    args = ap.parse_args()
    if not os.path.exists(args.workbook):
        sys.exit(f"ERROR: workbook not found: {args.workbook}")

    try:
        points = check_cached_values(args.workbook)
        book = Book(args.workbook)
        meta, start = read_meta(book, points)
        teams, by_short, hosts = read_teams(book)
        games, observed = read_games(book, by_short, teams)
        players, key_to_id, officials = read_players(book, by_short)
        goals = read_goals(book, games, by_short, key_to_id)
        urls = share_urls(book)
    except StructureError as e:
        sys.exit(f"ERROR: {e}")

    if points is None:  # no formula found: use what the cached Points columns show, else defaults
        for k in ("win", "draw", "loss"):
            if len(observed[k]) == 1:
                meta["points"][k] = observed[k].pop()
    if not meta["host"] and hosts:
        names = []
        for t in hosts:
            n = re.sub(r"\s+W$", "", t["name"])
            if n not in names:
                names.append(n)
        meta["host"] = " and ".join(names)
    meta["dates"] = dates_text(games, start)
    if not meta["streamUrl"]:
        meta["streamUrl"] = next((u for k, u in urls.items() if "stream" in k), "")
    if not meta["websiteUrl"]:
        meta["websiteUrl"] = next((u for k, u in urls.items() if "schedule" in k), "")
    meta["generatedAt"] = dt.datetime.now().astimezone().isoformat(timespec="seconds")

    # Validation: goals must add up to each final score.
    pteam = {p["id"]: p["team"] for p in players}
    sums = {}
    for x in goals:
        k = (x["game"], pteam.get(x["player"]))
        sums[k] = sums.get(k, 0) + x["goals"]
    for g in games:
        if g["status"] != "Final":
            continue
        for t, s in ((g["a"], g["scoreA"]), (g["b"], g["scoreB"])):
            if t == "TBD":
                continue
            got = sums.get((g["no"], t), 0)
            if got != s:
                warn(f"Game {g['no']}: goals for {t} add up to {got} but the score is {s}.")

    for g in games:
        g.pop("_playoff", None)
    for t in teams:
        t.pop("code", None)
    data = {"meta": meta, "teams": teams, "games": games, "players": players, "officials": officials, "goals": goals}
    out = os.path.abspath(args.out)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    tmp = out + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write("// Generated from the workbook. Do not edit by hand.\n")
        f.write(f"// Source: {os.path.basename(args.workbook)}  Generated: {meta['generatedAt']}\n")
        f.write("window.TOURNAMENT = ")
        json.dump(data, f, ensure_ascii=False, indent=1)
        f.write(";\n")
    os.replace(tmp, out)

    if args.cards_csv:
        write_cards_csv(args.cards_csv, games, teams)

    final = sum(1 for g in games if g["status"] == "Final")
    tbd = sum(1 for g in games if "TBD" in (g["a"], g["b"]))
    print(f"Wrote {out}")
    if args.cards_csv:
        print(f"Wrote {os.path.abspath(args.cards_csv)} (match cards CSV, {len(games)} games)")
    print(f"Tournament: {meta['name']}  {meta['edition']}  {meta['dates']}  {meta['venue']}")
    print(f"Teams: {len(teams)}  Games: {len(games)}  Final games: {final}  TBD games: {tbd}  "
          f"Players: {len(players)}  Goal rows: {len(goals)}  Goals: {sum(x['goals'] for x in goals)}")
    print(f"Warnings: {len(warnings)}")
    for w in warnings:
        print(f"  WARNING: {w}")


if __name__ == "__main__":
    main()

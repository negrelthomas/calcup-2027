// Generated from the workbook. Do not edit by hand.
// Source: test_values_copy.xlsx  Generated: 2026-10-08T11:42:39-07:00
window.TOURNAMENT = {
 "meta": {
  "name": "Bay Classic 2027",
  "edition": "5th edition",
  "year": "2027",
  "host": "Harbor HC",
  "dates": "Feb 12 to 14, 2027",
  "venue": "Northside Community Gym",
  "venueAddress": "Springfield, CA",
  "contactEmail": "",
  "streamUrl": "https://example.org/live",
  "websiteUrl": "https://example.org/schedule",
  "primaryColor": "#12355B",
  "accentColor": "#E4572E",
  "points": {
   "win": 2,
   "draw": 1,
   "loss": 0
  },
  "generatedAt": "2026-10-08T11:42:39-07:00"
 },
 "teams": [
  {
   "id": "HAR",
   "name": "Harbor HC",
   "short": "HAR",
   "club": "",
   "city": "",
   "division": "Men",
   "group": "A",
   "logo": "",
   "color": "#1F2A5A"
  },
  {
   "id": "MES",
   "name": "Mesa Valley",
   "short": "MES",
   "club": "",
   "city": "",
   "division": "Men",
   "group": "A",
   "logo": "",
   "color": "#C62828"
  },
  {
   "id": "RED",
   "name": "Redwood United",
   "short": "RED",
   "club": "",
   "city": "",
   "division": "Men",
   "group": "B",
   "logo": "",
   "color": "#2E7D32"
  },
  {
   "id": "PAC",
   "name": "Pacific Coast",
   "short": "PAC",
   "club": "",
   "city": "",
   "division": "Men",
   "group": "B",
   "logo": "",
   "color": "#1565C0"
  },
  {
   "id": "SUM",
   "name": "Summit City",
   "short": "SUM",
   "club": "",
   "city": "",
   "division": "Men",
   "group": "B",
   "logo": "",
   "color": "#1A1A1A"
  },
  {
   "id": "LAK",
   "name": "Lakeside HB",
   "short": "LAK",
   "club": "",
   "city": "",
   "division": "Men",
   "group": "A",
   "logo": "",
   "color": "#4FA3E0"
  },
  {
   "id": "CAN",
   "name": "Canyon Ridge HC",
   "short": "CAN",
   "club": "",
   "city": "",
   "division": "Men",
   "group": "B",
   "logo": "",
   "color": "#7B1E2B"
  },
  {
   "id": "NOR",
   "name": "Northwind HC",
   "short": "NOR",
   "club": "",
   "city": "",
   "division": "Men",
   "group": "A",
   "logo": "",
   "color": "#757575"
  },
  {
   "id": "HARW",
   "name": "Harbor HC W",
   "short": "HARW",
   "club": "",
   "city": "",
   "division": "Women",
   "group": "",
   "logo": "",
   "color": "#1F2A5A"
  },
  {
   "id": "REDW",
   "name": "Redwood United W",
   "short": "REDW",
   "club": "",
   "city": "",
   "division": "Women",
   "group": "",
   "logo": "",
   "color": "#2E7D32"
  },
  {
   "id": "DES",
   "name": "Desert Storm",
   "short": "DES",
   "club": "",
   "city": "",
   "division": "Women",
   "group": "",
   "logo": "",
   "color": "#EF6C00"
  },
  {
   "id": "BAY",
   "name": "Bayview",
   "short": "BAY",
   "club": "",
   "city": "",
   "division": "Women",
   "group": "",
   "logo": "",
   "color": "#6A1B9A"
  }
 ],
 "games": [
  {
   "no": 1,
   "date": "2027-02-12",
   "day": "Friday",
   "time": "14:35",
   "court": "",
   "division": "Women",
   "round": "Round robin",
   "a": "HARW",
   "b": "DES",
   "scoreA": 27,
   "scoreB": 24,
   "status": "Final",
   "refs": "Selin Ekstrom / Jasper Holm"
  },
  {
   "no": 2,
   "date": "2027-02-12",
   "day": "Friday",
   "time": "15:45",
   "court": "",
   "division": "Men",
   "round": "Group A",
   "a": "HAR",
   "b": "LAK",
   "scoreA": 31,
   "scoreB": 28,
   "status": "Final",
   "refs": "Camila Duarte / Nico Moretti"
  },
  {
   "no": 3,
   "date": "2027-02-12",
   "day": "Friday",
   "time": "16:55",
   "court": "",
   "division": "Men",
   "round": "Group B",
   "a": "RED",
   "b": "CAN",
   "scoreA": 29,
   "scoreB": 26,
   "status": "Final",
   "refs": "Leo Larsen / Silas Kaplan"
  },
  {
   "no": 4,
   "date": "2027-02-12",
   "day": "Friday",
   "time": "18:05",
   "court": "",
   "division": "Women",
   "round": "Round robin",
   "a": "REDW",
   "b": "BAY",
   "scoreA": 23,
   "scoreB": 25,
   "status": "Final",
   "refs": "Liam Garza / Emeka Dahl"
  },
  {
   "no": 5,
   "date": "2027-02-12",
   "day": "Friday",
   "time": "19:15",
   "court": "",
   "division": "Men",
   "round": "Group A",
   "a": "MES",
   "b": "NOR",
   "scoreA": 33,
   "scoreB": 27,
   "status": "Final",
   "refs": "Kira Engel / Erik Patel"
  },
  {
   "no": 6,
   "date": "2027-02-12",
   "day": "Friday",
   "time": "20:25",
   "court": "",
   "division": "Men",
   "round": "Group B",
   "a": "PAC",
   "b": "SUM",
   "scoreA": 24,
   "scoreB": 30,
   "status": "Final",
   "refs": "Selin Ekstrom / Jasper Holm"
  },
  {
   "no": 7,
   "date": "2027-02-12",
   "day": "Friday",
   "time": "21:35",
   "court": "",
   "division": "Women",
   "round": "Round robin",
   "a": "HARW",
   "b": "REDW",
   "scoreA": 28,
   "scoreB": 21,
   "status": "Final",
   "refs": "Camila Duarte / Nico Moretti"
  },
  {
   "no": 8,
   "date": "2027-02-13",
   "day": "Saturday",
   "time": "08:05",
   "court": "",
   "division": "Men",
   "round": "Group A",
   "a": "HAR",
   "b": "MES",
   "scoreA": 27,
   "scoreB": 32,
   "status": "Final",
   "refs": "Kira Engel / Erik Patel"
  },
  {
   "no": 9,
   "date": "2027-02-13",
   "day": "Saturday",
   "time": "09:15",
   "court": "",
   "division": "Women",
   "round": "Round robin",
   "a": "DES",
   "b": "BAY",
   "scoreA": 22,
   "scoreB": 29,
   "status": "Final",
   "refs": "Leo Larsen / Silas Kaplan"
  },
  {
   "no": 10,
   "date": "2027-02-13",
   "day": "Saturday",
   "time": "10:25",
   "court": "",
   "division": "Men",
   "round": "Group B",
   "a": "RED",
   "b": "PAC",
   "scoreA": 34,
   "scoreB": 25,
   "status": "Final",
   "refs": "Liam Garza / Emeka Dahl"
  },
  {
   "no": 11,
   "date": "2027-02-13",
   "day": "Saturday",
   "time": "11:35",
   "court": "",
   "division": "Women",
   "round": "Round robin",
   "a": "HARW",
   "b": "BAY",
   "scoreA": 25,
   "scoreB": 27,
   "status": "Final",
   "refs": "Selin Ekstrom / Jasper Holm"
  },
  {
   "no": 12,
   "date": "2027-02-13",
   "day": "Saturday",
   "time": "12:45",
   "court": "",
   "division": "Men",
   "round": "Group A",
   "a": "LAK",
   "b": "NOR",
   "scoreA": 29,
   "scoreB": 29,
   "status": "Final",
   "refs": "Camila Duarte / Nico Moretti"
  },
  {
   "no": 13,
   "date": "2027-02-13",
   "day": "Saturday",
   "time": "13:55",
   "court": "",
   "division": "Women",
   "round": "Round robin",
   "a": "DES",
   "b": "REDW",
   "scoreA": null,
   "scoreB": null,
   "status": "Scheduled",
   "refs": "Leo Larsen / Silas Kaplan"
  },
  {
   "no": 14,
   "date": "2027-02-13",
   "day": "Saturday",
   "time": "15:05",
   "court": "",
   "division": "Men",
   "round": "Group B",
   "a": "CAN",
   "b": "SUM",
   "scoreA": null,
   "scoreB": null,
   "status": "Scheduled",
   "refs": "Liam Garza / Emeka Dahl"
  },
  {
   "no": 15,
   "date": "2027-02-13",
   "day": "Saturday",
   "time": "16:15",
   "court": "",
   "division": "Men",
   "round": "Group A",
   "a": "HAR",
   "b": "NOR",
   "scoreA": null,
   "scoreB": null,
   "status": "Scheduled",
   "refs": "Kira Engel / Erik Patel"
  },
  {
   "no": 16,
   "date": "2027-02-13",
   "day": "Saturday",
   "time": "17:25",
   "court": "",
   "division": "Men",
   "round": "Group B",
   "a": "RED",
   "b": "SUM",
   "scoreA": null,
   "scoreB": null,
   "status": "Scheduled",
   "refs": "Selin Ekstrom / Jasper Holm"
  },
  {
   "no": 17,
   "date": "2027-02-13",
   "day": "Saturday",
   "time": "18:35",
   "court": "",
   "division": "Men",
   "round": "Group A",
   "a": "LAK",
   "b": "MES",
   "scoreA": null,
   "scoreB": null,
   "status": "Scheduled",
   "refs": "Camila Duarte / Nico Moretti"
  },
  {
   "no": 18,
   "date": "2027-02-13",
   "day": "Saturday",
   "time": "19:45",
   "court": "",
   "division": "Men",
   "round": "Group B",
   "a": "CAN",
   "b": "PAC",
   "scoreA": null,
   "scoreB": null,
   "status": "Scheduled",
   "refs": "Leo Larsen / Silas Kaplan"
  },
  {
   "no": 19,
   "date": "2027-02-14",
   "day": "Sunday",
   "time": "08:35",
   "court": "",
   "division": "Men",
   "round": "7th place",
   "a": "TBD",
   "b": "TBD",
   "scoreA": null,
   "scoreB": null,
   "status": "Scheduled",
   "refs": "Kira Engel / Erik Patel"
  },
  {
   "no": 20,
   "date": "2027-02-14",
   "day": "Sunday",
   "time": "09:45",
   "court": "",
   "division": "Men",
   "round": "5th place",
   "a": "TBD",
   "b": "TBD",
   "scoreA": null,
   "scoreB": null,
   "status": "Scheduled",
   "refs": "Selin Ekstrom / Jasper Holm"
  },
  {
   "no": 21,
   "date": "2027-02-14",
   "day": "Sunday",
   "time": "10:55",
   "court": "",
   "division": "Women",
   "round": "3rd place",
   "a": "TBD",
   "b": "TBD",
   "scoreA": null,
   "scoreB": null,
   "status": "Scheduled",
   "refs": "Camila Duarte / Nico Moretti"
  },
  {
   "no": 22,
   "date": "2027-02-14",
   "day": "Sunday",
   "time": "12:05",
   "court": "",
   "division": "Men",
   "round": "3rd place",
   "a": "TBD",
   "b": "TBD",
   "scoreA": null,
   "scoreB": null,
   "status": "Scheduled",
   "refs": "Kira Engel / Erik Patel"
  },
  {
   "no": 23,
   "date": "2027-02-14",
   "day": "Sunday",
   "time": "13:15",
   "court": "",
   "division": "Women",
   "round": "Final",
   "a": "TBD",
   "b": "TBD",
   "scoreA": null,
   "scoreB": null,
   "status": "Scheduled",
   "refs": "Selin Ekstrom / Jasper Holm"
  },
  {
   "no": 24,
   "date": "2027-02-14",
   "day": "Sunday",
   "time": "14:25",
   "court": "",
   "division": "Men",
   "round": "Final",
   "a": "TBD",
   "b": "TBD",
   "scoreA": null,
   "scoreB": null,
   "status": "Scheduled",
   "refs": "Camila Duarte / Nico Moretti"
  }
 ],
 "players": [
  {
   "id": "HAR-1",
   "team": "HAR",
   "first": "Jorge",
   "last": "Hoffmann",
   "number": 1
  },
  {
   "id": "HAR-12",
   "team": "HAR",
   "first": "Dante",
   "last": "Zielinski",
   "number": 12
  },
  {
   "id": "HAR-6",
   "team": "HAR",
   "first": "Julian",
   "last": "Pires",
   "number": 6
  },
  {
   "id": "HAR-65",
   "team": "HAR",
   "first": "Ahmed",
   "last": "Ortega",
   "number": 65
  },
  {
   "id": "HAR-87",
   "team": "HAR",
   "first": "Kai",
   "last": "Lowe",
   "number": 87
  },
  {
   "id": "HAR-89",
   "team": "HAR",
   "first": "Viktor",
   "last": "Rautio",
   "number": 89
  },
  {
   "id": "HAR-29",
   "team": "HAR",
   "first": "Alejandro",
   "last": "Pham",
   "number": 29
  },
  {
   "id": "HAR-77",
   "team": "HAR",
   "first": "Hamza",
   "last": "Weber",
   "number": 77
  },
  {
   "id": "HAR-92",
   "team": "HAR",
   "first": "Rasmus",
   "last": "Gallagher",
   "number": 92
  },
  {
   "id": "HAR-10",
   "team": "HAR",
   "first": "Pablo",
   "last": "Nguyen",
   "number": 10
  },
  {
   "id": "HAR-50",
   "team": "HAR",
   "first": "Hugo",
   "last": "Nyberg",
   "number": 50
  },
  {
   "id": "HAR-56",
   "team": "HAR",
   "first": "Sven",
   "last": "Toivonen",
   "number": 56
  },
  {
   "id": "HAR-59",
   "team": "HAR",
   "first": "Karim",
   "last": "Hayes",
   "number": 59
  },
  {
   "id": "HAR-58",
   "team": "HAR",
   "first": "Teodor",
   "last": "Nakamura",
   "number": 58
  },
  {
   "id": "HAR-71",
   "team": "HAR",
   "first": "Mikael",
   "last": "Sandberg",
   "number": 71
  },
  {
   "id": "HAR-11",
   "team": "HAR",
   "first": "Malik",
   "last": "Ferreira",
   "number": 11
  },
  {
   "id": "MES-1",
   "team": "MES",
   "first": "Rohan",
   "last": "Kowalski",
   "number": 1
  },
  {
   "id": "MES-12",
   "team": "MES",
   "first": "Gideon",
   "last": "Brandt",
   "number": 12
  },
  {
   "id": "MES-39",
   "team": "MES",
   "first": "Malik",
   "last": "Petrov",
   "number": 39
  },
  {
   "id": "MES-53",
   "team": "MES",
   "first": "Stefan",
   "last": "Doyle",
   "number": 53
  },
  {
   "id": "MES-80",
   "team": "MES",
   "first": "Jonas",
   "last": "Rios",
   "number": 80
  },
  {
   "id": "MES-13",
   "team": "MES",
   "first": "Yusuf",
   "last": "Sorensen",
   "number": 13
  },
  {
   "id": "MES-49",
   "team": "MES",
   "first": "Anton",
   "last": "Torres",
   "number": 49
  },
  {
   "id": "MES-83",
   "team": "MES",
   "first": "Sebastian",
   "last": "Keller",
   "number": 83
  },
  {
   "id": "MES-50",
   "team": "MES",
   "first": "Quentin",
   "last": "Jaramillo",
   "number": 50
  },
  {
   "id": "MES-55",
   "team": "MES",
   "first": "Zane",
   "last": "Takahashi",
   "number": 55
  },
  {
   "id": "MES-46",
   "team": "MES",
   "first": "Anton",
   "last": "Zhang",
   "number": 46
  },
  {
   "id": "MES-19",
   "team": "MES",
   "first": "Carlos",
   "last": "Becker",
   "number": 19
  },
  {
   "id": "MES-75",
   "team": "MES",
   "first": "Adrian",
   "last": "Bianchi",
   "number": 75
  },
  {
   "id": "MES-8",
   "team": "MES",
   "first": "Idris",
   "last": "Osei",
   "number": 8
  },
  {
   "id": "MES-6",
   "team": "MES",
   "first": "Darius",
   "last": "Winter",
   "number": 6
  },
  {
   "id": "MES-25",
   "team": "MES",
   "first": "Nico",
   "last": "Pajari",
   "number": 25
  },
  {
   "id": "RED-1",
   "team": "RED",
   "first": "Idris",
   "last": "Varga",
   "number": 1
  },
  {
   "id": "RED-12",
   "team": "RED",
   "first": "Marco",
   "last": "Tanaka",
   "number": 12
  },
  {
   "id": "RED-90",
   "team": "RED",
   "first": "Yusuf",
   "last": "Bakker",
   "number": 90
  },
  {
   "id": "RED-25",
   "team": "RED",
   "first": "Marco",
   "last": "Castillo",
   "number": 25
  },
  {
   "id": "RED-58",
   "team": "RED",
   "first": "Sebastian",
   "last": "Marchetti",
   "number": 58
  },
  {
   "id": "RED-69",
   "team": "RED",
   "first": "Tomas",
   "last": "Laine",
   "number": 69
  },
  {
   "id": "RED-30",
   "team": "RED",
   "first": "Carlos",
   "last": "Achterberg",
   "number": 30
  },
  {
   "id": "RED-41",
   "team": "RED",
   "first": "Hamza",
   "last": "Hoffmann",
   "number": 41
  },
  {
   "id": "RED-11",
   "team": "RED",
   "first": "Bram",
   "last": "Gallagher",
   "number": 11
  },
  {
   "id": "RED-47",
   "team": "RED",
   "first": "Farid",
   "last": "Calloway",
   "number": 47
  },
  {
   "id": "RED-71",
   "team": "RED",
   "first": "Liam",
   "last": "Nieminen",
   "number": 71
  },
  {
   "id": "RED-73",
   "team": "RED",
   "first": "Kevin",
   "last": "Dubois",
   "number": 73
  },
  {
   "id": "RED-28",
   "team": "RED",
   "first": "Idris",
   "last": "Sandberg",
   "number": 28
  },
  {
   "id": "RED-96",
   "team": "RED",
   "first": "Jonas",
   "last": "Moreau",
   "number": 96
  },
  {
   "id": "RED-85",
   "team": "RED",
   "first": "Jorge",
   "last": "Delgado",
   "number": 85
  },
  {
   "id": "RED-59",
   "team": "RED",
   "first": "Rasmus",
   "last": "Hoffmann",
   "number": 59
  },
  {
   "id": "PAC-1",
   "team": "PAC",
   "first": "Samir",
   "last": "Holm",
   "number": 1
  },
  {
   "id": "PAC-12",
   "team": "PAC",
   "first": "Kevin",
   "last": "Weber",
   "number": 12
  },
  {
   "id": "PAC-23",
   "team": "PAC",
   "first": "Sebastian",
   "last": "Ibrahim",
   "number": 23
  },
  {
   "id": "PAC-76",
   "team": "PAC",
   "first": "Liam",
   "last": "Abara",
   "number": 76
  },
  {
   "id": "PAC-70",
   "team": "PAC",
   "first": "Vasco",
   "last": "Keller",
   "number": 70
  },
  {
   "id": "PAC-71",
   "team": "PAC",
   "first": "Idris",
   "last": "Byrne",
   "number": 71
  },
  {
   "id": "PAC-26",
   "team": "PAC",
   "first": "Bram",
   "last": "Holm",
   "number": 26
  },
  {
   "id": "PAC-3",
   "team": "PAC",
   "first": "Luis",
   "last": "Ahn",
   "number": 3
  },
  {
   "id": "PAC-88",
   "team": "PAC",
   "first": "Kenji",
   "last": "Rautio",
   "number": 88
  },
  {
   "id": "PAC-15",
   "team": "PAC",
   "first": "Henrik",
   "last": "Esposito",
   "number": 15
  },
  {
   "id": "PAC-30",
   "team": "PAC",
   "first": "Nico",
   "last": "Thorsen",
   "number": 30
  },
  {
   "id": "PAC-10",
   "team": "PAC",
   "first": "Karim",
   "last": "Nordin",
   "number": 10
  },
  {
   "id": "PAC-25",
   "team": "PAC",
   "first": "Arjun",
   "last": "Nieminen",
   "number": 25
  },
  {
   "id": "PAC-55",
   "team": "PAC",
   "first": "Carlos",
   "last": "Ekstrom",
   "number": 55
  },
  {
   "id": "PAC-6",
   "team": "PAC",
   "first": "Rafael",
   "last": "Thorsen",
   "number": 6
  },
  {
   "id": "PAC-79",
   "team": "PAC",
   "first": "Samir",
   "last": "Fontaine",
   "number": 79
  },
  {
   "id": "SUM-1",
   "team": "SUM",
   "first": "Dario",
   "last": "Eriksen",
   "number": 1
  },
  {
   "id": "SUM-12",
   "team": "SUM",
   "first": "Caleb",
   "last": "Quiroga",
   "number": 12
  },
  {
   "id": "SUM-47",
   "team": "SUM",
   "first": "Joel",
   "last": "Flynn",
   "number": 47
  },
  {
   "id": "SUM-35",
   "team": "SUM",
   "first": "Malik",
   "last": "Byrne",
   "number": 35
  },
  {
   "id": "SUM-92",
   "team": "SUM",
   "first": "Enzo",
   "last": "Vasquez",
   "number": 92
  },
  {
   "id": "SUM-70",
   "team": "SUM",
   "first": "Liam",
   "last": "Mattila",
   "number": 70
  },
  {
   "id": "SUM-25",
   "team": "SUM",
   "first": "Aaron",
   "last": "Novak",
   "number": 25
  },
  {
   "id": "SUM-45",
   "team": "SUM",
   "first": "Noah",
   "last": "Almeida",
   "number": 45
  },
  {
   "id": "SUM-26",
   "team": "SUM",
   "first": "Lars",
   "last": "Wiklund",
   "number": 26
  },
  {
   "id": "SUM-2",
   "team": "SUM",
   "first": "Anton",
   "last": "Toivonen",
   "number": 2
  },
  {
   "id": "SUM-24",
   "team": "SUM",
   "first": "Ivan",
   "last": "Coleman",
   "number": 24
  },
  {
   "id": "SUM-98",
   "team": "SUM",
   "first": "Levi",
   "last": "Park",
   "number": 98
  },
  {
   "id": "SUM-9",
   "team": "SUM",
   "first": "Jasper",
   "last": "Park",
   "number": 9
  },
  {
   "id": "SUM-91",
   "team": "SUM",
   "first": "Levi",
   "last": "Vasquez",
   "number": 91
  },
  {
   "id": "SUM-83",
   "team": "SUM",
   "first": "Tomas",
   "last": "Ekstrom",
   "number": 83
  },
  {
   "id": "SUM-66",
   "team": "SUM",
   "first": "Sven",
   "last": "Strand",
   "number": 66
  },
  {
   "id": "LAK-1",
   "team": "LAK",
   "first": "Ivan",
   "last": "Vidal",
   "number": 1
  },
  {
   "id": "LAK-12",
   "team": "LAK",
   "first": "Gideon",
   "last": "Farouk",
   "number": 12
  },
  {
   "id": "LAK-97",
   "team": "LAK",
   "first": "Nico",
   "last": "Novak",
   "number": 97
  },
  {
   "id": "LAK-94",
   "team": "LAK",
   "first": "Fabian",
   "last": "Almeida",
   "number": 94
  },
  {
   "id": "LAK-62",
   "team": "LAK",
   "first": "Erik",
   "last": "Jaramillo",
   "number": 62
  },
  {
   "id": "LAK-54",
   "team": "LAK",
   "first": "Nico",
   "last": "Bergstrom",
   "number": 54
  },
  {
   "id": "LAK-98",
   "team": "LAK",
   "first": "Gabriel",
   "last": "Pereira",
   "number": 98
  },
  {
   "id": "LAK-28",
   "team": "LAK",
   "first": "Quentin",
   "last": "Banerjee",
   "number": 28
  },
  {
   "id": "LAK-16",
   "team": "LAK",
   "first": "Amir",
   "last": "Delgado",
   "number": 16
  },
  {
   "id": "LAK-39",
   "team": "LAK",
   "first": "Orion",
   "last": "Moreau",
   "number": 39
  },
  {
   "id": "LAK-49",
   "team": "LAK",
   "first": "Anton",
   "last": "Pham",
   "number": 49
  },
  {
   "id": "LAK-55",
   "team": "LAK",
   "first": "Stefan",
   "last": "Kruger",
   "number": 55
  },
  {
   "id": "LAK-23",
   "team": "LAK",
   "first": "Orion",
   "last": "Kruger",
   "number": 23
  },
  {
   "id": "LAK-91",
   "team": "LAK",
   "first": "Darius",
   "last": "Olsen",
   "number": 91
  },
  {
   "id": "LAK-59",
   "team": "LAK",
   "first": "Ryan",
   "last": "Kaplan",
   "number": 59
  },
  {
   "id": "LAK-52",
   "team": "LAK",
   "first": "Silas",
   "last": "Fontaine",
   "number": 52
  },
  {
   "id": "CAN-1",
   "team": "CAN",
   "first": "Mateo",
   "last": "Almeida",
   "number": 1
  },
  {
   "id": "CAN-12",
   "team": "CAN",
   "first": "Kai",
   "last": "Banerjee",
   "number": 12
  },
  {
   "id": "CAN-82",
   "team": "CAN",
   "first": "Oliver",
   "last": "Kolar",
   "number": 82
  },
  {
   "id": "CAN-39",
   "team": "CAN",
   "first": "Oliver",
   "last": "Marchetti",
   "number": 39
  },
  {
   "id": "CAN-62",
   "team": "CAN",
   "first": "Sebastian",
   "last": "Gallagher",
   "number": 62
  },
  {
   "id": "CAN-58",
   "team": "CAN",
   "first": "Pablo",
   "last": "Demir",
   "number": 58
  },
  {
   "id": "CAN-38",
   "team": "CAN",
   "first": "Emil",
   "last": "Nordin",
   "number": 38
  },
  {
   "id": "CAN-18",
   "team": "CAN",
   "first": "Marco",
   "last": "Pereira",
   "number": 18
  },
  {
   "id": "CAN-59",
   "team": "CAN",
   "first": "Enzo",
   "last": "Almeida",
   "number": 59
  },
  {
   "id": "CAN-31",
   "team": "CAN",
   "first": "Caleb",
   "last": "Iversen",
   "number": 31
  },
  {
   "id": "CAN-90",
   "team": "CAN",
   "first": "Ahmed",
   "last": "Delgado",
   "number": 90
  },
  {
   "id": "CAN-3",
   "team": "CAN",
   "first": "Milan",
   "last": "Farouk",
   "number": 3
  },
  {
   "id": "CAN-37",
   "team": "CAN",
   "first": "Kenji",
   "last": "Rios",
   "number": 37
  },
  {
   "id": "CAN-96",
   "team": "CAN",
   "first": "Anton",
   "last": "Valdez",
   "number": 96
  },
  {
   "id": "CAN-68",
   "team": "CAN",
   "first": "Magnus",
   "last": "Larsen",
   "number": 68
  },
  {
   "id": "CAN-95",
   "team": "CAN",
   "first": "Liam",
   "last": "Kavanagh",
   "number": 95
  },
  {
   "id": "NOR-1",
   "team": "NOR",
   "first": "Enzo",
   "last": "Mendes",
   "number": 1
  },
  {
   "id": "NOR-12",
   "team": "NOR",
   "first": "Jalen",
   "last": "Esposito",
   "number": 12
  },
  {
   "id": "NOR-5",
   "team": "NOR",
   "first": "Jasper",
   "last": "Bianchi",
   "number": 5
  },
  {
   "id": "NOR-91",
   "team": "NOR",
   "first": "Yannick",
   "last": "Park",
   "number": 91
  },
  {
   "id": "NOR-2",
   "team": "NOR",
   "first": "Xavier",
   "last": "Park",
   "number": 2
  },
  {
   "id": "NOR-9",
   "team": "NOR",
   "first": "Farid",
   "last": "Ibrahim",
   "number": 9
  },
  {
   "id": "NOR-68",
   "team": "NOR",
   "first": "Farid",
   "last": "Garza",
   "number": 68
  },
  {
   "id": "NOR-25",
   "team": "NOR",
   "first": "Enzo",
   "last": "Arslan",
   "number": 25
  },
  {
   "id": "NOR-47",
   "team": "NOR",
   "first": "Bastian",
   "last": "Engel",
   "number": 47
  },
  {
   "id": "NOR-34",
   "team": "NOR",
   "first": "Erik",
   "last": "Almeida",
   "number": 34
  },
  {
   "id": "NOR-17",
   "team": "NOR",
   "first": "Henrik",
   "last": "Duarte",
   "number": 17
  },
  {
   "id": "NOR-61",
   "team": "NOR",
   "first": "Henrik",
   "last": "Madsen",
   "number": 61
  },
  {
   "id": "NOR-96",
   "team": "NOR",
   "first": "Leo",
   "last": "Kruger",
   "number": 96
  },
  {
   "id": "NOR-31",
   "team": "NOR",
   "first": "Jasper",
   "last": "Almeida",
   "number": 31
  },
  {
   "id": "NOR-66",
   "team": "NOR",
   "first": "Aiden",
   "last": "Osei",
   "number": 66
  },
  {
   "id": "NOR-56",
   "team": "NOR",
   "first": "Pavel",
   "last": "Duarte",
   "number": 56
  },
  {
   "id": "HARW-1",
   "team": "HARW",
   "first": "Lotte",
   "last": "Halvorsen",
   "number": 1
  },
  {
   "id": "HARW-12",
   "team": "HARW",
   "first": "Vera",
   "last": "Nakamura",
   "number": 12
  },
  {
   "id": "HARW-9",
   "team": "HARW",
   "first": "Sara",
   "last": "Hartley",
   "number": 9
  },
  {
   "id": "HARW-76",
   "team": "HARW",
   "first": "Zoe",
   "last": "Iversen",
   "number": 76
  },
  {
   "id": "HARW-29",
   "team": "HARW",
   "first": "Greta",
   "last": "Haddad",
   "number": 29
  },
  {
   "id": "HARW-86",
   "team": "HARW",
   "first": "Ines",
   "last": "Okonkwo",
   "number": 86
  },
  {
   "id": "HARW-61",
   "team": "HARW",
   "first": "Valentina",
   "last": "Mattila",
   "number": 61
  },
  {
   "id": "HARW-81",
   "team": "HARW",
   "first": "Greta",
   "last": "Adeyemi",
   "number": 81
  },
  {
   "id": "HARW-11",
   "team": "HARW",
   "first": "Daria",
   "last": "Torres",
   "number": 11
  },
  {
   "id": "HARW-7",
   "team": "HARW",
   "first": "Petra",
   "last": "Gallagher",
   "number": 7
  },
  {
   "id": "HARW-39",
   "team": "HARW",
   "first": "Naomi",
   "last": "Castillo",
   "number": 39
  },
  {
   "id": "HARW-44",
   "team": "HARW",
   "first": "Elif",
   "last": "Thorsen",
   "number": 44
  },
  {
   "id": "HARW-32",
   "team": "HARW",
   "first": "Lina",
   "last": "Rios",
   "number": 32
  },
  {
   "id": "HARW-94",
   "team": "HARW",
   "first": "Hedda",
   "last": "Pham",
   "number": 94
  },
  {
   "id": "HARW-6",
   "team": "HARW",
   "first": "Aisha",
   "last": "Terzic",
   "number": 6
  },
  {
   "id": "HARW-51",
   "team": "HARW",
   "first": "Linnea",
   "last": "Uribe",
   "number": 51
  },
  {
   "id": "REDW-1",
   "team": "REDW",
   "first": "Helena",
   "last": "Schmidt",
   "number": 1
  },
  {
   "id": "REDW-12",
   "team": "REDW",
   "first": "Nora",
   "last": "Dahl",
   "number": 12
  },
  {
   "id": "REDW-37",
   "team": "REDW",
   "first": "Bea",
   "last": "Becker",
   "number": 37
  },
  {
   "id": "REDW-96",
   "team": "REDW",
   "first": "Sara",
   "last": "Ekstrom",
   "number": 96
  },
  {
   "id": "REDW-45",
   "team": "REDW",
   "first": "Greta",
   "last": "Gonzaga",
   "number": 45
  },
  {
   "id": "REDW-84",
   "team": "REDW",
   "first": "Beatriz",
   "last": "Kruger",
   "number": 84
  },
  {
   "id": "REDW-91",
   "team": "REDW",
   "first": "Gaia",
   "last": "Gallagher",
   "number": 91
  },
  {
   "id": "REDW-54",
   "team": "REDW",
   "first": "Priya",
   "last": "Valdez",
   "number": 54
  },
  {
   "id": "REDW-28",
   "team": "REDW",
   "first": "Ronja",
   "last": "Nakamura",
   "number": 28
  },
  {
   "id": "REDW-23",
   "team": "REDW",
   "first": "Nina",
   "last": "Haugen",
   "number": 23
  },
  {
   "id": "REDW-52",
   "team": "REDW",
   "first": "Lana",
   "last": "Pham",
   "number": 52
  },
  {
   "id": "REDW-70",
   "team": "REDW",
   "first": "Camila",
   "last": "Kowalski",
   "number": 70
  },
  {
   "id": "REDW-3",
   "team": "REDW",
   "first": "Carla",
   "last": "Gallo",
   "number": 3
  },
  {
   "id": "REDW-93",
   "team": "REDW",
   "first": "Leah",
   "last": "Oyelaran",
   "number": 93
  },
  {
   "id": "REDW-13",
   "team": "REDW",
   "first": "Nadia",
   "last": "Coleman",
   "number": 13
  },
  {
   "id": "REDW-38",
   "team": "REDW",
   "first": "Elena",
   "last": "Keller",
   "number": 38
  },
  {
   "id": "DES-1",
   "team": "DES",
   "first": "Uma",
   "last": "Oyelaran",
   "number": 1
  },
  {
   "id": "DES-12",
   "team": "DES",
   "first": "Grace",
   "last": "Coleman",
   "number": 12
  },
  {
   "id": "DES-84",
   "team": "DES",
   "first": "Lana",
   "last": "Terzic",
   "number": 84
  },
  {
   "id": "DES-50",
   "team": "DES",
   "first": "Priya",
   "last": "Keller",
   "number": 50
  },
  {
   "id": "DES-9",
   "team": "DES",
   "first": "Maja",
   "last": "Kaplan",
   "number": 9
  },
  {
   "id": "DES-10",
   "team": "DES",
   "first": "Abigail",
   "last": "Madsen",
   "number": 10
  },
  {
   "id": "DES-77",
   "team": "DES",
   "first": "Beatriz",
   "last": "Ferreira",
   "number": 77
  },
  {
   "id": "DES-34",
   "team": "DES",
   "first": "Lucia",
   "last": "Vasquez",
   "number": 34
  },
  {
   "id": "DES-17",
   "team": "DES",
   "first": "Leah",
   "last": "Ishikawa",
   "number": 17
  },
  {
   "id": "DES-23",
   "team": "DES",
   "first": "Talia",
   "last": "Singh",
   "number": 23
  },
  {
   "id": "DES-2",
   "team": "DES",
   "first": "Edda",
   "last": "Haddad",
   "number": 2
  },
  {
   "id": "DES-51",
   "team": "DES",
   "first": "Nadia",
   "last": "Torres",
   "number": 51
  },
  {
   "id": "DES-20",
   "team": "DES",
   "first": "Celine",
   "last": "Nakamura",
   "number": 20
  },
  {
   "id": "DES-14",
   "team": "DES",
   "first": "Hana",
   "last": "Brennan",
   "number": 14
  },
  {
   "id": "DES-82",
   "team": "DES",
   "first": "Vera",
   "last": "Calloway",
   "number": 82
  },
  {
   "id": "DES-11",
   "team": "DES",
   "first": "Marta",
   "last": "Brennan",
   "number": 11
  },
  {
   "id": "BAY-1",
   "team": "BAY",
   "first": "Carla",
   "last": "Halvorsen",
   "number": 1
  },
  {
   "id": "BAY-12",
   "team": "BAY",
   "first": "Wren",
   "last": "Laine",
   "number": 12
  },
  {
   "id": "BAY-7",
   "team": "BAY",
   "first": "Aisha",
   "last": "Singh",
   "number": 7
  },
  {
   "id": "BAY-63",
   "team": "BAY",
   "first": "Camila",
   "last": "Nyberg",
   "number": 63
  },
  {
   "id": "BAY-65",
   "team": "BAY",
   "first": "Anika",
   "last": "Sorensen",
   "number": 65
  },
  {
   "id": "BAY-22",
   "team": "BAY",
   "first": "Marta",
   "last": "Olsen",
   "number": 22
  },
  {
   "id": "BAY-86",
   "team": "BAY",
   "first": "Nadia",
   "last": "Calloway",
   "number": 86
  },
  {
   "id": "BAY-17",
   "team": "BAY",
   "first": "Lotte",
   "last": "Sauer",
   "number": 17
  },
  {
   "id": "BAY-18",
   "team": "BAY",
   "first": "Astrid",
   "last": "Cruz",
   "number": 18
  },
  {
   "id": "BAY-94",
   "team": "BAY",
   "first": "Yuki",
   "last": "Almeida",
   "number": 94
  },
  {
   "id": "BAY-80",
   "team": "BAY",
   "first": "Edda",
   "last": "Demir",
   "number": 80
  },
  {
   "id": "BAY-64",
   "team": "BAY",
   "first": "Jade",
   "last": "Moretti",
   "number": 64
  },
  {
   "id": "BAY-25",
   "team": "BAY",
   "first": "Josie",
   "last": "Quinn",
   "number": 25
  },
  {
   "id": "BAY-67",
   "team": "BAY",
   "first": "Adaeze",
   "last": "Coleman",
   "number": 67
  },
  {
   "id": "BAY-8",
   "team": "BAY",
   "first": "Rania",
   "last": "Yilmaz",
   "number": 8
  },
  {
   "id": "BAY-50",
   "team": "BAY",
   "first": "Selin",
   "last": "Olsen",
   "number": 50
  }
 ],
 "goals": [
  {
   "game": 3,
   "player": "CAN-3",
   "goals": 1
  },
  {
   "game": 3,
   "player": "CAN-18",
   "goals": 1
  },
  {
   "game": 3,
   "player": "CAN-31",
   "goals": 3
  },
  {
   "game": 3,
   "player": "CAN-37",
   "goals": 5
  },
  {
   "game": 3,
   "player": "CAN-38",
   "goals": 3
  },
  {
   "game": 3,
   "player": "CAN-39",
   "goals": 1
  },
  {
   "game": 3,
   "player": "CAN-58",
   "goals": 2
  },
  {
   "game": 3,
   "player": "CAN-59",
   "goals": 2
  },
  {
   "game": 3,
   "player": "CAN-62",
   "goals": 3
  },
  {
   "game": 3,
   "player": "CAN-68",
   "goals": 1
  },
  {
   "game": 3,
   "player": "CAN-82",
   "goals": 1
  },
  {
   "game": 3,
   "player": "CAN-90",
   "goals": 1
  },
  {
   "game": 3,
   "player": "CAN-95",
   "goals": 1
  },
  {
   "game": 3,
   "player": "CAN-96",
   "goals": 1
  },
  {
   "game": 8,
   "player": "HAR-6",
   "goals": 3
  },
  {
   "game": 2,
   "player": "HAR-10",
   "goals": 2
  },
  {
   "game": 8,
   "player": "HAR-10",
   "goals": 6
  },
  {
   "game": 2,
   "player": "HAR-29",
   "goals": 7
  },
  {
   "game": 8,
   "player": "HAR-29",
   "goals": 1
  },
  {
   "game": 2,
   "player": "HAR-50",
   "goals": 2
  },
  {
   "game": 8,
   "player": "HAR-50",
   "goals": 1
  },
  {
   "game": 2,
   "player": "HAR-56",
   "goals": 2
  },
  {
   "game": 8,
   "player": "HAR-56",
   "goals": 3
  },
  {
   "game": 2,
   "player": "HAR-58",
   "goals": 3
  },
  {
   "game": 2,
   "player": "HAR-59",
   "goals": 3
  },
  {
   "game": 8,
   "player": "HAR-59",
   "goals": 2
  },
  {
   "game": 8,
   "player": "HAR-65",
   "goals": 1
  },
  {
   "game": 2,
   "player": "HAR-77",
   "goals": 1
  },
  {
   "game": 8,
   "player": "HAR-77",
   "goals": 1
  },
  {
   "game": 2,
   "player": "HAR-87",
   "goals": 4
  },
  {
   "game": 2,
   "player": "HAR-89",
   "goals": 2
  },
  {
   "game": 8,
   "player": "HAR-89",
   "goals": 6
  },
  {
   "game": 2,
   "player": "HAR-92",
   "goals": 5
  },
  {
   "game": 8,
   "player": "HAR-92",
   "goals": 3
  },
  {
   "game": 2,
   "player": "LAK-23",
   "goals": 2
  },
  {
   "game": 12,
   "player": "LAK-23",
   "goals": 3
  },
  {
   "game": 2,
   "player": "LAK-28",
   "goals": 1
  },
  {
   "game": 12,
   "player": "LAK-28",
   "goals": 1
  },
  {
   "game": 2,
   "player": "LAK-39",
   "goals": 1
  },
  {
   "game": 12,
   "player": "LAK-39",
   "goals": 2
  },
  {
   "game": 2,
   "player": "LAK-49",
   "goals": 1
  },
  {
   "game": 12,
   "player": "LAK-49",
   "goals": 3
  },
  {
   "game": 12,
   "player": "LAK-52",
   "goals": 1
  },
  {
   "game": 2,
   "player": "LAK-54",
   "goals": 1
  },
  {
   "game": 12,
   "player": "LAK-54",
   "goals": 4
  },
  {
   "game": 2,
   "player": "LAK-55",
   "goals": 3
  },
  {
   "game": 12,
   "player": "LAK-55",
   "goals": 3
  },
  {
   "game": 2,
   "player": "LAK-59",
   "goals": 2
  },
  {
   "game": 12,
   "player": "LAK-59",
   "goals": 2
  },
  {
   "game": 2,
   "player": "LAK-62",
   "goals": 5
  },
  {
   "game": 12,
   "player": "LAK-62",
   "goals": 1
  },
  {
   "game": 2,
   "player": "LAK-91",
   "goals": 1
  },
  {
   "game": 12,
   "player": "LAK-91",
   "goals": 1
  },
  {
   "game": 12,
   "player": "LAK-94",
   "goals": 2
  },
  {
   "game": 2,
   "player": "LAK-97",
   "goals": 6
  },
  {
   "game": 12,
   "player": "LAK-97",
   "goals": 3
  },
  {
   "game": 2,
   "player": "LAK-98",
   "goals": 5
  },
  {
   "game": 12,
   "player": "LAK-98",
   "goals": 3
  },
  {
   "game": 5,
   "player": "MES-6",
   "goals": 2
  },
  {
   "game": 8,
   "player": "MES-6",
   "goals": 2
  },
  {
   "game": 5,
   "player": "MES-8",
   "goals": 4
  },
  {
   "game": 8,
   "player": "MES-8",
   "goals": 3
  },
  {
   "game": 5,
   "player": "MES-13",
   "goals": 4
  },
  {
   "game": 8,
   "player": "MES-13",
   "goals": 4
  },
  {
   "game": 5,
   "player": "MES-19",
   "goals": 2
  },
  {
   "game": 8,
   "player": "MES-19",
   "goals": 3
  },
  {
   "game": 5,
   "player": "MES-25",
   "goals": 2
  },
  {
   "game": 8,
   "player": "MES-25",
   "goals": 3
  },
  {
   "game": 5,
   "player": "MES-39",
   "goals": 1
  },
  {
   "game": 5,
   "player": "MES-46",
   "goals": 3
  },
  {
   "game": 8,
   "player": "MES-46",
   "goals": 1
  },
  {
   "game": 5,
   "player": "MES-49",
   "goals": 1
  },
  {
   "game": 8,
   "player": "MES-49",
   "goals": 3
  },
  {
   "game": 5,
   "player": "MES-50",
   "goals": 2
  },
  {
   "game": 8,
   "player": "MES-50",
   "goals": 2
  },
  {
   "game": 5,
   "player": "MES-53",
   "goals": 5
  },
  {
   "game": 8,
   "player": "MES-53",
   "goals": 4
  },
  {
   "game": 5,
   "player": "MES-55",
   "goals": 1
  },
  {
   "game": 8,
   "player": "MES-75",
   "goals": 1
  },
  {
   "game": 5,
   "player": "MES-80",
   "goals": 4
  },
  {
   "game": 8,
   "player": "MES-80",
   "goals": 5
  },
  {
   "game": 5,
   "player": "MES-83",
   "goals": 2
  },
  {
   "game": 8,
   "player": "MES-83",
   "goals": 1
  },
  {
   "game": 5,
   "player": "NOR-2",
   "goals": 1
  },
  {
   "game": 12,
   "player": "NOR-2",
   "goals": 1
  },
  {
   "game": 5,
   "player": "NOR-5",
   "goals": 3
  },
  {
   "game": 12,
   "player": "NOR-5",
   "goals": 1
  },
  {
   "game": 5,
   "player": "NOR-9",
   "goals": 1
  },
  {
   "game": 12,
   "player": "NOR-9",
   "goals": 2
  },
  {
   "game": 5,
   "player": "NOR-17",
   "goals": 2
  },
  {
   "game": 12,
   "player": "NOR-17",
   "goals": 5
  },
  {
   "game": 5,
   "player": "NOR-25",
   "goals": 1
  },
  {
   "game": 12,
   "player": "NOR-25",
   "goals": 3
  },
  {
   "game": 5,
   "player": "NOR-31",
   "goals": 3
  },
  {
   "game": 12,
   "player": "NOR-31",
   "goals": 1
  },
  {
   "game": 5,
   "player": "NOR-34",
   "goals": 1
  },
  {
   "game": 12,
   "player": "NOR-34",
   "goals": 3
  },
  {
   "game": 12,
   "player": "NOR-47",
   "goals": 1
  },
  {
   "game": 12,
   "player": "NOR-56",
   "goals": 1
  },
  {
   "game": 5,
   "player": "NOR-61",
   "goals": 3
  },
  {
   "game": 12,
   "player": "NOR-61",
   "goals": 1
  },
  {
   "game": 5,
   "player": "NOR-68",
   "goals": 4
  },
  {
   "game": 12,
   "player": "NOR-68",
   "goals": 4
  },
  {
   "game": 5,
   "player": "NOR-91",
   "goals": 4
  },
  {
   "game": 12,
   "player": "NOR-91",
   "goals": 2
  },
  {
   "game": 5,
   "player": "NOR-96",
   "goals": 4
  },
  {
   "game": 12,
   "player": "NOR-96",
   "goals": 4
  },
  {
   "game": 6,
   "player": "PAC-3",
   "goals": 7
  },
  {
   "game": 10,
   "player": "PAC-3",
   "goals": 2
  },
  {
   "game": 6,
   "player": "PAC-6",
   "goals": 1
  },
  {
   "game": 10,
   "player": "PAC-6",
   "goals": 3
  },
  {
   "game": 6,
   "player": "PAC-10",
   "goals": 1
  },
  {
   "game": 6,
   "player": "PAC-15",
   "goals": 5
  },
  {
   "game": 10,
   "player": "PAC-23",
   "goals": 2
  },
  {
   "game": 10,
   "player": "PAC-25",
   "goals": 1
  },
  {
   "game": 6,
   "player": "PAC-26",
   "goals": 2
  },
  {
   "game": 10,
   "player": "PAC-26",
   "goals": 4
  },
  {
   "game": 6,
   "player": "PAC-30",
   "goals": 1
  },
  {
   "game": 10,
   "player": "PAC-30",
   "goals": 1
  },
  {
   "game": 6,
   "player": "PAC-55",
   "goals": 1
  },
  {
   "game": 10,
   "player": "PAC-55",
   "goals": 6
  },
  {
   "game": 6,
   "player": "PAC-70",
   "goals": 2
  },
  {
   "game": 10,
   "player": "PAC-71",
   "goals": 2
  },
  {
   "game": 6,
   "player": "PAC-76",
   "goals": 1
  },
  {
   "game": 10,
   "player": "PAC-76",
   "goals": 1
  },
  {
   "game": 6,
   "player": "PAC-79",
   "goals": 3
  },
  {
   "game": 10,
   "player": "PAC-79",
   "goals": 2
  },
  {
   "game": 10,
   "player": "PAC-88",
   "goals": 1
  },
  {
   "game": 3,
   "player": "RED-11",
   "goals": 2
  },
  {
   "game": 10,
   "player": "RED-11",
   "goals": 2
  },
  {
   "game": 3,
   "player": "RED-25",
   "goals": 3
  },
  {
   "game": 10,
   "player": "RED-25",
   "goals": 1
  },
  {
   "game": 3,
   "player": "RED-28",
   "goals": 1
  },
  {
   "game": 10,
   "player": "RED-28",
   "goals": 2
  },
  {
   "game": 3,
   "player": "RED-30",
   "goals": 1
  },
  {
   "game": 10,
   "player": "RED-30",
   "goals": 6
  },
  {
   "game": 3,
   "player": "RED-41",
   "goals": 3
  },
  {
   "game": 10,
   "player": "RED-41",
   "goals": 6
  },
  {
   "game": 3,
   "player": "RED-47",
   "goals": 1
  },
  {
   "game": 10,
   "player": "RED-47",
   "goals": 3
  },
  {
   "game": 3,
   "player": "RED-58",
   "goals": 4
  },
  {
   "game": 10,
   "player": "RED-58",
   "goals": 3
  },
  {
   "game": 3,
   "player": "RED-59",
   "goals": 2
  },
  {
   "game": 10,
   "player": "RED-59",
   "goals": 1
  },
  {
   "game": 3,
   "player": "RED-69",
   "goals": 4
  },
  {
   "game": 10,
   "player": "RED-69",
   "goals": 3
  },
  {
   "game": 3,
   "player": "RED-71",
   "goals": 4
  },
  {
   "game": 10,
   "player": "RED-71",
   "goals": 2
  },
  {
   "game": 3,
   "player": "RED-73",
   "goals": 1
  },
  {
   "game": 10,
   "player": "RED-73",
   "goals": 1
  },
  {
   "game": 3,
   "player": "RED-85",
   "goals": 2
  },
  {
   "game": 10,
   "player": "RED-85",
   "goals": 1
  },
  {
   "game": 3,
   "player": "RED-90",
   "goals": 1
  },
  {
   "game": 10,
   "player": "RED-90",
   "goals": 1
  },
  {
   "game": 10,
   "player": "RED-96",
   "goals": 2
  },
  {
   "game": 6,
   "player": "SUM-2",
   "goals": 1
  },
  {
   "game": 6,
   "player": "SUM-9",
   "goals": 3
  },
  {
   "game": 6,
   "player": "SUM-24",
   "goals": 4
  },
  {
   "game": 6,
   "player": "SUM-25",
   "goals": 1
  },
  {
   "game": 6,
   "player": "SUM-26",
   "goals": 3
  },
  {
   "game": 6,
   "player": "SUM-35",
   "goals": 2
  },
  {
   "game": 6,
   "player": "SUM-45",
   "goals": 2
  },
  {
   "game": 6,
   "player": "SUM-47",
   "goals": 4
  },
  {
   "game": 6,
   "player": "SUM-70",
   "goals": 1
  },
  {
   "game": 6,
   "player": "SUM-83",
   "goals": 2
  },
  {
   "game": 6,
   "player": "SUM-91",
   "goals": 2
  },
  {
   "game": 6,
   "player": "SUM-98",
   "goals": 5
  },
  {
   "game": 4,
   "player": "BAY-7",
   "goals": 3
  },
  {
   "game": 9,
   "player": "BAY-7",
   "goals": 3
  },
  {
   "game": 11,
   "player": "BAY-7",
   "goals": 1
  },
  {
   "game": 4,
   "player": "BAY-8",
   "goals": 2
  },
  {
   "game": 11,
   "player": "BAY-8",
   "goals": 6
  },
  {
   "game": 4,
   "player": "BAY-17",
   "goals": 2
  },
  {
   "game": 9,
   "player": "BAY-17",
   "goals": 2
  },
  {
   "game": 4,
   "player": "BAY-18",
   "goals": 3
  },
  {
   "game": 11,
   "player": "BAY-18",
   "goals": 4
  },
  {
   "game": 4,
   "player": "BAY-22",
   "goals": 2
  },
  {
   "game": 9,
   "player": "BAY-22",
   "goals": 1
  },
  {
   "game": 11,
   "player": "BAY-22",
   "goals": 1
  },
  {
   "game": 4,
   "player": "BAY-25",
   "goals": 1
  },
  {
   "game": 9,
   "player": "BAY-25",
   "goals": 1
  },
  {
   "game": 11,
   "player": "BAY-25",
   "goals": 3
  },
  {
   "game": 4,
   "player": "BAY-50",
   "goals": 1
  },
  {
   "game": 11,
   "player": "BAY-50",
   "goals": 1
  },
  {
   "game": 4,
   "player": "BAY-63",
   "goals": 1
  },
  {
   "game": 9,
   "player": "BAY-63",
   "goals": 3
  },
  {
   "game": 11,
   "player": "BAY-63",
   "goals": 1
  },
  {
   "game": 9,
   "player": "BAY-64",
   "goals": 3
  },
  {
   "game": 11,
   "player": "BAY-64",
   "goals": 1
  },
  {
   "game": 4,
   "player": "BAY-65",
   "goals": 2
  },
  {
   "game": 9,
   "player": "BAY-65",
   "goals": 4
  },
  {
   "game": 11,
   "player": "BAY-65",
   "goals": 3
  },
  {
   "game": 11,
   "player": "BAY-67",
   "goals": 1
  },
  {
   "game": 4,
   "player": "BAY-80",
   "goals": 2
  },
  {
   "game": 9,
   "player": "BAY-80",
   "goals": 5
  },
  {
   "game": 11,
   "player": "BAY-80",
   "goals": 2
  },
  {
   "game": 4,
   "player": "BAY-86",
   "goals": 3
  },
  {
   "game": 9,
   "player": "BAY-86",
   "goals": 2
  },
  {
   "game": 11,
   "player": "BAY-86",
   "goals": 2
  },
  {
   "game": 4,
   "player": "BAY-94",
   "goals": 3
  },
  {
   "game": 9,
   "player": "BAY-94",
   "goals": 5
  },
  {
   "game": 11,
   "player": "BAY-94",
   "goals": 1
  },
  {
   "game": 9,
   "player": "DES-2",
   "goals": 3
  },
  {
   "game": 1,
   "player": "DES-9",
   "goals": 5
  },
  {
   "game": 1,
   "player": "DES-10",
   "goals": 3
  },
  {
   "game": 9,
   "player": "DES-10",
   "goals": 3
  },
  {
   "game": 9,
   "player": "DES-11",
   "goals": 1
  },
  {
   "game": 1,
   "player": "DES-14",
   "goals": 1
  },
  {
   "game": 9,
   "player": "DES-14",
   "goals": 2
  },
  {
   "game": 1,
   "player": "DES-17",
   "goals": 1
  },
  {
   "game": 9,
   "player": "DES-17",
   "goals": 3
  },
  {
   "game": 1,
   "player": "DES-20",
   "goals": 3
  },
  {
   "game": 9,
   "player": "DES-20",
   "goals": 2
  },
  {
   "game": 1,
   "player": "DES-23",
   "goals": 3
  },
  {
   "game": 1,
   "player": "DES-34",
   "goals": 1
  },
  {
   "game": 9,
   "player": "DES-34",
   "goals": 2
  },
  {
   "game": 9,
   "player": "DES-50",
   "goals": 2
  },
  {
   "game": 1,
   "player": "DES-51",
   "goals": 2
  },
  {
   "game": 9,
   "player": "DES-51",
   "goals": 2
  },
  {
   "game": 1,
   "player": "DES-77",
   "goals": 1
  },
  {
   "game": 9,
   "player": "DES-77",
   "goals": 1
  },
  {
   "game": 1,
   "player": "DES-82",
   "goals": 3
  },
  {
   "game": 1,
   "player": "DES-84",
   "goals": 1
  },
  {
   "game": 9,
   "player": "DES-84",
   "goals": 1
  },
  {
   "game": 7,
   "player": "HARW-6",
   "goals": 2
  },
  {
   "game": 1,
   "player": "HARW-7",
   "goals": 1
  },
  {
   "game": 7,
   "player": "HARW-7",
   "goals": 1
  },
  {
   "game": 11,
   "player": "HARW-7",
   "goals": 3
  },
  {
   "game": 7,
   "player": "HARW-9",
   "goals": 3
  },
  {
   "game": 1,
   "player": "HARW-11",
   "goals": 1
  },
  {
   "game": 7,
   "player": "HARW-11",
   "goals": 2
  },
  {
   "game": 1,
   "player": "HARW-29",
   "goals": 2
  },
  {
   "game": 7,
   "player": "HARW-29",
   "goals": 1
  },
  {
   "game": 11,
   "player": "HARW-29",
   "goals": 1
  },
  {
   "game": 1,
   "player": "HARW-32",
   "goals": 1
  },
  {
   "game": 7,
   "player": "HARW-32",
   "goals": 2
  },
  {
   "game": 11,
   "player": "HARW-32",
   "goals": 2
  },
  {
   "game": 1,
   "player": "HARW-39",
   "goals": 1
  },
  {
   "game": 7,
   "player": "HARW-39",
   "goals": 4
  },
  {
   "game": 11,
   "player": "HARW-39",
   "goals": 1
  },
  {
   "game": 1,
   "player": "HARW-51",
   "goals": 2
  },
  {
   "game": 7,
   "player": "HARW-51",
   "goals": 2
  },
  {
   "game": 11,
   "player": "HARW-51",
   "goals": 3
  },
  {
   "game": 1,
   "player": "HARW-61",
   "goals": 4
  },
  {
   "game": 7,
   "player": "HARW-61",
   "goals": 1
  },
  {
   "game": 11,
   "player": "HARW-61",
   "goals": 6
  },
  {
   "game": 1,
   "player": "HARW-76",
   "goals": 2
  },
  {
   "game": 7,
   "player": "HARW-76",
   "goals": 2
  },
  {
   "game": 1,
   "player": "HARW-81",
   "goals": 4
  },
  {
   "game": 7,
   "player": "HARW-81",
   "goals": 1
  },
  {
   "game": 11,
   "player": "HARW-81",
   "goals": 3
  },
  {
   "game": 1,
   "player": "HARW-86",
   "goals": 8
  },
  {
   "game": 7,
   "player": "HARW-86",
   "goals": 4
  },
  {
   "game": 11,
   "player": "HARW-86",
   "goals": 5
  },
  {
   "game": 1,
   "player": "HARW-94",
   "goals": 1
  },
  {
   "game": 7,
   "player": "HARW-94",
   "goals": 3
  },
  {
   "game": 11,
   "player": "HARW-94",
   "goals": 1
  },
  {
   "game": 4,
   "player": "REDW-3",
   "goals": 2
  },
  {
   "game": 7,
   "player": "REDW-3",
   "goals": 1
  },
  {
   "game": 7,
   "player": "REDW-13",
   "goals": 2
  },
  {
   "game": 4,
   "player": "REDW-23",
   "goals": 2
  },
  {
   "game": 7,
   "player": "REDW-23",
   "goals": 1
  },
  {
   "game": 4,
   "player": "REDW-28",
   "goals": 3
  },
  {
   "game": 7,
   "player": "REDW-28",
   "goals": 1
  },
  {
   "game": 4,
   "player": "REDW-37",
   "goals": 2
  },
  {
   "game": 7,
   "player": "REDW-37",
   "goals": 1
  },
  {
   "game": 7,
   "player": "REDW-38",
   "goals": 1
  },
  {
   "game": 4,
   "player": "REDW-45",
   "goals": 5
  },
  {
   "game": 7,
   "player": "REDW-45",
   "goals": 1
  },
  {
   "game": 4,
   "player": "REDW-52",
   "goals": 3
  },
  {
   "game": 7,
   "player": "REDW-52",
   "goals": 3
  },
  {
   "game": 7,
   "player": "REDW-54",
   "goals": 1
  },
  {
   "game": 4,
   "player": "REDW-70",
   "goals": 1
  },
  {
   "game": 7,
   "player": "REDW-70",
   "goals": 2
  },
  {
   "game": 4,
   "player": "REDW-84",
   "goals": 1
  },
  {
   "game": 7,
   "player": "REDW-84",
   "goals": 1
  },
  {
   "game": 4,
   "player": "REDW-91",
   "goals": 1
  },
  {
   "game": 7,
   "player": "REDW-91",
   "goals": 6
  },
  {
   "game": 4,
   "player": "REDW-93",
   "goals": 2
  },
  {
   "game": 4,
   "player": "REDW-96",
   "goals": 1
  }
 ]
};

/* Tournament site. Reads window.TOURNAMENT (data/data.js) and renders the current page.
   No framework, no build step. Standings and scorers are computed here from games and goals. */
(function () {
  "use strict";

  var T = window.TOURNAMENT;
  var app = document.getElementById("app");
  var page = document.body.getAttribute("data-page") || "home";

  if (!T || !T.meta) {
    if (app) app.innerHTML = '<div class="card"><p>Tournament data is missing. Run the converter to create data/data.js.</p></div>';
    return;
  }

  var meta = T.meta;
  var teams = T.teams || [];
  var games = T.games || [];
  var players = T.players || [];
  var goals = T.goals || [];
  var teamById = {};
  teams.forEach(function (t) { teamById[t.id] = t; });
  var playerById = {};
  players.forEach(function (p) { playerById[p.id] = p; });
  var points = meta.points || { win: 2, draw: 1, loss: 0 };
  /* Live game stats (score.html, live.html, netlify/functions/live.mjs). Set to false if you do not run them:
     the "Live stats" menu item and the link on each game disappear. */
  var LIVE_STATS = true;

  /* ---------- helpers ---------- */
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function isHex(c) { return /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(c || ""); }
  function hex6(c) { c = c.replace("#", ""); if (c.length === 3) c = c.split("").map(function (x) { return x + x; }).join(""); return c; }
  function luminance(c) {
    var h = hex6(c);
    var rgb = [0, 2, 4].map(function (i) {
      var v = parseInt(h.substr(i, 2), 16) / 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
  }
  /* Pick black or white text, whichever reads better on the given background. */
  function textOn(bg) {
    if (!isHex(bg)) return "#ffffff";
    var L = luminance(bg);
    return (1.05 / (L + 0.05)) >= ((L + 0.05) / 0.05) ? "#ffffff" : "#111111";
  }
  function isTBD(id) { return !id || String(id).toUpperCase() === "TBD" || !teamById[id]; }
  function teamName(id) { return isTBD(id) ? "TBD" : teamById[id].name; }
  function teamLabel(id) {
    return isTBD(id) ? '<span class="tbd">TBD</span>' : esc(teamById[id].name);
  }
  function isFinal(g) { return g.status === "Final" && g.scoreA != null && g.scoreB != null; }
  /* Standings count group stage games only: Round starts with "Group" or is "Round robin". */
  function isGroupGame(g) {
    var r = String(g.round || "").trim().toLowerCase();
    return r.indexOf("group") === 0 || r === "round robin";
  }
  function sortKey(g) { return (g.date || "") + " " + (g.time || "") + " " + ("0000" + (g.no || 0)).slice(-4); }
  function byTime(a, b) { return sortKey(a) < sortKey(b) ? -1 : sortKey(a) > sortKey(b) ? 1 : 0; }
  function fmtDate(iso) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(iso || "")) return esc(iso || "");
    var p = iso.split("-");
    var d = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2]));
    return d.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric", timeZone: "UTC" });
  }
  function unique(arr) { var o = []; arr.forEach(function (x) { if (x !== "" && x != null && o.indexOf(x) < 0) o.push(x); }); return o; }
  function divisions() { return unique(teams.map(function (t) { return t.division; }).concat(games.map(function (g) { return g.division; }))); }

  /* ---------- theme ---------- */
  var root = document.documentElement.style;
  if (isHex(meta.primaryColor)) { root.setProperty("--primary", meta.primaryColor); root.setProperty("--primary-text", textOn(meta.primaryColor)); }
  if (isHex(meta.accentColor)) root.setProperty("--accent", meta.accentColor);
  var brand = document.querySelector(".brand");
  if (brand) brand.textContent = meta.name || "Tournament";
  document.title = (document.title ? document.title + " | " : "") + (meta.name || "Tournament");
  var navEl = document.querySelector(".nav");
  if (LIVE_STATS && navEl && !navEl.querySelector('[data-page="live"]')) {
    var liveLink = document.createElement("a");
    liveLink.href = "live.html"; liveLink.setAttribute("data-page", "live"); liveLink.textContent = "Live stats";
    var watchLink = navEl.querySelector('[data-page="watch"]');
    navEl.insertBefore(liveLink, watchLink ? watchLink.nextSibling : null);
  }
  var cur = document.querySelector('.nav a[data-page="' + page + '"]');
  if (cur) cur.setAttribute("aria-current", "page");
  var upd = document.getElementById("updated");
  if (upd && meta.generatedAt) {
    var dt = new Date(meta.generatedAt);
    upd.textContent = "Last updated " + (isNaN(dt) ? meta.generatedAt : dt.toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })) + ".";
  }

  /* ---------- computations ---------- */
  function computeStandings() {
    /* returns [{division, group, rows:[...]}] */
    var out = [];
    divisions().forEach(function (div) {
      var divTeams = teams.filter(function (t) { return t.division === div; });
      var groups = unique(divTeams.map(function (t) { return t.group || ""; }));
      if (divTeams.some(function (t) { return !t.group; }) && groups.indexOf("") < 0) groups.push("");
      groups.sort();
      groups.forEach(function (grp) {
        var gTeams = divTeams.filter(function (t) { return (t.group || "") === grp; });
        var rows = {};
        gTeams.forEach(function (t) { rows[t.id] = { team: t, P: 0, W: 0, D: 0, L: 0, GF: 0, GA: 0, GD: 0, Pts: 0 }; });
        games.forEach(function (g) {
          if (!isFinal(g) || !isGroupGame(g) || !rows[g.a] || !rows[g.b]) return;
          [[g.a, g.scoreA, g.scoreB], [g.b, g.scoreB, g.scoreA]].forEach(function (x) {
            var r = rows[x[0]];
            r.P++; r.GF += x[1]; r.GA += x[2];
            if (x[1] > x[2]) r.W++; else if (x[1] === x[2]) r.D++; else r.L++;
          });
        });
        var list = Object.keys(rows).map(function (k) {
          var r = rows[k];
          r.GD = r.GF - r.GA;
          r.Pts = r.W * points.win + r.D * points.draw + r.L * points.loss;
          return r;
        });
        list.sort(function (a, b) {
          return (b.Pts - a.Pts) || (b.GD - a.GD) || (b.GF - a.GF) || a.team.name.localeCompare(b.team.name);
        });
        out.push({ division: div, group: grp, rows: list });
      });
    });
    return out;
  }

  function computeScorers(div, limit) {
    var tot = {};
    goals.forEach(function (x) {
      var p = playerById[x.player];
      if (!p) return;
      var t = teamById[p.team];
      if (!t || t.division !== div) return;
      tot[x.player] = (tot[x.player] || 0) + (Number(x.goals) || 0);
    });
    var list = Object.keys(tot).filter(function (k) { return tot[k] > 0; }).map(function (k) {
      return { player: playerById[k], goals: tot[k] };
    });
    list.sort(function (a, b) {
      return (b.goals - a.goals) || a.player.last.localeCompare(b.player.last) || a.player.first.localeCompare(b.player.first);
    });
    return list.slice(0, limit || 20);
  }

  /* ---------- renderers ---------- */
  function gameRow(g, opts) {
    opts = opts || {};
    var fin = isFinal(g);
    var aWin = fin && g.scoreA > g.scoreB, bWin = fin && g.scoreB > g.scoreA;
    var when = '<div class="when">' + esc(g.time || "") + (opts.showDay ? "<small>" + esc(g.day || "") + "</small>" : "") + "</div>";
    var tms = '<div class="teams"><div class="' + (aWin ? "win" : "") + '">' + teamLabel(g.a) + '</div><div class="' + (bWin ? "win" : "") + '">' + teamLabel(g.b) + "</div></div>";
    var score = fin
      ? '<div class="score" aria-label="Final score ' + esc(g.scoreA) + " to " + esc(g.scoreB) + '"><span>' + esc(g.scoreA) + "</span><span>" + esc(g.scoreB) + "</span></div>"
      : '<div class="score"><span class="pill">' + esc(g.status || "Scheduled") + "</span></div>";
    var m = [g.division, g.round, g.court, g.no != null ? "Game " + g.no : ""].filter(Boolean).map(esc).join(" · ");
    if (fin) m += ' <span class="pill final">Final</span>';
    if (LIVE_STATS && g.no != null && !isTBD(g.a) && !isTBD(g.b)) m += ' · <a href="live.html?game=' + encodeURIComponent(g.no) + '">Live stats</a>';
    return '<div class="game" data-game="' + esc(g.no) + '">' + when + tms + score + '<div class="meta">' + m + "</div></div>";
  }

  function renderHome() {
    var upcoming = games.filter(function (g) { return !isFinal(g); }).sort(byTime).slice(0, 4);
    var latest = games.filter(isFinal).sort(byTime).reverse().slice(0, 4);
    var h = '<section class="card hero"><h1>' + esc(meta.name) + "</h1>" +
      (meta.edition ? '<p class="muted">' + esc(meta.edition) + (meta.host ? " · Hosted by " + esc(meta.host) : "") + "</p>" : "") +
      "<p><strong>" + esc(meta.dates) + "</strong></p>" +
      "<p>" + esc(meta.venue) + (meta.venueAddress ? ", " + esc(meta.venueAddress) : "") + "</p></section>";
    h += '<nav class="quick" aria-label="Quick links"><a href="schedule.html">Schedule</a><a href="standings.html">Standings</a><a href="scorers.html">Top scorers</a><a href="teams.html">Teams</a><a href="watch.html">Watch live</a></nav>';
    h += '<div class="grid two">';
    h += '<section><h2>Next games</h2><div class="card" id="next-games">' + (upcoming.length ? upcoming.map(function (g) { return gameRow(g, { showDay: true }); }).join("") : '<p class="muted">No games left on the schedule.</p>') + "</div></section>";
    h += '<section><h2>Latest results</h2><div class="card" id="latest-results">' + (latest.length ? latest.map(function (g) { return gameRow(g, { showDay: true }); }).join("") : '<p class="muted">No results yet. Results are posted after each game.</p>') + "</div></section>";
    h += "</div>";
    app.innerHTML = h;
  }

  function renderSchedule() {
    var divs = divisions();
    var days = unique(games.slice().sort(byTime).map(function (g) { return g.date; }));
    var params = new URLSearchParams(location.search);
    var h = "<h1>Schedule</h1>";
    h += '<div class="filters"><label>Division<select id="f-div"><option value="">All divisions</option>' +
      divs.map(function (d) { return '<option value="' + esc(d) + '">' + esc(d) + "</option>"; }).join("") + "</select></label>" +
      '<label>Day<select id="f-day"><option value="">All days</option>' +
      days.map(function (d) { return '<option value="' + esc(d) + '">' + fmtDate(d) + "</option>"; }).join("") + "</select></label></div>";
    h += '<div id="schedule-list"></div>';
    app.innerHTML = h;
    var fd = document.getElementById("f-div"), fy = document.getElementById("f-day");
    if (params.get("division")) fd.value = params.get("division");
    if (params.get("day")) fy.value = params.get("day");
    function draw() {
      var list = games.filter(function (g) { return (!fd.value || g.division === fd.value) && (!fy.value || g.date === fy.value); }).sort(byTime);
      var out = "";
      unique(list.map(function (g) { return g.date; })).forEach(function (d) {
        out += '<section class="day"><h2>' + fmtDate(d) + '</h2><div class="card">' +
          list.filter(function (g) { return g.date === d; }).map(function (g) { return gameRow(g); }).join("") + "</div></section>";
      });
      document.getElementById("schedule-list").innerHTML = out || '<p class="muted">No games match these filters.</p>';
    }
    fd.addEventListener("change", draw);
    fy.addEventListener("change", draw);
    draw();
  }

  function renderStandings() {
    var tables = computeStandings();
    var h = "<h1>Standings</h1><p class=\"muted\">Group games only. Win " + esc(points.win) + ", draw " + esc(points.draw) + ", loss " + esc(points.loss) + " points. Order: points, goal difference, goals for.</p>";
    var lastDiv = null;
    tables.forEach(function (tb) {
      if (tb.division !== lastDiv) { h += "<h2>" + esc(tb.division) + "</h2>"; lastDiv = tb.division; }
      var title = tb.group ? "Group " + tb.group : tb.division;
      h += '<div class="table-wrap"><table class="standings" data-division="' + esc(tb.division) + '" data-group="' + esc(tb.group) + '"><caption>' + esc(title) + "</caption>" +
        '<thead><tr><th scope="col" class="l">#</th><th scope="col" class="l">Team</th><th scope="col" title="Played">P</th><th scope="col" title="Won">W</th><th scope="col" title="Drawn">D</th><th scope="col" title="Lost">L</th><th scope="col" title="Goals for">GF</th><th scope="col" title="Goals against">GA</th><th scope="col" title="Goal difference">GD</th><th scope="col" title="Points">Pts</th></tr></thead><tbody>' +
        tb.rows.map(function (r, i) {
          return '<tr data-team="' + esc(r.team.id) + '"><td class="l">' + (i + 1) + '</td><td class="l">' + esc(r.team.name) + "</td><td>" + r.P + "</td><td>" + r.W + "</td><td>" + r.D + "</td><td>" + r.L + "</td><td>" + r.GF + "</td><td>" + r.GA + "</td><td>" + (r.GD > 0 ? "+" : "") + r.GD + '</td><td class="pts">' + r.Pts + "</td></tr>";
        }).join("") + "</tbody></table></div>";
    });
    h += '<p class="muted">If teams are still tied, the organizers apply the head to head result.</p>';
    app.innerHTML = h;
  }

  function renderScorers() {
    var h = "<h1>Top scorers</h1>";
    divisions().forEach(function (div) {
      var list = computeScorers(div, 20);
      h += "<h2>" + esc(div) + "</h2>";
      if (!list.length) { h += '<p class="muted">No goals recorded yet.</p>'; return; }
      h += '<div class="table-wrap"><table class="scorers" data-division="' + esc(div) + '"><thead><tr><th scope="col" class="l">#</th><th scope="col" class="l">Player</th><th scope="col" class="l">Team</th><th scope="col">Goals</th></tr></thead><tbody>' +
        list.map(function (s, i) {
          var t = teamById[s.player.team];
          return '<tr data-player="' + esc(s.player.id) + '"><td class="l">' + (i + 1) + '</td><td class="l">' + esc(s.player.first + " " + s.player.last) + (s.player.number != null ? ' <span class="muted">#' + esc(s.player.number) + "</span>" : "") + '</td><td class="l">' + esc(t ? t.name : s.player.team) + '</td><td class="pts">' + s.goals + "</td></tr>";
        }).join("") + "</tbody></table></div>";
    });
    app.innerHTML = h;
  }

  function renderTeams() {
    var h = "<h1>Teams</h1>";
    divisions().forEach(function (div) {
      var list = teams.filter(function (t) { return t.division === div; });
      if (!list.length) return;
      h += "<h2>" + esc(div) + '</h2><div class="team-grid">' + list.map(function (t) {
        var color = isHex(t.color) ? t.color : "#cccccc";
        var badge = '<div class="swatch" style="background:' + color + ";color:" + textOn(color) + '" aria-hidden="true">' + esc(t.short || t.id) + "</div>";
        var logo = t.logo ? '<img src="assets/logos/' + encodeURIComponent(t.logo) + '" alt="' + esc(t.name) + ' logo" loading="lazy">' : "";
        return '<div class="team-card" data-team="' + esc(t.id) + '">' + (logo || badge) +
          '<div class="name">' + esc(t.name) + "</div>" +
          '<div class="sub">' + esc([t.short, t.group ? "Group " + t.group : ""].filter(Boolean).join(" · ")) + "</div>" +
          '<div class="sub">' + esc([t.club, t.city].filter(Boolean).join(", ")) + "</div></div>";
      }).join("") + "</div>";
    });
    app.innerHTML = h;
    /* If a logo file is missing, fall back to the color badge. */
    Array.prototype.forEach.call(app.querySelectorAll(".team-card img"), function (img) {
      img.addEventListener("error", function () {
        var t = teamById[img.closest(".team-card").getAttribute("data-team")];
        var color = isHex(t.color) ? t.color : "#cccccc";
        var d = document.createElement("div");
        d.className = "swatch"; d.style.background = color; d.style.color = textOn(color); d.textContent = t.short || t.id;
        img.replaceWith(d);
      });
    });
  }

  function renderInfo() {
    var maps = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent([meta.venue, meta.venueAddress].filter(Boolean).join(", "));
    var h = "<h1>Event info</h1><div class=\"grid two\">";
    h += '<section class="card"><h2>Dates</h2><p><strong>' + esc(meta.dates) + "</strong></p>" + (meta.edition ? '<p class="muted">' + esc(meta.edition) + "</p>" : "") + "</section>";
    h += '<section class="card"><h2>Venue</h2><p><strong>' + esc(meta.venue) + "</strong><br>" + esc(meta.venueAddress) + '</p><p><a class="btn" id="maps-link" href="' + esc(maps) + '" target="_blank" rel="noopener">Open in Google Maps</a></p></section>';
    h += '<section class="card"><h2>Contact</h2>' + (meta.contactEmail ? '<p><a href="mailto:' + esc(meta.contactEmail) + '">' + esc(meta.contactEmail) + "</a></p>" : '<p class="muted">Contact details coming soon.</p>') + (meta.host ? "<p>Hosted by " + esc(meta.host) + "</p>" : "") + "</section>";
    h += '<section class="card"><h2>Format</h2><p>' + divisions().map(function (d) {
      var n = teams.filter(function (t) { return t.division === d; }).length;
      return esc(d) + ": " + n + " teams";
    }).join("<br>") + '</p><p class="muted">Standings use group games only. Win ' + esc(points.win) + ", draw " + esc(points.draw) + ", loss " + esc(points.loss) + " points.</p></section>";
    h += "</div>";
    app.innerHTML = h;
  }

  /* Hall of Champions from the workbook Past Winners tab. An empty cell shows "Not on record";
     a name ending in "?" shows as "to confirm". Never fill a gap with a guess. */
  function renderHistory() {
    var hist = T.history || [];
    var h = "<h1>History</h1>";
    if (!hist.length) {
      app.innerHTML = h + '<div class="card"><p>Past results are being compiled. Have results or photos from past editions?' +
        (meta.contactEmail ? ' Email <a href="mailto:' + esc(meta.contactEmail) + '">' + esc(meta.contactEmail) + "</a>." : " Contact the organizers.") + "</p></div>";
      return;
    }
    function cell(v, extra) {
      if (!v) return '<span class="tbd">Not on record</span>';
      var s = String(v).trim(), tc = /\?$/.test(s);
      return esc(tc ? s.replace(/\?+$/, "") : s) + (extra ? ' <span class="muted">' + esc(extra) + "</span>" : "") + (tc ? ' <span class="tbd">to confirm</span>' : "");
    }
    var divs = [];
    hist.forEach(function (x) { if (divs.indexOf(x.division) < 0) divs.push(x.division); });
    divs.forEach(function (div) {
      var rows = hist.filter(function (x) { return x.division === div; });
      h += "<h2>" + esc(div) + '</h2><div class="table-wrap"><table class="champs"><thead><tr><th>Year</th><th>Champion</th><th>Runner up</th><th>Third</th><th>MVP</th><th>MVG</th><th>Top scorer</th></tr></thead><tbody>' +
        rows.map(function (x) {
          return "<tr><td><strong>" + esc(x.year) + '</strong><br><span class="muted">Edition ' + esc(x.edition) + "</span></td><td><strong>" + cell(x.gold) + "</strong></td><td>" + cell(x.silver) + "</td><td>" + cell(x.bronze) +
            "</td><td>" + cell(x.mvp) + "</td><td>" + cell(x.mvg) + "</td><td>" + cell(x.topScorer, x.topScorerGoals != null ? x.topScorerGoals + " goals" : "") + "</td></tr>";
        }).join("") + "</tbody></table></div>";
    });
    h += '<p class="muted">From the engraved trophies, past event reports and official results.' + (meta.contactEmail ? ' Corrections welcome at <a href="mailto:' + esc(meta.contactEmail) + '">' + esc(meta.contactEmail) + "</a>." : "") + "</p>";
    app.innerHTML = h;
  }

  function youtubeEmbed(url) {
    if (!url) return null;
    var m = String(url).match(/(?:youtube\.com\/(?:watch\?(?:.*&)?v=|live\/|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{6,})/);
    return m ? "https://www.youtube-nocookie.com/embed/" + m[1] : null;
  }

  function renderWatch() {
    var url = (meta.streamUrl || "").trim();
    var h = "<h1>Watch live</h1>";
    if (!url) {
      h += '<div class="card" id="no-stream"><p>The live stream link is not posted yet. Check back on game day.</p></div>';
    } else if (youtubeEmbed(url)) {
      h += '<div class="video"><iframe src="' + esc(youtubeEmbed(url)) + '" title="Live stream" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe></div>' +
        '<p><a href="' + esc(url) + '" target="_blank" rel="noopener">Open the stream in a new tab</a></p>';
    } else {
      h += '<div class="card"><p>The stream opens on another site.</p><p><a class="btn" href="' + esc(url) + '" target="_blank" rel="noopener">Watch the stream</a></p></div>';
    }
    app.innerHTML = h;
  }

  /* exposed for testing and for custom pages */
  window.TK = { computeStandings: computeStandings, computeScorers: computeScorers, youtubeEmbed: youtubeEmbed, teamName: teamName };

  var pages = { home: renderHome, schedule: renderSchedule, standings: renderStandings, scorers: renderScorers, teams: renderTeams, info: renderInfo, watch: renderWatch, history: renderHistory };
  // Pages not listed here (refquiz, flashcards, vote, vote-admin) draw their own content.
  if (pages[page]) pages[page]();
})();

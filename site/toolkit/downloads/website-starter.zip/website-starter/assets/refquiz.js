/* Referee rules quiz for the tournament website.
   Questions: IHF Catalogue of Rules Questions 2025 (data/ihf_rules_catalogue_2025.js), official answer key.
   Leaderboard: netlify/functions/leaderboard.mjs (Netlify Blobs). Scores are reported by the browser,
   so do not attach a prize to the board unless scores are verified (see the README). */
(function(){
  function renderRefQuiz(el){
    var Q=window.REFQUIZ; if(!Q||!Q.questions)return;
    var per=Q.perQuestion||15, POOL=Q.questions.slice(), ROUND=Math.min(15,POOL.length);
    var API="/.netlify/functions/leaderboard", LKEY="tk_refquiz_v1";
    var CLOSE=new Date((window.TOURNAMENT&&window.TOURNAMENT.meta&&window.TOURNAMENT.meta.quizClose)||"2100-01-01T00:00:00Z"); // optional: set meta.quizClose (ISO date) to close the board
    function boardOpen(){ return Date.now() < CLOSE.getTime(); }
    function esc(x){ return String(x).replace(/[<>&"]/g,function(c){return {'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c];}); }
    function loadLocal(){ try{return JSON.parse(localStorage.getItem(LKEY)||"[]");}catch(e){return [];} }
    function saveLocal(rec){ try{var a=loadLocal(); a.push(rec); a.sort(function(x,y){return (y.score-x.score)||(x.ts-y.ts);}); localStorage.setItem(LKEY,JSON.stringify(a.slice(0,50)));}catch(e){} }
    function boardHTML(list,hl,live){
      list=(list||[]).slice(0,10);
      var tag=live?' <span class="lb-live">live</span>':'';
      var head='<div class="quiz-lb-h">Weekend leaderboard'+tag+'</div>';
      if(!list.length) return head+'<div class="muted" style="font-size:13px;text-align:center">No scores yet - be the first!</div>';
      return head+'<table class="lb"><thead><tr><th>#</th><th style="text-align:left">Player</th><th>Score</th><th>Time</th></tr></thead><tbody>'+
        list.map(function(r,i){return '<tr'+(hl&&r.id===hl?' class="me"':'')+'><td>'+(i+1)+'</td><td class="lb-name">'+esc(r.name)+'</td><td>'+r.score+'/'+r.total+'</td><td>'+fmtMs(r.ms)+'</td></tr>';}).join("")+'</tbody></table>'+
        '<div class="muted" style="font-size:11px;text-align:center;margin-top:6px">Ranked by score, then fastest time.</div>';
    }
    function getBoard(cb){ fetch(API,{headers:{"Accept":"application/json"}}).then(function(r){return r.json();}).then(function(l){cb(l,true);}).catch(function(){cb(loadLocal(),false);}); }
    function postBoard(rec,cb){ saveLocal(rec); if(!boardOpen()){ getBoard(cb); return; } fetch(API,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(rec)}).then(function(r){return r.json();}).then(function(l){cb(l,true);}).catch(function(){cb(loadLocal(),false);}); }
    function shuffle(a){ a=a.slice(); for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=a[i];a[i]=a[j];a[j]=t;} return a; }
    // Rule-spread round draw: at most one question per rule until every rule has been used,
    // then fill the remainder at random. At most MAX_MULTI "select all" questions per round.
    var MAX_MULTI=5;
    function drawRound(pool){
      var byTopic={}, chosen=[], multi=0, cap=MAX_MULTI;
      pool.forEach(function(q){ var t=(q&&q.topic)||"other"; (byTopic[t]=byTopic[t]||[]).push(q); });
      var topics=shuffle(Object.keys(byTopic)), lists={};
      topics.forEach(function(t){ lists[t]=shuffle(byTopic[t]); });
      while(chosen.length<ROUND){ var added=false;
        for(var k=0;k<topics.length&&chosen.length<ROUND;k++){ var l=lists[topics[k]];
          for(var j=0;j<l.length;j++){ if(l[j].cs&&multi>=cap)continue; var q=l.splice(j,1)[0]; if(q.cs)multi++; chosen.push(q); added=true; break; } }
        if(!added){ if(cap===Infinity)break; cap=Infinity; } }
      return shuffle(chosen);
    }
    var name="", qs=[], i=0, score=0, timer=null, left=per, answered=false, qStartTs=0, qElapsedMs=0;
    function fmtMs(ms){ if(ms==null||isNaN(ms))return "-"; var s=ms/1000, m=Math.floor(s/60), sec=Math.floor(s%60), t=Math.floor((s*10)%10); return m+":"+("0"+sec).slice(-2)+"."+t; }
    function intro(){
      el.innerHTML='<div class="quiz quiz-intro"><div class="quiz-badge"><i class="ti ti-flag"></i></div>'+
        '<h2 style="margin:10px 0 4px">You think you can ref?</h2>'+
        '<p class="muted" style="max-width:520px;margin:0 auto 14px">'+ROUND+' questions &middot; <b>15 to 45 seconds each</b>, depending on length. Some questions have more than one correct answer. Questions from the IHF Catalogue of Rules Questions 2025. Add a nickname to join the weekend leaderboard.</p>'+
                (boardOpen()?'':'<div class="callout" style="margin:0 0 12px">The leaderboard is <b>closed</b>. You can still play for practice.</div>')+
        '<input id="qname" class="quiz-name" maxlength="18" placeholder="Your nickname" autocomplete="off" spellcheck="false">'+
        '<div style="margin:14px 0"><button class="btn btn-pri btn-lg" id="qstart">Start the test</button></div>'+
        '<div class="quiz-lb-wrap" id="qlb"><div class="quiz-lb-h">Weekend leaderboard</div><div class="muted" style="font-size:13px;text-align:center">Loading…</div></div></div>';
      var inp=el.querySelector("#qname"); void inp; /* no autofocus - keeps the Refereeing page at the top */
      getBoard(function(l,live){ var w=el.querySelector("#qlb"); if(w)w.innerHTML=boardHTML(l,null,live); });
      function begin(){ name=((inp&&inp.value)||"Anon").trim().slice(0,18)||"Anon"; qElapsedMs=0;
        qs=drawRound(POOL).map(function(q){ var opts=shuffle(q.a.map(function(t,idx){return {t:t,ok:q.cs?q.cs.indexOf(idx)>=0:idx===q.c};})); return {q:q.q,opts:opts,why:q.why,t:q.t||per,multi:!!q.cs}; });
        i=0; score=0; show(); }
      el.querySelector("#qstart").addEventListener("click",begin);
      if(inp)inp.addEventListener("keydown",function(e){ if(e.key==="Enter")begin(); });
    }
    function show(){
      var q=qs[i]; answered=false; left=q.t; qStartTs=Date.now();
      var opts=q.opts.map(function(o,idx){return '<button class="quiz-opt" data-i="'+idx+'">'+esc(o.t)+'</button>';}).join("");
      el.innerHTML='<div class="quiz"><div class="quiz-top"><span class="quiz-count">Q '+(i+1)+' / '+qs.length+'</span><span class="quiz-score">Score '+score+'</span><span class="quiz-timer" id="qtimer">'+left+'</span></div>'+
        '<div class="quiz-bar"><div class="quiz-bar-in" id="qbar"></div></div>'+
        '<div class="quiz-q">'+esc(q.q)+'</div>'+(q.multi?'<div class="quiz-multi">More than one answer is correct. Select every correct answer, then submit.</div>':'')+
        '<div class="quiz-opts">'+opts+'</div>'+(q.multi?'<div style="margin-top:12px"><button class="btn btn-pri" id="qsubmit">Submit</button></div>':'')+'<div class="quiz-fb" id="qfb"></div></div>';
      Array.prototype.forEach.call(el.querySelectorAll(".quiz-opt"),function(b){b.addEventListener("click",function(){
        if(q.multi){ if(!answered){ b.classList.toggle("picked"); b.setAttribute("aria-pressed",b.classList.contains("picked")?"true":"false"); } }
        else choose(+b.getAttribute("data-i"));});});
      if(q.multi) el.querySelector("#qsubmit").addEventListener("click",function(){ submitMulti(false); });
      var bar=el.querySelector("#qbar"); if(bar){ bar.style.transition="none"; bar.style.width="100%"; void bar.offsetWidth; bar.style.transition="width "+q.t+"s linear"; bar.style.width="0%"; }
      clearInterval(timer); timer=setInterval(function(){ left--; var t=el.querySelector("#qtimer"); if(t)t.textContent=left; if(left<=0){clearInterval(timer); if(!answered){ if(q.multi)submitMulti(true); else choose(-1);} } },1000);
    }
    function choose(idx){
      if(answered)return; qElapsedMs+=Date.now()-qStartTs; answered=true; clearInterval(timer);
      var q=qs[i], ci=-1; q.opts.forEach(function(o,k){if(o.ok)ci=k;});
      Array.prototype.forEach.call(el.querySelectorAll(".quiz-opt"),function(b){var bi=+b.getAttribute("data-i"); b.disabled=true; if(bi===ci)b.classList.add("correct"); if(bi===idx&&idx!==ci)b.classList.add("wrong");});
      feedback(idx===ci, idx===-1);
    }
    // "Select all" questions: all or nothing; on time out the current selection is scored.
    function submitMulti(timedOut){
      if(answered)return; qElapsedMs+=Date.now()-qStartTs; answered=true; clearInterval(timer);
      var q=qs[i], ok=true;
      Array.prototype.forEach.call(el.querySelectorAll(".quiz-opt"),function(b){var o=q.opts[+b.getAttribute("data-i")], picked=b.classList.contains("picked");
        b.disabled=true; b.classList.remove("picked"); if(o.ok)b.classList.add("correct"); if(picked&&!o.ok)b.classList.add("wrong"); if(picked!==o.ok)ok=false;});
      var sb=el.querySelector("#qsubmit"); if(sb)sb.parentNode.removeChild(sb);
      feedback(ok, timedOut);
    }
    function feedback(ok, timedOut){
      var q=qs[i]; if(ok)score++;
      var st=el.querySelector(".quiz-score"); if(st)st.textContent="Score "+score;
      el.querySelector("#qfb").innerHTML='<b>'+(ok?"Correct! ":(timedOut?"Time&rsquo;s up! ":"Nope. "))+'</b>'+esc(q.why)+'<div class="muted" style="font-size:12px;margin-top:6px">Take your time - the clock is paused while you read.</div><div style="margin-top:10px"><button class="btn btn-pri" id="qnext">'+(i+1<qs.length?"Next &rarr;":"Finish")+'</button></div>';
      el.querySelector("#qnext").addEventListener("click",function(){ i++; if(i<qs.length)show(); else finish(); });
    }
    function finish(){
      var id=Date.now()+"-"+Math.floor(Math.random()*1e6), rec={id:id,name:name,score:score,total:qs.length,ms:qElapsedMs,ts:Date.now()};
      var r=score/qs.length, g=r>=0.86?["Certified referee","You could officiate the final."]:r>=0.6?["Table official","Strong rules knowledge."]:r>=0.33?["Rookie","Keep studying the rulebook."]:["Spectator","Best leave the whistle to the pros!"];
      el.innerHTML='<div class="quiz quiz-result"><div class="quiz-bigscore"><span class="bs-num">'+score+'</span> / '+qs.length+'</div><h2 style="margin:8px 0 2px">'+g[0]+'</h2><p class="muted" style="margin:0 0 8px">'+esc(name)+' &mdash; '+g[1]+'</p>'+
        '<div class="quiz-lb-wrap" id="qlb"><div class="quiz-lb-h">Weekend leaderboard</div><div class="muted" style="font-size:13px;text-align:center">Saving…</div></div>'+
        '<div style="margin-top:14px"><button class="btn btn-pri" id="qretry">Play again</button> <a class="btn btn-ghost" href="referees.html">Meet the real refs</a></div></div>';
      el.querySelector("#qretry").addEventListener("click",intro);
      postBoard(rec,function(l,live){ var w=el.querySelector("#qlb"); if(w)w.innerHTML=boardHTML(l,id,live); });
    }
    intro();
  }
  function go(){ var el=document.getElementById("refquiz"); if(el) renderRefQuiz(el); }
  if(document.readyState!=="loading") go(); else document.addEventListener("DOMContentLoaded",go);
})();

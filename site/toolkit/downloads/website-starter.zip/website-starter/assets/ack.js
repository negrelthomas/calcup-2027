/* Head coach confirmation of the technical document: coach page (#ack-coach) and organizer
   page (#ack-admin). Every check runs on the server (netlify/functions/ack.mjs). */
(function () {
  var API = "/.netlify/functions/ack";
  var css =
    ".vt{max-width:860px;margin:0 auto;padding:22px 0 40px;font-size:15px;line-height:1.5}" +
    ".vt h2{font-size:20px;margin:26px 0 8px}.vt h3{font-size:16px;margin:0 0 2px}" +
    ".vt .vt-card{background:#fff;border:1px solid #dfe5ec;border-radius:12px;padding:16px;margin:12px 0}" +
    ".vt .vt-muted{color:#5b6b7c;font-size:13px}.vt .vt-row{display:flex;gap:10px;align-items:center;margin:8px 0;flex-wrap:wrap}" +
    ".vt input[type=text],.vt input[type=password]{flex:1;min-width:0;font:inherit;padding:9px 10px;border:1px solid #c5cfda;border-radius:8px;background:#fff;max-width:100%}" +
    ".vt button{font:inherit;font-weight:600;padding:10px 18px;border-radius:8px;border:1px solid transparent;cursor:pointer;background:var(--accent,#F47920);color:#2b1400}" +
    ".vt button.vt-sec{background:#fff;border-color:#c5cfda;color:#102A43}.vt button:disabled{opacity:.5;cursor:default}" +
    ".vt .vt-msg{padding:12px 14px;border-radius:10px;margin:12px 0;background:#eef2f6}.vt .vt-ok{background:#e2f2ec;color:#145a3a}.vt .vt-err{background:#f7e3e3;color:#8a1f1f}" +
    ".vt table{width:100%;border-collapse:collapse;font-size:14px}.vt th,.vt td{padding:7px 6px;border-bottom:1px solid #e6ebf1;text-align:left;vertical-align:top}" +
    ".vt th{background:var(--primary,#102A43);color:#fff;font-size:12px;text-transform:uppercase;letter-spacing:.3px}" +
    ".vt .vt-scroll{overflow-x:auto}.vt .vt-pill{font-size:12px;font-weight:600;padding:2px 8px;border-radius:20px;background:#eef2f6;white-space:nowrap}" +
    ".vt .vt-pill.on{background:#e2f2ec;color:#145a3a}.vt .vt-pill.off{background:#f7e3e3;color:#8a1f1f}.vt .vt-pill.warn{background:#fdf0dc;color:#7a4a00}" +
    ".vt label.vt-agree{display:flex;gap:10px;align-items:flex-start;margin:12px 0}.vt label.vt-agree input{margin-top:4px;width:18px;height:18px}";
  function addCss() { var s = document.createElement("style"); s.textContent = css; document.head.appendChild(s); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function post(body) {
    return fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().then(function (j) { if (!r.ok || j.error) throw new Error(j.error || ("Error " + r.status)); return j; }); });
  }
  function fmt(iso) { if (!iso) return ""; return new Date(iso).toLocaleString([], { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }); }
  function gameDate(fg) { return fg ? new Date(fg.date + "T" + (fg.time || "00:00")) : null; }
  function gameText(fg) { var d = gameDate(fg); return d ? fmt(d.toISOString()) + (fg.no != null ? " (game " + fg.no + ")" : "") : "Not scheduled yet"; }

  /* Reminder stage before the first game: 7 days, 3 days, 1 day, then a last call on game day. */
  function stage(fg) {
    var d = gameDate(fg); if (!d) return null;
    var h = (d - new Date()) / 36e5;
    if (h <= 0) return { label: "Past first game", cls: "off" };
    if (h <= 4) return { label: "Last call", cls: "off" };
    if (h <= 24) return { label: "1 day reminder", cls: "warn" };
    if (h <= 72) return { label: "3 day reminder", cls: "warn" };
    if (h <= 168) return { label: "7 day reminder", cls: "warn" };
    return { label: "Not due yet", cls: "" };
  }

  /* ================= head coach ================= */
  function coach(el) {
    var t = new URLSearchParams(location.search).get("t");
    if (!t) { el.innerHTML = '<div class="vt-msg vt-err">This page opens from your team\'s personal link. Use the link the organizer sent you.</div>'; return; }
    el.innerHTML = '<div class="vt-msg">Loading&hellip;</div>';
    post({ action: "doc", t: t }).then(render).catch(function (e) { el.innerHTML = '<div class="vt-msg vt-err">' + esc(e.message) + "</div>"; });
    function render(R) {
      var head = '<div class="vt-card"><h3>' + esc(R.team.name) + '</h3><div class="vt-muted">' + esc(R.team.div) + " &middot; " + esc(R.event) + " &middot; First game: " + esc(gameText(R.team.firstGame)) + "</div></div>";
      var doc = '<div class="vt-card"><h3>' + esc(R.doc.docTitle) + ", version " + esc(R.doc.version) + "</h3>" +
        (R.doc.docUrl ? '<p><a href="' + esc(R.doc.docUrl) + '" target="_blank" rel="noopener">Open the document</a></p>' : '<p class="vt-muted">The organizer sends the document with this link.</p>') + "</div>";
      if (R.confirmed) { el.innerHTML = head + doc + '<div class="vt-msg vt-ok">Confirmed by ' + esc(R.confirmed.name) + " on " + esc(fmt(R.confirmed.ts)) + " for version " + esc(R.confirmed.version) + ". Thank you. Nothing else to do unless the organizer publishes a new version.</div>"; return; }
      var h = head + doc + (R.older ? '<div class="vt-msg">Your team confirmed version ' + esc(R.older.version) + " on " + esc(fmt(R.older.ts)) + ". The document has changed since: please read version " + esc(R.doc.version) + " and confirm again.</div>" : "") +
        '<div class="vt-card"><div class="vt-row"><span style="min-width:90px;font-weight:600">Your name</span><input type="text" id="ak-name" autocomplete="name" value="' + esc(R.team.coach) + '"></div>' +
        '<label class="vt-agree"><input type="checkbox" id="ak-agree"><span>As head coach (Official A) of ' + esc(R.team.name) + ", I confirm that I have read version " + esc(R.doc.version) + " of the " + esc(R.doc.docTitle.toLowerCase()) + " and that my team accepts it. I will share it with my players and team officials.</span></label>" +
        '<div class="vt-row"><button id="ak-go">Confirm for my team</button></div><div id="ak-out"></div><p class="vt-muted">Confirm before your first game. One confirmation per team; the organizer sees the name and the time.</p></div>';
      el.innerHTML = h;
      el.querySelector("#ak-go").addEventListener("click", function () {
        var b = this, out = el.querySelector("#ak-out");
        b.disabled = true;
        post({ action: "confirm", t: t, version: R.doc.version, agree: el.querySelector("#ak-agree").checked, name: el.querySelector("#ak-name").value })
          .then(function () { return post({ action: "doc", t: t }).then(render); })
          .catch(function (e) { b.disabled = false; out.innerHTML = '<div class="vt-msg vt-err">' + esc(e.message) + "</div>"; });
      });
    }
  }

  /* ================= organizer ================= */
  function admin(el) {
    var SK = "ack-admin-token", token = "";
    try { token = sessionStorage.getItem(SK) || ""; } catch (e) {}
    el.innerHTML = '<div class="vt-card"><div class="vt-row"><input type="password" id="ak-tok" placeholder="Organizer token (VOTE_ADMIN_TOKEN)" value="' + esc(token) + '"><button id="ak-load">Show status</button></div></div><div id="ak-main"></div>';
    var main = el.querySelector("#ak-main");
    function call(action, extra) {
      token = el.querySelector("#ak-tok").value.trim();
      try { sessionStorage.setItem(SK, token); } catch (e) {}
      var b = { action: action, token: token }; for (var k in extra || {}) b[k] = extra[k];
      return post(b).then(draw).catch(function (e) { main.insertAdjacentHTML("afterbegin", '<div class="vt-msg vt-err">' + esc(e.message) + "</div>"); });
    }
    function reminder(S, t) {
      return "Subject: " + S.event + ": please confirm the " + S.doc.docTitle.toLowerCase() + " (version " + S.doc.version + ")\n\n" +
        "Hello " + (t.coach || "coach") + ",\n\n" +
        "Before your first game (" + gameText(t.firstGame) + "), each head coach confirms on our site that the team has read and accepts the " + S.doc.docTitle.toLowerCase() + ". " +
        (t.older ? "Your team confirmed version " + t.older.version + "; the document has changed since, so please read version " + S.doc.version + " and confirm again. " : "") +
        "It takes one minute:\n" + t.link + "\n\nThis link is personal to " + t.name + ". Thank you.";
    }
    function csvCell(v) { v = String(v == null ? "" : v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }
    function draw(S) {
      var done = S.teams.filter(function (t) { return t.confirmed; }).length;
      var h = '<div class="vt-card"><h3>Document</h3><div class="vt-row"><input type="text" id="ak-title" placeholder="Title" value="' + esc(S.doc.docTitle) + '"><input type="text" id="ak-ver" placeholder="Version, for example 1.0" style="max-width:150px" value="' + esc(S.doc.version) + '"></div>' +
        '<div class="vt-row"><input type="text" id="ak-url" placeholder="Link to the document (https://... or a PDF on this site)" value="' + esc(S.doc.docUrl) + '"><button id="ak-save">Publish this version</button></div>' +
        '<p class="vt-muted">A new version number asks every team to confirm again. Links stay the same.</p></div>';
      if (!S.doc.version) { main.innerHTML = h + '<div class="vt-msg">Publish a version first. Coaches see a waiting message until then.</div>'; bind(S); return; }
      h += '<div class="vt-msg">' + done + " of " + S.teams.length + " teams confirmed version " + esc(S.doc.version) + ". Send reminders 7 days, 3 days and 1 day before each team's first game, from your own mailbox or phone.</div>";
      h += '<div class="vt-row"><button class="vt-sec" id="ak-csv">Download pending teams (CSV)</button><button class="vt-sec" id="ak-refresh">Refresh</button></div>';
      h += '<div class="vt-scroll"><table><thead><tr><th>Team</th><th>Head coach</th><th>First game</th><th>Status</th><th>Reminder</th><th></th></tr></thead><tbody>' +
        S.teams.map(function (t, i) {
          var st = t.confirmed ? '<span class="vt-pill on">Confirmed</span><div class="vt-muted">' + esc(t.confirmed.name) + ", " + esc(fmt(t.confirmed.ts)) + "</div>"
            : t.older ? '<span class="vt-pill warn">Older version ' + esc(t.older.version) + "</span>" : '<span class="vt-pill off">Not confirmed</span>';
          var sg = t.confirmed ? null : stage(t.firstGame);
          return "<tr><td>" + esc(t.name) + '<div class="vt-muted">' + esc(t.div) + "</div></td><td>" + (t.coach ? esc(t.coach) : '<span class="vt-pill off">No Official A</span>') + "</td><td>" + esc(gameText(t.firstGame)) + "</td><td>" + st + "</td><td>" +
            (sg ? '<span class="vt-pill ' + sg.cls + '">' + esc(sg.label) + "</span>" : "") + "</td><td>" +
            (t.confirmed ? "" : '<button class="vt-sec" data-copy="' + i + '">Copy reminder</button>') + "</td></tr>";
        }).join("") + "</tbody></table></div>";
      main.innerHTML = h; bind(S);
    }
    function bind(S) {
      main.querySelector("#ak-save").addEventListener("click", function () {
        call("setdoc", { docTitle: main.querySelector("#ak-title").value, version: main.querySelector("#ak-ver").value, docUrl: main.querySelector("#ak-url").value });
      });
      var r = main.querySelector("#ak-refresh"); if (r) r.addEventListener("click", function () { call("status"); });
      var c = main.querySelector("#ak-csv"); if (c) c.addEventListener("click", function () {
        var rows = [["Team", "Division", "Head coach", "First game", "Status", "Reminder due", "Link", "Message"]];
        S.teams.filter(function (t) { return !t.confirmed; }).forEach(function (t) {
          var sg = stage(t.firstGame);
          rows.push([t.name, t.div, t.coach, gameText(t.firstGame), t.older ? "Older version " + t.older.version : "Not confirmed", sg ? sg.label : "", t.link, reminder(S, t)]);
        });
        var blob = new Blob(["﻿" + rows.map(function (x) { return x.map(csvCell).join(","); }).join("\r\n")], { type: "text/csv" });
        var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "coach-confirmation-pending.csv"; a.click();
      });
      Array.prototype.forEach.call(main.querySelectorAll("[data-copy]"), function (b) {
        b.addEventListener("click", function () {
          var txt = reminder(S, S.teams[+b.getAttribute("data-copy")]);
          (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(function () { b.textContent = "Copied"; }, function () { window.prompt("Copy the reminder:", txt); });
        });
      });
    }
    el.querySelector("#ak-load").addEventListener("click", function () { call("status"); });
    if (token) call("status");
  }

  var c = document.getElementById("ack-coach"), a = document.getElementById("ack-admin");
  if (c || a) addCss();
  if (c) coach(c);
  if (a) admin(a);
})();
